﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;

namespace ExtensionMethods
{
    public static class MyExtensions
    {
        public static string Right(this string s, int length)
        {
            length = Math.Max(length, 0);

            if (s.Length > length)
            {
                return s.Substring(s.Length - length, length);
            }
            else
            {
                return s;
            }
        }


        /// <summary>
        ///  IV (對稱演算法的初始化向量)和Key(金鑰)
        /// </summary>

        /// 第一組加密金鑰 for real time Encrypt
        public static string strKey = "ethanlin"; //一定要有8碼
        public static string strIV = "ethanlin";
        /// 第一組加密金鑰
        /// 
        /// 第二組加密金鑰 for OralceDB login Encrypt
        public static string strKey1 = "25236470"; //一定要有8碼
        public static string strIV1 = "ethanlin";
        /// 第二組加密金鑰
        
        /// <summary>
        ///  加密
        /// </summary>
        /// <param name ="_strQ"></param>>
        /// <returns></returns>>
        /// 

        /// 第一組加密金鑰
        public static string Encrypt(string _strQ)
        {

            byte[] buffer = Encoding.UTF8.GetBytes(_strQ);
            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateEncryptor(Encoding.UTF8.GetBytes(strKey), Encoding.UTF8.GetBytes(strIV)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Convert.ToBase64String(ms.ToArray()).Replace("+", "%");
        }

        /// <summary>
        ///  解密
        /// </summary>
        /// <param name ="_strQ"></param>>
        /// <returns></returns>>

        public static string Decrypt(string _strQ)
        {
            _strQ = _strQ.Replace("%", "+");
            byte[] buffer = Convert.FromBase64String(_strQ);

            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateDecryptor(Encoding.UTF8.GetBytes(strKey), Encoding.UTF8.GetBytes(strIV)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Encoding.UTF8.GetString(ms.ToArray());
        }
        /// 第一組加密金鑰
        /// 第二組加密金鑰
        public static string Encrypt1(string _strQ)
        {

            byte[] buffer = Encoding.UTF8.GetBytes(_strQ);
            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateEncryptor(Encoding.UTF8.GetBytes(strKey1), Encoding.UTF8.GetBytes(strIV1)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Convert.ToBase64String(ms.ToArray()).Replace("+", "%");
        }

        /// <summary>
        ///  解密
        /// </summary>
        /// <param name ="_strQ"></param>>
        /// <returns></returns>>

        public static string Decrypt1(string _strQ)
        {
            _strQ = _strQ.Replace("%", "+");
            byte[] buffer = Convert.FromBase64String(_strQ);

            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateDecryptor(Encoding.UTF8.GetBytes(strKey1), Encoding.UTF8.GetBytes(strIV1)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Encoding.UTF8.GetString(ms.ToArray());
        }
        /// 第二組加密金鑰

    }
}
