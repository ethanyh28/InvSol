﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using System.Data.OracleClient;
using ExtensionMethods;

namespace DailyTrans01
{
    public partial class F_DailyForm : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        string dirstr = Application.StartupPath;
        string dirstr1 = "" ;

        //public SqlConnection Excel_cnn;
        //MSSQL connection string 
        string connectionString = null;

        public SqlConnection cnn;
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";

        //ORA connection string 
        public OracleConnection cnn_ora;
        string connectionString_ora = null;
        string server_ora = "";
        string database_ora = "";
        string user_ora = "";
        string password_ora = "";

        string loguser_ = "";
        string vFlag = "";
        string vFlagTime = "F";


        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release to Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void Delay(int mm)
        {
            DateTime current = DateTime.Now;

            while (current.AddMilliseconds(mm) > DateTime.Now)
            {
                Application.DoEvents();
            }
            return;
        }

        private string DT_adj() 
        {
            String DT_ADJ;
            DT_ADJ = "";

            String now_str = DateTime.Now.Hour.ToString("00") + DateTime.Now.Minute.ToString("00");
            if (String.Compare(now_str, "1301") == -1) //中午以前維持前日日期
            {
                if (DateTime.Today.DayOfWeek == DayOfWeek.Monday) //星期一的前一工作日設定為星期五
                {
                    DT_ADJ = DateTime.Today.AddDays(-3).Year.ToString("0000") + DateTime.Today.AddDays(-3).Month.ToString("00") + DateTime.Today.AddDays(-3).Day.ToString("00");
                }
                else if (DateTime.Today.DayOfWeek == DayOfWeek.Sunday)//星期日的前一工作日設定為星期五
                {
                    DT_ADJ = DateTime.Today.AddDays(-2).Year.ToString("0000") + DateTime.Today.AddDays(-2).Month.ToString("00") + DateTime.Today.AddDays(-2).Day.ToString("00");
                }
                else
                {
                    DT_ADJ = DateTime.Today.AddDays(-1).Year.ToString("0000") + DateTime.Today.AddDays(-1).Month.ToString("00") + DateTime.Today.AddDays(-1).Day.ToString("00");
                }
            }
            else //中午以後調整為當日日期
            {
                if (DateTime.Today.DayOfWeek == DayOfWeek.Sunday) //當日若為星期日,調整為星期五
                {
                    DT_ADJ = DateTime.Today.AddDays(-2).Year.ToString("0000") + DateTime.Today.AddDays(-2).Month.ToString("00") + DateTime.Today.AddDays(-2).Day.ToString("00");
                }
                else if (DateTime.Today.DayOfWeek == DayOfWeek.Saturday)//當日若為星期六,調整為星期五
                {
                    DT_ADJ = DateTime.Today.AddDays(-1).Year.ToString("0000") + DateTime.Today.AddDays(-1).Month.ToString("00") + DateTime.Today.AddDays(-1).Day.ToString("00");
                }
                else
                {
                    DT_ADJ = DateTime.Today.AddDays(0).Year.ToString("0000") + DateTime.Today.AddDays(0).Month.ToString("00") + DateTime.Today.AddDays(0).Day.ToString("00");
                }
            }

            return DT_ADJ;
        }

        public void SaveToCSV(DataTable oTable, string FilePath)
        {
            
            StreamWriter wr = new StreamWriter(FilePath, false,System.Text.Encoding.UTF8);

            string data = "";
            int j = 0;
            foreach (DataRow row in oTable.Rows)
            {
                j = j + 1;      
                int i = 0 ;
                foreach (DataColumn column in oTable.Columns)
                {
                    i = i + 1 ;
                    if (oTable.Columns.Count == i)
                    { data += row[column].ToString().Trim() ;  }
                    else
                    { data += row[column].ToString().Trim() + ","; }                    
                }

                //if (oTable.Rows.Count > j)
                data += "\n";

                wr.Write(data);
                data = "";
            }
         
            wr.Dispose();
            wr.Close();
        }

        public void WriteToListbox(string Newline)
        {
            listBox1.Items.Insert(0,listBox1.Items.Count.ToString("000") + " " + Newline + " " + DateTime.Now.ToString() );
        }

        private void Reload_CheckList()
        {
            //Read Txt to Checklistbox
            cl_BAL.Items.Clear();
            if (System.IO.File.Exists(dirstr + "\\ToDoItem01.txt"))
                cl_BAL.Items.AddRange(System.IO.File.ReadAllLines(dirstr + "\\ToDoItem01.txt", Encoding.Default));

            for (int i = 0; i <= cl_BAL.Items.Count - 1; i++)
            {
                if (cl_BAL.Items[i].ToString().IndexOf(":", 0) > -1)
                { cl_BAL.SetItemChecked(i, true); }
                else
                { cl_BAL.SetItemChecked(i, false); }
            }
        }

        public F_DailyForm()
        {
            InitializeComponent();
            loguser_ = Environment.UserName;
            StringBuilder data = new StringBuilder(255);

            //取得ini檔案路徑
            dirstr1 = dirstr + "\\DailyTrans01.ini";
            toolStripStatusLabel1.Text = "" ;
            toolStripStatusLabel2.Text = "";

            //調整轉檔時間
            textBox2.Text = DT_adj();

            Reload_CheckList();

            // start timer
            timer1.Enabled = true ;
            cb_PROC.Checked = true;

            WriteToListbox("服務啟動...") ;
            //建立NotifyIcon
            this.notifyIcon1.Text = "每日轉檔";
            this.notifyIcon1.Visible = false;

            //填入預設值
            GetPrivateProfileString("CONFIG", "1ST", "", data, 255, dirstr1);
            tb_sTime.Text = data.ToString();
            GetPrivateProfileString("CONFIG", "2ND", "", data, 255, dirstr1);
            tb_sTime1.Text = data.ToString();
            GetPrivateProfileString("CONFIG", "3TH", "", data, 255, dirstr1);
            tb_sTime2.Text = data.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectSQL(textBox2.Text,"PDB");
            ConnectORA(textBox2.Text);
        }

        private int ConnectSQL(String vDt,String database_)
        {
            //連絡資料庫 MSSQL
            WriteToListbox("[" + vDt + "] 資料庫連結啟動!!");

            StringBuilder data = new StringBuilder(255);
            //database_ = "PDB";

            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr1);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr1);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr1);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr1);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 ";
            
            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;                
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            cnn.Open();
            if (cnn != null && cnn.State == ConnectionState.Open)
            {
                WriteToListbox("[" + vDt + "] 資料庫連結完成!!");
            }
            else
            {
                WriteToListbox("[" + vDt + "] 資料庫連結失敗,請查明原因!!");
            }
            return 0;
        }

        private int DisconnectSQL(String vDt)
        {

            if (cnn != null && cnn.State == ConnectionState.Open)
            {
                cnn.Close();
                WriteToListbox("[" + vDt + "] 資料庫結束連線!!");
            }
            return 0;
        }

        private int ConnectORA(String vDt)
        {

            //連結資料 ORA_CTLGA
            StringBuilder data_ora = new StringBuilder(255);
            //database_ora = "ORA_CTLGA";
            database_ora = toolStripDropDownButton1.Text;

            if (database_ora == "來源資料庫")
            {
                MessageBox.Show("請指定來源資料");
            }
            else
            {
                //連絡資料庫 MSSQL
                WriteToListbox("[" + vDt + "] ORA-資料庫連結啟動!!");

                GetPrivateProfileString(database_ora, "server_", "", data_ora, 255, dirstr1);
                server_ora = data_ora.ToString();
                //GetPrivateProfileString(database_ora, "database_", "", data_ora, 255, dirstr1);
                //database_ora = data_ora.ToString();
                GetPrivateProfileString(database_ora, "user_", "", data_ora, 255, dirstr1);
                user_ora = data_ora.ToString();
                GetPrivateProfileString(database_ora, "password_", "", data_ora, 255, dirstr1);
                password_ora = data_ora.ToString();

                connectionString_ora = "Data Source=" + server_ora
                                     + ";Persist Security Info = True; User ID=" + user_ora
                                     + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_ora)
                                     + ";Unicode = True ";

                if (cnn_ora != null)
                {
                    cnn_ora.Close();
                    cnn_ora.ConnectionString = connectionString_ora;
                }
                else
                {
                    cnn_ora = new OracleConnection(connectionString_ora);
                }

                cnn_ora.Open();

                if (cnn_ora != null && cnn_ora.State == ConnectionState.Open)
                {
                    WriteToListbox("[" + vDt + "] ORA-資料庫連結完成!!");
                    //StartExport(textBox2.Text, "SW.BTS702");
                }
                else
                {
                    WriteToListbox("[" + vDt + "] ORA-資料庫連結失敗,請查明原因!!");
                }

            }
            return 0;
        }

        private int DisconnectORA(String vDt)
        {

            if (cnn_ora != null && cnn_ora.State == ConnectionState.Open)
            {
                cnn_ora.Close();
                WriteToListbox("[" + vDt + "] ORA-資料庫結束連線!!");
                //StartExport(textBox2.Text, "SW.BTS702");
            }
            return 0;
        }

        //大量由 ORA 寫入 PDB 資料
        private int StartExport(String vDt , String TableName)
        {

                try
                {
                    try
                    {
                        if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                        {
                            cnn_ora.Open();
                        }
                        OracleCommand OraComm = new OracleCommand();
                        OraComm.Connection = cnn_ora;
                        //OraComm.Parameters.Clear();
                        //OraComm.CommandText = "SELECT * FROM " + TableName;

                    if ((TableName == "SW.BBS001") || (TableName == "SW.BBS008") ||
                            (TableName == "SW.BTS002") || (TableName == "SW.BTS702") ||
                            (TableName == "SW.BTS719") || (TableName == "SW.BTS724") ||
                            (TableName == "SW.BTS725") || (TableName == "SW.BTS771") ||
                            (TableName == "SW.BTS774"))
                        {
                            OraComm.CommandText = "SELECT * FROM " + TableName;
                            if (vFlag == "T") //flag for 第二次迴圈後不異動資料
                            {
                                OraComm.CommandText = OraComm.CommandText
                                                     + " WHERE 1 <> 1 ";
                            }
                        }
                        else if ((TableName == "SW.BTS717")) //現金/股票股利、增減資交易明細檔
                        {
                            OraComm.CommandText = "SELECT * FROM SW.BTS717 WHERE TRAN_NO  IN (SELECT TRAN_NO FROM SW.BTS716 WHERE TR_DATE = '" + vDt + "') ";
                        }
                        else if ((TableName == "SW.BTS709")) //每日收盤價
                        {
                            OraComm.CommandText = "SELECT * FROM " + TableName + " WHERE DATA_DATE = '" + vDt + "' ";
                        }
                        else if ((TableName == "SW.BBS009")) //每日匯率
                        {
                            OraComm.CommandText = "SELECT * FROM " + TableName + " WHERE CDATE = '" + vDt + "' ";
                        }
                        else //交易型資料TR_DATE
                        {
                            OraComm.CommandText = "SELECT * FROM " + TableName + " WHERE TR_DATE = '" + vDt + "' ";
                        }

                        //OraComm.Parameters.Add(new OracleParameter("DT1", vDt)); //日期yyyymmdd
                        OracleDataReader oraReader = OraComm.ExecuteReader();

                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        SqlCommand sqlComm = new SqlCommand();
                        sqlComm.Connection = cnn;                        
                        sqlComm.CommandTimeout = 0;
                        if (oraReader.HasRows)
                        {
                            //開始異動資料表 - 刪除 PDB 同一異動日資料
                            sqlComm.Parameters.Clear();
                            //sqlComm.CommandText = "DELETE FROM " + TableName + " WHERE UPD_DATE =  @DT1 ";
                            //sqlComm.CommandText = "TRUNCATE TABLE " + TableName;
                            if ((TableName == "SW.BBS001") || (TableName == "SW.BBS008") ||
                                (TableName == "SW.BTS002") || (TableName == "SW.BTS702") ||
                                (TableName == "SW.BTS719") || (TableName == "SW.BTS724") ||
                                (TableName == "SW.BTS725") || (TableName == "SW.BTS771") ||
                                (TableName == "SW.BTS774"))
                            {
                                sqlComm.CommandText = "TRUNCATE TABLE " + TableName;
                            }
                            else if ((TableName == "SW.BTS717")) //現金/股票股利、增減資交易明細檔
                            {
                                sqlComm.CommandText = "DELETE FROM SW.BTS717 WHERE TRAN_NO  IN (SELECT TRAN_NO FROM SW.BTS716 WHERE TR_DATE = '" + vDt + "') ";
                            }
                            else if ((TableName == "SW.BTS709")) //每日收盤價
                            {
                                sqlComm.CommandText = "DELETE FROM " + TableName + " WHERE DATA_DATE = '" + vDt + "' ";
                            }
                            else if ((TableName == "SW.BBS009")) //每日匯率
                            {
                                sqlComm.CommandText = "DELETE FROM " + TableName + " WHERE CDATE = '" + vDt + "' ";
                            }
                            else //交易型資料TR_DATE
                            {
                                sqlComm.CommandText = "DELETE FROM " + TableName + " WHERE TR_DATE = '" + vDt + "' ";
                            }
                            //sqlComm.Parameters.Add(new SqlParameter("DT1", vDt )); //日期yyyymmdd
                            sqlComm.ExecuteNonQuery();

                            // 讀取 ORA資料
                            OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm);

                            DataSet OraDataSet = new DataSet();
                            OraDataSet.Clear();
                            oraDataadapter.Fill(OraDataSet, TableName);

                            // 大量寫入庫存
                            SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                            sqlbulkcopy.BatchSize = 10000;
                            sqlbulkcopy.BulkCopyTimeout = 0;
                            sqlbulkcopy.DestinationTableName = TableName;
                            sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                            WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + ")轉檔完成!!");
                            Application.DoEvents();
                        }
                        else
                        {
                            WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                        }
                        oraReader.Close();
                        OraComm.Dispose();
                        sqlComm.Dispose();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(TableName + " " + ex.Message);
                        return -1;
                    }
                }
                catch (Exception ex)
                {
                    //Show mssql Exception
                    WriteToListbox(TableName + " " + ex.Message);
                    return -1;
                }
            return 0;
        }

        //大量由 ORA 寫入 PDB 資料 EXEC StoredProcedure BTSR308
        private int StartSP_BTSR308(String vDt, String TableName)
        {

            try
            {
                try
                {
                    if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                    {
                        cnn_ora.Open();
                    }

                    String vSOURCE_ = "";
                    String Tables = "";

                    if (TableName == "D01")
                    {
                        vSOURCE_ = "308-台幣債券";
                        Tables = "BTSR308TMP2";
                    }
                    else if (TableName == "D02")
                    {
                        vSOURCE_ = "308-外幣債券";
                        Tables = "BTSR308TMP2";
                    }
                    OracleCommand OraComm = new OracleCommand();
                    OraComm.Connection = cnn_ora;
                    OraComm.CommandType = CommandType.StoredProcedure;

                    OraComm.Parameters.Clear();
                    OraComm.CommandText = "SW.BTSR308_P02";
                    OraComm.Parameters.Add(new OracleParameter("xTR_DATE", vDt));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT2", "z"));
                    if (TableName == "D01")
                    {
                        OraComm.Parameters.Add(new OracleParameter("xREP_TYPE", "0")); //--0.國內投資 1.國外投資 
                    }
                    else
                    {
                        OraComm.Parameters.Add(new OracleParameter("xREP_TYPE", "1")); //--0.國內投資 1.國外投資 
                    }
                    OraComm.Parameters.Add(new OracleParameter("XSUM_TOTAL", "N")); //是否顯示小計
                    OraComm.Parameters.Add(new OracleParameter("XSUM_PORTFOLIO", "Y")); //是否顯示資產區隔(交易平台)
                    OraComm.Parameters.Add(new OracleParameter("XSUM_TYPE", "N")); //是否顯示債券小計
                    OraComm.Parameters.Add(new OracleParameter("XINC_ZERO", "N")); //是否顯示零庫存資料
                    OraComm.Parameters.Add(new OracleParameter("XTRADER_ID", " ")); //交易員代碼
                    OraComm.ExecuteNonQuery();

                    String SQLstr = "'" + vDt + "'" + "as DATE_ ,'" + vSOURCE_ + "' as SOURCE_ ";
                    OracleCommand OraComm1 = new OracleCommand();
                    OraComm1.Connection = OraComm.Connection;
                    OraComm1.CommandType = CommandType.Text;
                    OraComm1.CommandText = "SELECT " + SQLstr + ", SW." + Tables + ".* FROM SW." + Tables;

                    OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);
                    DataSet OraDataSet = new DataSet();
                    OraDataSet.Clear();
                    oraDataadapter.Fill(OraDataSet, Tables);

                    SqlCommand sqlComm = new SqlCommand();

                    if (OraDataSet.Tables[0].Rows.Count > 0)
                    {
                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        //刪除MSSQL資料表 當日資料                        
                        sqlComm.Connection = cnn;
                        sqlComm.CommandTimeout = 3000;
                        sqlComm.CommandText = "DELETE FROM " + Tables + " WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        // 大量寫入庫存
                        SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                        sqlbulkcopy.BatchSize = 10000;
                        sqlbulkcopy.BulkCopyTimeout = 0;
                        sqlbulkcopy.DestinationTableName = Tables;
                        sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + "轉檔完成!!");
                        Application.DoEvents();
                    }
                    else
                    {
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                    }
                    oraDataadapter.Dispose();
                    OraComm1.Dispose();
                    sqlComm.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(TableName + " " + ex.Message);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                //Show mssql Exception
                WriteToListbox(TableName + " " + ex.Message);
                return -1;
            }
            return 0;
        }

 
        //大量由 ORA 寫入 PDB 資料 EXEC StoredProcedure BTSR354
        private int StartSP_BTSR354(String vDt, String TableName)
        {

            try
            {
                try
                {
                    if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                    {
                        cnn_ora.Open();
                    }

                    String vSOURCE_ = "";
                    String Tables = "";

                    if (TableName == "D03")
                    {
                        vSOURCE_ = "354-投資單位";
                        Tables = "BTSR354TMP1";
                    }

                    OracleCommand OraComm = new OracleCommand();
                    OraComm.Connection = cnn_ora;
                    OraComm.CommandType = CommandType.StoredProcedure;

                    OraComm.Parameters.Clear();
                    OraComm.CommandText = "SW.BTSR354_P01";
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDATE", vDt));
                    OraComm.Parameters.Add(new OracleParameter("xREP_TYPE", "0")); 
                    OraComm.Parameters.Add(new OracleParameter("XINC_ZERO", "Y")); 
                    OraComm.Parameters.Add(new OracleParameter("XT6_CODE", "1")); //0.僅含有區隔資料 1.全部資料
                    OraComm.Parameters.Add(new OracleParameter("XREP_KIND", "0")); //0.庫存表  1.覆蓋法報表
                    OraComm.ExecuteNonQuery();

                    String SQLstr = "'" + vDt + "'" + "as DATE_ ,'" + vSOURCE_ + "' as SOURCE_ ";
                    OracleCommand OraComm1 = new OracleCommand();
                    OraComm1.Connection = OraComm.Connection;
                    OraComm1.CommandType = CommandType.Text;
                    OraComm1.CommandText = "SELECT " + SQLstr + ", SW." + Tables + ".* FROM SW." + Tables + " WHERE ORDER_CODE = 10 ";

                    OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);
                    DataSet OraDataSet = new DataSet();
                    OraDataSet.Clear();
                    oraDataadapter.Fill(OraDataSet, Tables);

                    SqlCommand sqlComm = new SqlCommand();

                    if (OraDataSet.Tables[0].Rows.Count > 0)
                    {
                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        //刪除MSSQL資料表 當日資料                        
                        sqlComm.Connection = cnn;
                        sqlComm.CommandTimeout = 3000;
                        sqlComm.CommandText = "DELETE FROM " + Tables + " WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        // 大量寫入庫存
                        SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                        sqlbulkcopy.BatchSize = 10000;
                        sqlbulkcopy.BulkCopyTimeout = 0;
                        sqlbulkcopy.DestinationTableName = Tables;
                        sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + "轉檔完成!!");
                        Application.DoEvents();
                    }
                    else
                    {
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                    }
                    oraDataadapter.Dispose();
                    OraComm1.Dispose();
                    sqlComm.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(TableName + " " + ex.Message);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                //Show mssql Exception
                WriteToListbox(TableName + " " + ex.Message);
                return -1;
            }
            return 0;
        }

        //大量由 ORA 寫入 PDB 資料 EXEC StoredProcedure BTSR453
        private int StartSP_BTSR453(String vDt, String TableName)
        {

            try
            {
                try
                {
                    if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                    {
                        cnn_ora.Open();
                    }

                    String vSOURCE_ = "";
                    String Tables = "";

                    if (TableName == "C03")
                    {
                        vSOURCE_ = "453-投資單位";
                        Tables = "BTSR453TMP1";
                    }

                    OracleCommand OraComm = new OracleCommand();
                    OraComm.Connection = cnn_ora;
                    OraComm.CommandType = CommandType.StoredProcedure;

                    OraComm.Parameters.Clear();
                    OraComm.CommandText = "SW.BTSR453_P01";
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDATE", vDt));
                    OraComm.Parameters.Add(new OracleParameter("xACC_TYPE", "1")); //--0.日結前 1:日結後
                    OraComm.Parameters.Add(new OracleParameter("xZERO_UNIT", "Y")); //是否顯示零庫存資料
                    OraComm.Parameters.Add(new OracleParameter("XDEAL_CTR", "0")); //0.全部 D1:國內 F1:國外
                    OraComm.Parameters.Add(new OracleParameter("XREP_KIND", "0")); //0.庫存表  1.覆蓋法報表
                    OraComm.ExecuteNonQuery();

                    String SQLstr = "'" + vDt + "'" + "as DATE_ ,'" + vSOURCE_ + "' as SOURCE_ ";
                    OracleCommand OraComm1 = new OracleCommand();
                    OraComm1.Connection = OraComm.Connection;
                    OraComm1.CommandType = CommandType.Text;
                    OraComm1.CommandText = "SELECT " + SQLstr + ", SW." + Tables + ".* FROM SW." + Tables;

                    OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);
                    DataSet OraDataSet = new DataSet();
                    OraDataSet.Clear();
                    oraDataadapter.Fill(OraDataSet, Tables);

                    SqlCommand sqlComm = new SqlCommand();

                    if (OraDataSet.Tables[0].Rows.Count > 0)
                    {
                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        //刪除MSSQL資料表 當日資料                        
                        sqlComm.Connection = cnn;
                        sqlComm.CommandTimeout = 3000;
                        sqlComm.CommandText = "DELETE FROM " + Tables + " WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        // 大量寫入庫存
                        SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                        sqlbulkcopy.BatchSize = 10000;
                        sqlbulkcopy.BulkCopyTimeout = 0;
                        sqlbulkcopy.DestinationTableName = Tables;
                        sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + "轉檔完成!!");
                        Application.DoEvents();
                    }
                    else
                    {
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                    }
                    oraDataadapter.Dispose();
                    OraComm1.Dispose();
                    sqlComm.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(TableName + " " + ex.Message);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                //Show mssql Exception
                WriteToListbox(TableName + " " + ex.Message);
                return -1;
            }
            return 0;
        }

        //大量由 ORA 寫入 PDB 資料 EXEC StoredProcedure BTSR753
        private int StartSP_BTSR753(String vDt, String TableName)
        {

            try
            {
                try
                {
                    if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                    {
                        cnn_ora.Open();
                    }

                    String vSOURCE_ = "";
                    String Tables = "";

                    if (TableName == "B03")
                    {
                        vSOURCE_ = "753-投資單位";
                        Tables = "BTSR753TMP1";
                    }

                    OracleCommand OraComm = new OracleCommand();
                    OraComm.Connection = cnn_ora;
                    OraComm.CommandType = CommandType.StoredProcedure;

                    OraComm.Parameters.Clear();
                    OraComm.CommandText = "SW.BTSR753_P01";
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDATE", vDt));
                    OraComm.Parameters.Add(new OracleParameter("xZERO_UNIT", "Y")); //是否顯示零庫存資料
                    OraComm.Parameters.Add(new OracleParameter("xDEAL_CTR", "0"));
                    OraComm.Parameters.Add(new OracleParameter("XREP_KIND", "0")); //0庫存/1覆蓋法
                    OraComm.ExecuteNonQuery();

                    String SQLstr = "'" + vDt + "'" + "as DATE_ ,'" + vSOURCE_ + "' as SOURCE_ ";
                    OracleCommand OraComm1 = new OracleCommand();
                    OraComm1.Connection = OraComm.Connection;
                    OraComm1.CommandType = CommandType.Text;
                    OraComm1.CommandText = "SELECT " + SQLstr + ", SW." + Tables + ".* FROM SW." + Tables + " WHERE DATA_TYPE = 0 ";

                    OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);
                    DataSet OraDataSet = new DataSet();
                    OraDataSet.Clear();
                    oraDataadapter.Fill(OraDataSet, Tables);
                    

                    SqlCommand sqlComm = new SqlCommand();

                    if (OraDataSet.Tables[0].Rows.Count > 0)
                    {
                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        //刪除MSSQL資料表 當日資料                        
                        sqlComm.Connection = cnn;
                        sqlComm.CommandTimeout = 3000;
                        sqlComm.CommandText = "DELETE FROM " + Tables + " WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        // 大量寫入庫存
                        SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                        sqlbulkcopy.BatchSize = 10000;
                        sqlbulkcopy.BulkCopyTimeout = 0;
                        sqlbulkcopy.DestinationTableName = Tables;
                        sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + "轉檔完成!!");
                        Application.DoEvents();
                    }
                    else
                    {
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                    }
                    oraDataadapter.Dispose();
                    OraComm1.Dispose();
                    sqlComm.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(TableName + " " + ex.Message);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                //Show mssql Exception
                WriteToListbox(TableName + " " + ex.Message);
                return -1;
            }
            return 0;
        }

        //共同基金取得庫存
        private int StartSP_BTSR402(String vDt, String TableName)
        {

            try
            {
                try
                {
                    if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                    {
                        cnn_ora.Open();
                    }

                    String vSOURCE_ = "";
                    String Tables = "";
                    //填入所有投資單位及部位資料
                    OracleCommand OraComm = new OracleCommand();
                    OraComm.Connection = cnn_ora;
                    OraComm.CommandType = CommandType.Text;
                    if (TableName == "C01")
                    {
                        OraComm.CommandText = "DELETE FROM SW.SELECTUNIT";
                    }
                    else if (TableName == "C02")
                    {
                        OraComm.CommandText = "DELETE FROM SW.SELECTPART";
                    }
                    OraComm.ExecuteNonQuery();

                    if (TableName == "C01")
                    {
                        OraComm.CommandText = "INSERT INTO SW.SELECTUNIT SELECT FUND_UNIT FROM SW.BTS471 GROUP BY FUND_UNIT";
                    }
                    else if (TableName == "C02")
                    {
                        OraComm.CommandText = "INSERT INTO SW.SELECTPART SELECT PART_ID FROM SW.BTS471 GROUP BY PART_ID";
                    }
                    OraComm.ExecuteNonQuery();

                    //讀取庫存資料
                    OraComm.CommandType = CommandType.StoredProcedure;
                    if (TableName == "C01")
                    {
                        vSOURCE_ = "402-投資單位";
                        Tables = "BTSR402TMP1";
                        OraComm.CommandText = "SW.BTSR402_P01";
                    }
                    else if (TableName == "C02")
                    {
                        vSOURCE_ = "402-部位";
                        Tables = "BTSR402TMP2";
                        OraComm.CommandText = "SW.BTSR402_P02";
                    }
                    OraComm.Parameters.Clear();
                    OraComm.Parameters.Add(new OracleParameter("xTR_DATE", vDt));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", ""));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", ""));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", ""));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", ""));
                    OraComm.Parameters.Add(new OracleParameter("XZERO_UNIT", "Y"));
                    OraComm.Parameters.Add(new OracleParameter("XBOOK_TYPE", "0")); //--0.原幣 1.記帳幣
                    OraComm.ExecuteNonQuery();

                    String SQLstr = "'" + vDt + "'" + "as DATE_ ,'" + vSOURCE_ + "' as SOURCE_ ";
                    OracleCommand OraComm1 = new OracleCommand();
                    OraComm1.Connection = OraComm.Connection;
                    OraComm1.CommandType = CommandType.Text;
                    OraComm1.CommandText = "SELECT " + SQLstr + ", SW." + Tables + ".* FROM SW." + Tables
                                         + " WHERE DATA_TYPE = 1  "; //AND  (ABS(UNIT_ON_HAND) + ABS(REALIZE_DIFF)+ ABS(REBATE_AMT)+ ABS(LIMITED_RATE)) <> 0 

                    OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);
                    DataSet OraDataSet = new DataSet();
                    OraDataSet.Clear();
                    oraDataadapter.Fill(OraDataSet, Tables);

                    SqlCommand sqlComm = new SqlCommand();

                    if (OraDataSet.Tables[0].Rows.Count > 0)
                    {
                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        //刪除MSSQL資料表 當日資料                        
                        sqlComm.Connection = cnn;
                        sqlComm.CommandTimeout = 3000;
                        sqlComm.CommandText = "DELETE FROM " + Tables + " WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        // 大量寫入庫存
                        SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                        sqlbulkcopy.BatchSize = 10000;
                        sqlbulkcopy.BulkCopyTimeout = 0;
                        sqlbulkcopy.DestinationTableName = Tables;
                        sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + "轉檔完成!!");
                        Application.DoEvents();
                    }
                    else
                    {
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                    }
                    oraDataadapter.Dispose();
                    OraComm1.Dispose();
                    sqlComm.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(TableName + " " + ex.Message);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                //Show mssql Exception
                WriteToListbox(TableName + " " + ex.Message);
                return -1;
            }
            return 0;
        }

        //712 報表取得庫存
        private int StartSP_BTSR712(String vDt, String TableName)
        {

            try
            {
                try
                {
                    if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                    {
                        cnn_ora.Open();
                    }

                    String vSOURCE_ = "";
                    String Tables = "";
                    //填入所有投資單位及部位資料
                    OracleCommand OraComm = new OracleCommand();
                    OraComm.Connection = cnn_ora;
                    OraComm.CommandType = CommandType.Text;
                    OraComm.CommandText = "DELETE FROM SW.SELECTEXECPART";
                    OraComm.ExecuteNonQuery();

                    OraComm.CommandText = "INSERT INTO SW.SELECTEXECPART SELECT FUND_UNIT , PART_ID FROM SW.BTS771";
                    OraComm.ExecuteNonQuery();

                    //讀取庫存資料
                    OraComm.CommandType = CommandType.StoredProcedure;
                    if (TableName == "B11")
                    {
                        vSOURCE_ = "712-投資單位";
                        Tables = "BTSR712TMP1";
                        OraComm.CommandText = "SW.BTSR712_P01";
                    }
                    else if (TableName == "B12")
                    {
                        vSOURCE_ = "712-部位";
                        Tables = "BTSR712TMP3";
                        OraComm.CommandText = "SW.BTSR712_P02";
                    }
                    OraComm.Parameters.Clear();
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("XFUND_UNIT1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("XFUND_UNIT2", "z"));
                    if (TableName == "B11")
                    {
                        OraComm.Parameters.Add(new OracleParameter("XDATE", vDt));
                        OraComm.Parameters.Add(new OracleParameter("XZERO_UNIT", "Y"));
                        OraComm.Parameters.Add(new OracleParameter("XSUM_FUND_UNIT", "Y")); //--0.原幣 1.記帳幣
                    }
                    else if (TableName == "B12")
                    {
                        OraComm.Parameters.Add(new OracleParameter("XPART_ID1", "0"));
                        OraComm.Parameters.Add(new OracleParameter("XPART_ID2", "z"));
                        OraComm.Parameters.Add(new OracleParameter("XDATE", vDt));
                        OraComm.Parameters.Add(new OracleParameter("XZERO_UNIT", "Y"));
                        OraComm.Parameters.Add(new OracleParameter("XSUM_PART_ID", "Y")); //--0.原幣 1.記帳幣
                    }
                    OraComm.ExecuteNonQuery();

                    String SQLstr = "'" + vDt + "'" + "as DATE_ ,'" + vSOURCE_ + "' as SOURCE_ " ;
                    OracleCommand OraComm1 = new OracleCommand();
                    OraComm1.Connection = OraComm.Connection;
                    OraComm1.CommandType = CommandType.Text;
                    OraComm1.CommandText = "SELECT " + SQLstr + ", SW." + Tables + ".* FROM SW." + Tables
                                          + " WHERE DATA_TYPE = 0 AND (ABS(STK_ON_HAND) + ABS(PROFIT_LOSS1)) <> 0  ";

                    OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);
                    DataSet OraDataSet = new DataSet();
                    OraDataSet.Clear();
                    oraDataadapter.Fill(OraDataSet, Tables);

                    SqlCommand sqlComm = new SqlCommand();

                    if (OraDataSet.Tables[0].Rows.Count > 0)
                    {
                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        //刪除MSSQL資料表 當日資料                        
                        sqlComm.Connection = cnn;
                        sqlComm.CommandTimeout = 3000;
                        sqlComm.CommandText = "DELETE FROM " + Tables + " WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        // 大量寫入庫存
                        SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                        sqlbulkcopy.BatchSize = 10000;
                        sqlbulkcopy.BulkCopyTimeout = 0;
                        sqlbulkcopy.DestinationTableName = Tables;
                        sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + "轉檔完成!!");
                        Application.DoEvents();
                    }
                    else
                    {
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                    }
                    oraDataadapter.Dispose();
                    OraComm1.Dispose();
                    sqlComm.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(TableName + " " + ex.Message);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                //Show mssql Exception
                WriteToListbox(TableName + " " + ex.Message);
                return -1;
            }
            return 0;
        }

        //719 報表取得庫存
        private int StartSP_BTSR719(String vDt, String TableName)
        {

            try
            {
                try
                {
                    if (cnn_ora == null && cnn_ora.State == ConnectionState.Closed)
                    {
                        cnn_ora.Open();
                    }

                    String vSOURCE_ = "";
                    String Tables = "";
                    //填入所有投資單位及部位資料
                    OracleCommand OraComm = new OracleCommand();
                    OraComm.Connection = cnn_ora;
                    OraComm.CommandType = CommandType.Text;
                    OraComm.CommandText = "DELETE FROM SW.SELECTEXECPART";
                    OraComm.ExecuteNonQuery();


                    OraComm.CommandText = "INSERT INTO SW.SELECTEXECPART SELECT FUND_UNIT , PART_ID FROM SW.BTS771";
                    OraComm.ExecuteNonQuery();

                    //讀取庫存資料
                    OraComm.CommandType = CommandType.StoredProcedure;
                    if (TableName == "B13")
                    {
                        vSOURCE_ = "719-投資單位-原";
                        Tables = "BTSR719TMP1";
                        OraComm.CommandText = "SW.BTSR719_P01";
                    }
                    else if (TableName == "B14")
                    {
                        vSOURCE_ = "719-投資單位-記";
                        Tables = "BTSR719TMP1";
                        OraComm.CommandText = "SW.BTSR719_P01";
                    }
                    else if (TableName == "B15")
                    {
                        vSOURCE_ = "719-部位-原";
                        Tables = "BTSR719TMP3";
                        OraComm.CommandText = "SW.BTSR719_P02";
                    }
                    else if (TableName == "B16")
                    {
                        vSOURCE_ = "719-部位-記";
                        Tables = "BTSR719TMP3";
                        OraComm.CommandText = "SW.BTSR719_P02";
                    }

                    OraComm.Parameters.Clear();
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", "z"));
                    OraComm.Parameters.Add(new OracleParameter("XFUND_UNIT1", "0"));
                    OraComm.Parameters.Add(new OracleParameter("XFUND_UNIT2", "z"));
                    if ((TableName == "B13") || (TableName == "B14"))
                    {
                        OraComm.Parameters.Add(new OracleParameter("XDATE", vDt));
                        OraComm.Parameters.Add(new OracleParameter("XZERO_UNIT", "Y"));
                        OraComm.Parameters.Add(new OracleParameter("XSUM_FUND_UNIT", "Y"));
                        if (TableName == "B13")
                        {
                            OraComm.Parameters.Add(new OracleParameter("XBOOK_TYPE", "0")); //--0.原幣 1.記帳幣
                        }
                        else if (TableName == "B14")
                        {
                            OraComm.Parameters.Add(new OracleParameter("XBOOK_TYPE", "1")); //--0.原幣 1.記帳幣
                        }
                    }
                    else if ((TableName == "B15") || (TableName == "B16"))
                    {
                        OraComm.Parameters.Add(new OracleParameter("XPART_ID1", "0"));
                        OraComm.Parameters.Add(new OracleParameter("XPART_ID2", "z"));
                        OraComm.Parameters.Add(new OracleParameter("XDATE", vDt));
                        OraComm.Parameters.Add(new OracleParameter("XZERO_UNIT", "Y"));
                        OraComm.Parameters.Add(new OracleParameter("XSUM_PART_ID", "Y"));
                        if (TableName == "B15")
                        {
                            OraComm.Parameters.Add(new OracleParameter("XBOOK_TYPE", "0")); //--0.原幣 1.記帳幣
                        }
                        else if (TableName == "B16")
                        {
                            OraComm.Parameters.Add(new OracleParameter("XBOOK_TYPE", "1")); //--0.原幣 1.記帳幣
                        }
                    }
                    
                    OraComm.ExecuteNonQuery();

                    String SQLstr = "'" + vDt + "'" + "as DATE_ ,'" + vSOURCE_ + "' as SOURCE_ ";
                    OracleCommand OraComm1 = new OracleCommand();
                    OraComm1.Connection = OraComm.Connection;
                    OraComm1.CommandType = CommandType.Text;
                    OraComm1.CommandText = "SELECT " + SQLstr + ", SW." + Tables + ".* FROM SW." + Tables
                                          + " WHERE DATA_TYPE = 0 AND (ABS(STK_ON_HAND) + ABS(PROFIT_LOSS1)) <> 0  ";

                    OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);
                    DataSet OraDataSet = new DataSet();
                    OraDataSet.Clear();
                    oraDataadapter.Fill(OraDataSet, Tables);

                    SqlCommand sqlComm = new SqlCommand();

                    if (OraDataSet.Tables[0].Rows.Count > 0)
                    {
                        if (cnn == null && cnn.State == ConnectionState.Closed)
                        {
                            cnn.Open();
                        }
                        //刪除MSSQL資料表 當日資料                        
                        sqlComm.Connection = cnn;
                        sqlComm.CommandTimeout = 3000;
                        sqlComm.CommandText = "DELETE FROM " + Tables + " WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        // 大量寫入庫存
                        SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                        sqlbulkcopy.BatchSize = 10000;
                        sqlbulkcopy.BulkCopyTimeout = 0;
                        sqlbulkcopy.DestinationTableName = Tables;
                        sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + "轉檔完成!!");
                        Application.DoEvents();
                    }
                    else
                    {
                        WriteToListbox("[" + vDt + "] ORA-" + TableName + "無資料!!");
                    }
                    oraDataadapter.Dispose();
                    OraComm1.Dispose();
                    sqlComm.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(TableName + " " + ex.Message);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                //Show mssql Exception
                WriteToListbox(TableName + " " + ex.Message);
                return -1;
            }
            return 0;
        }

        //產生BBG-PORT檔案股債基
        private int ExpertBEM_csv(String vDt)
        {
            String path_ = @"D:\BBU\TWL_BEM.csv";
            cnn.Close();
            cnn.Open();
            if (cnn != null && cnn.State == ConnectionState.Open)
            {
                // 執行轉檔
                String vSelstr;
                vSelstr = vDt;

                this.Cursor = Cursors.WaitCursor;
                ConnectSQL(vDt, "PDB");
                //1.組合股債基的資料產生
                SqlCommand cmd2 = new SqlCommand();
                cmd2.Connection = cnn;
                cmd2.CommandTimeout = 0;
                cmd2.Parameters.Clear();
                //cmd.CommandType = CommandType.StoredProcedure;
                cmd2.CommandText = "EXEC PR_PORT_DATA2 @DT1 , @DT2 ,@SEL ";
                cmd2.Parameters.Add(new SqlParameter("DT1", vSelstr)); //日期yyyymmdd
                cmd2.Parameters.Add(new SqlParameter("DT2", vSelstr)); //日期yyyymmdd
                cmd2.Parameters.Add(new SqlParameter("SEL", '1')); //日期yyyymmdd                   
                //2.轉出csv檔案至指定目錄
                SqlDataReader reader2;
                reader2 = cmd2.ExecuteReader();
                DataTable F19DT = new DataTable();
                F19DT.Load(reader2);
                SaveToCSV(F19DT, path_);
                F19DT.Dispose();
                reader2.Dispose();
                cmd2.Dispose();
                Application.DoEvents();

                WriteToListbox("[" + vDt + "] 股債基csv完成!!");

                this.Cursor = Cursors.Default;
            }
            else
            {
                WriteToListbox("[" + vDt + "] 資料庫連結失敗,請查明原因!!");
            }
            return 0;
        }

        //產生BBG-PORT檔案美債
        private int ExpertBND_csv(String vDt)
        {
            String path_ = @"D:\BBU\TWL_BND.csv";
            cnn.Close();
            cnn.Open();
            if (cnn != null && cnn.State == ConnectionState.Open)
            {
                // 執行轉檔
                String vSelstr;
                vSelstr = vDt ;

                this.Cursor = Cursors.WaitCursor;
                ConnectSQL(vDt, "PDB");
                //1.組合債的資料產生-Bryan
                SqlCommand cmd3 = new SqlCommand();
                cmd3.Connection = cnn;
                cmd3.CommandTimeout = 0;
                cmd3.Parameters.Clear();
                //cmd.CommandType = CommandType.StoredProcedure;
                cmd3.CommandText = "EXEC PR_PORT_DATA1 @DT1 , @DT2 ,@SEL ";
                cmd3.Parameters.Add(new SqlParameter("DT1", vSelstr)); //日期yyyymmdd
                cmd3.Parameters.Add(new SqlParameter("DT2", vSelstr)); //日期yyyymmdd
                cmd3.Parameters.Add(new SqlParameter("SEL", '1')); //日期yyyymmdd

                //2.轉出csv檔案至指定目錄
                SqlDataReader reader3;
                reader3 = cmd3.ExecuteReader();
                DataTable F19DT = new DataTable();
                F19DT.Load(reader3);
                SaveToCSV(F19DT, path_);
                F19DT.Dispose();
                reader3.Dispose();
                cmd3.Dispose();
                Application.DoEvents();
                WriteToListbox("[" + vDt + "] 債券csv完成!!");
                this.Cursor = Cursors.Default;
            }
            else
            {
                WriteToListbox("[" + vDt + "] 資料庫連結失敗,請查明原因!!");
            }
            return 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ExpertBEM_csv(textBox2.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ExpertBND_csv(textBox2.Text);
        }


        private void TRANS_BALANCE_DATA(String vDt)
        {
            
            if (database_ora != "來源資料庫")
            {
                this.Cursor = Cursors.WaitCursor;
                WriteToListbox("[" + vDt + "] 庫存轉檔開始!!");
                // 執行轉檔-收集每日庫存資料
                String vSelstr;
                vSelstr = vDt;
                String vSel = "";

                for (int i = 0; i <= cl_BAL.Items.Count - 1; i++)
                {

                    if (cl_BAL.GetItemChecked(i))
                    {
                        if (cl_BAL.Items[i].ToString().IndexOf(":", 0) > -1)
                        {
                            vSel = cl_BAL.Items[i].ToString().Substring(0, cl_BAL.Items[i].ToString().IndexOf(":", 0));
                            Application.DoEvents();
                            try
                            {
                                
                                if (vSel.Substring(0, 3) == "SW.") //轉檔DB
                                {
                                    ConnectSQL(vDt, "BSDATA");
                                    StartExport(vSelstr, vSel);
                                }
                                else if (vSel.Substring(0, 3) != "SW.") //MSSQL庫存處理
                                {
                                    if (vSel == "C01" || vSel == "C02")
                                    {
                                        StartSP_BTSR402(vSelstr, vSel);
                                    }
                                    else if (vSel == "D01" || vSel == "D02")
                                    {
                                        StartSP_BTSR308(vSelstr, vSel);
                                    }
                                    else if (vSel == "B03")
                                    {
                                        StartSP_BTSR753(vSelstr, vSel);
                                    }
                                    else if (vSel == "C03")
                                    {
                                        StartSP_BTSR453(vSelstr, vSel);
                                    }
                                    else if (vSel == "D03")
                                    {
                                        StartSP_BTSR354(vSelstr, vSel);
                                    }
                                    else if (vSel == "B11" || vSel == "B12")
                                    {
                                        StartSP_BTSR712(vSelstr, vSel);
                                    }
                                    else if (vSel == "B13" || vSel == "B14" || vSel == "B15" || vSel == "B16")
                                    {
                                        StartSP_BTSR719(vSelstr, vSel);
                                    }
                                    else
                                    {
                                        if (cnn != null && cnn.State == ConnectionState.Open)
                                        {
                                            SqlCommand cmd1 = new SqlCommand();
                                            cmd1.Connection = cnn;
                                            cmd1.CommandTimeout = 0;
                                            cmd1.Parameters.Clear();
                                            cmd1.CommandText = "EXEC PRC_LINKSERVER_ETL_GA @DT ,@SEL ";
                                            cmd1.Parameters.Add(new SqlParameter("DT", vSelstr)); //日期yyyymmdd
                                            cmd1.Parameters.Add(new SqlParameter("SEL", vSel)); //類別
                                            cmd1.ExecuteNonQuery();
                                            Application.DoEvents();
                                            Delay(int.Parse(textBox1.Text));
                                            cmd1.Dispose();
                                        }
                                        else
                                        {
                                            WriteToListbox("[" + vDt + "] 資料庫連結 失敗,請查明原因!!");
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(vSel + " " + ex.Message);
                                this.Cursor = Cursors.Default;
                            }
                        }
                    }
                }
                WriteToListbox("[" + vDt + "] 庫存轉檔完成!!");
                this.Cursor = Cursors.Default;
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TRANS_BALANCE_DATA(textBox2.Text);
        }

        private void FTP_TO_BBG(String vDt)
        {
            //執行 sFTP bat至Bloomberg FTP Site
            WriteToListbox("[" + vDt + "] BBU傳送開始!!");
            String command_ = @"D:\BBU\upBBU.bat";
            System.Diagnostics.Process.Start(command_);
            WriteToListbox("[" + textBox2.Text + "] BBU傳送完成!!");
            Application.DoEvents();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FTP_TO_BBG(textBox2.Text); //傳送
        }


        private void timer1_Tick(object sender, EventArgs e)
        {

            String vTime = "" ;
            String sTime = tb_sTime.Text.Trim() ;
            String sTime1 = tb_sTime1.Text.Trim();
            String sTime2 = tb_sTime2.Text.Trim();
            vTime = DateTime.Now.Hour.ToString("00") + DateTime.Now.Minute.ToString("00") + DateTime.Now.Second.ToString("00");
            toolStripStatusLabel1.Text = DateTime.Now.ToString();
            toolStripStatusLabel2.Text = vTime;


            if (toolStripDropDownButton1.Text != "來源資料庫")
            {
                if (sTime.Equals(vTime) || sTime1.Equals(vTime) || sTime2.Equals(vTime))
                {
                    if (vFlagTime == "F")
                    {
                        vFlag = "F";
                        vFlagTime = "T";
                        ConnectSQL(textBox2.Text,"PDB");
                        ConnectORA(textBox2.Text);
                        Do_Daily_Todo(textBox2.Text);
                        DisconnectSQL(textBox2.Text);
                        DisconnectORA(textBox2.Text);
                        WriteToListbox("[" + textBox2.Text + "] ========END=======");
                    }
                }
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            if (this.WindowState == FormWindowState.Normal)
            {
                this.notifyIcon1.Visible = false ;
            }
        }

        private void F_DailyForm_SizeChanged(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.notifyIcon1.Visible = true;
                //this.Hide();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            WriteToListbox("[" + textBox2.Text + "] TEST");
        }

        private void label1_DoubleClick(object sender, EventArgs e)
        {
            if (label6.Visible)
            {
                label6.Visible = false;
            }
            else
            {
                label6.Visible = true;
            }

            if (textBox3.Visible)
            {
                textBox3.Visible = false;
                listBox2.Items.Clear();
            }
            else
            {
                textBox3.Visible = true;
            }
        }

        private void cb_PROC_CheckedChanged(object sender, EventArgs e)
        {
            // 全選與全不選
            for (int i = 0; i <= cl_PROC.Items.Count - 1; i++)
            {
                cl_PROC.SetItemChecked(i, cb_PROC.Checked);
            }
        }

        private void cb_BAL_CheckedChanged(object sender, EventArgs e)
        {
            // 全選與全不選
            for (int i = 0; i <= cl_BAL.Items.Count - 1; i++)
            {
                cl_BAL.SetItemChecked(i, cb_BAL.Checked);
            }
        }

        private void Do_Daily_Todo(String vDt)
        {
            this.Cursor = Cursors.WaitCursor;
            //button1_Click(null, null);
            for (int i = 0; i <= (cl_PROC.Items.Count - 1); i++)
            {
                switch (i)
                {
                    case 0:
                        if (cl_PROC.GetItemChecked(i))
                        { TRANS_BALANCE_DATA(vDt); }
                    //button5_Click(null, null);
                    break;
                    case 1:
                        if (cl_PROC.GetItemChecked(i))
                        { ExpertBEM_csv(vDt); }
                        //button3_Click(null, null);
                        
                        break;
                    case 2:
                        //button4_Click(null, null);
                        if (cl_PROC.GetItemChecked(i))
                        { ExpertBND_csv(vDt); }                        
                        break;
                    case 3:
                        if (cl_PROC.GetItemChecked(i))
                        { FTP_TO_BBG(vDt); }//傳送
                        //button6_Click(null, null);
                        break;
                }
            }

            //判斷在定時轉檔時,不會在短時間內多跑很多次的開關標記
            vFlagTime = "F"; 
            this.Cursor = Cursors.Default;
        }

        private void button2_Click(object sender, EventArgs e)
        {
                ConnectSQL("", "PDB");
                ConnectORA(textBox2.Text);
                vFlag = "F";
                Do_Daily_Todo(textBox2.Text);

                textBox2.Text = DT_adj();
                //if (listBox2.Items.IndexOf(textBox2.Text) == -1)
                //{
                //    listBox2.Items.Add(textBox2.Text);
                //    if (listBox2.Items.Count > 0)
                //    {
                //        listBox2.Items.RemoveAt(0);
                //    }
                //}
                vFlag = "T";
                DisconnectSQL(textBox2.Text);
                DisconnectORA(textBox2.Text);
                WriteToListbox("[" + textBox2.Text + "] ========END=======");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Reload_CheckList();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //button1_Click(null, null);
            //OracleCommand OraComm = new OracleCommand();
            //OraComm.Connection = cnn_ora;

            //OraComm.CommandType = CommandType.StoredProcedure;
            //OraComm.CommandText = "SW.BTSR308_P02";
            //OraComm.Parameters.Clear();
            //OraComm.Parameters.Add(new OracleParameter("xTR_DATE", "20171020"));
            //OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE1", "0"));
            //OraComm.Parameters.Add(new OracleParameter("xPORTFOLIO_CODE2", "z"));
            //OraComm.Parameters.Add(new OracleParameter("xDESK_CODE1", "0"));
            //OraComm.Parameters.Add(new OracleParameter("xDESK_CODE2", "z"));
            //OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT1", "0"));
            //OraComm.Parameters.Add(new OracleParameter("xFUND_UNIT2", "z"));
            //OraComm.Parameters.Add(new OracleParameter("xREP_TYPE", "0")); //--0.國內投資 1.國外投資
            //OraComm.Parameters.Add(new OracleParameter("XSUM_TOTAL", "N")); //是否顯示小計
            //OraComm.Parameters.Add(new OracleParameter("XSUM_PORTFOLIO", "Y")); //是否顯示資產區隔(交易平台)
            //OraComm.Parameters.Add(new OracleParameter("XSUM_TYPE", "N")); //是否顯示債券小計
            //OraComm.Parameters.Add(new OracleParameter("XINC_ZERO", "N")); //是否顯示零庫存資料
            //OraComm.Parameters.Add(new OracleParameter("XTRADER_ID", " ")); //交易員代碼
            //OraComm.ExecuteNonQuery();

            //String vDt = "20171020";
            //String vSOURCE_ = "308-台幣債券";
            //String TableName = "BTSR308TMP2";
            //String SQLstr = "'" + vDt + "'"+"as DATE_ ,'"+ vSOURCE_ + "' as SOURCE_ ";

            //OracleCommand OraComm1 = new OracleCommand();
            //OraComm1.Connection = OraComm.Connection ;
            //OraComm1.CommandType = CommandType.Text;
            //OraComm1.CommandText = "SELECT "+ SQLstr + ", SW."+ TableName + ".* FROM SW."+ TableName;
            ////OraComm1.CommandText = "SELECT SW." + TableName + ".* FROM SW." + TableName;
            //OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm1);

            //DataSet OraDataSet = new DataSet();
            //OraDataSet.Clear();
            //oraDataadapter.Fill(OraDataSet, TableName);

            //if (OraDataSet.Tables[0].Rows.Count > 0)
            //{
            //    //刪除SQL BTSR308TMP2 當日資料
            //    SqlCommand sqlComm = new SqlCommand();
            //    sqlComm.Connection = cnn;
            //    sqlComm.CommandText = "DELETE FROM BTSR308TMP2 WHERE DATE_ = '" + vDt + "' AND SOURCE_ = '" + vSOURCE_ + "' ";
            //    sqlComm.ExecuteNonQuery();

            //    // 大量寫入庫存
            //    SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
            //    sqlbulkcopy.BatchSize = 10000;
            //    sqlbulkcopy.DestinationTableName = TableName;
            //    sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
            //    MessageBox.Show(OraDataSet.Tables[0].Rows.Count.ToString() + ")轉檔完成!!");
            //    //WriteToListbox("[" + textBox2.Text + "] ORA-" + TableName + "(" + OraDataSet.Tables[0].Rows.Count.ToString() + ")轉檔完成!!");
            //    Application.DoEvents();
            //}
            //else
            //{
            //    MessageBox.Show(OraDataSet.Tables[0].Rows.Count.ToString() + ")轉檔完成!!");
            //}
                       
        }

        private void listBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (listBox2.SelectedIndex != -1)
                {
                    listBox2.Items.RemoveAt(listBox2.SelectedIndex);
                }                
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox2.Text.Trim() != "")
                {
                    if (listBox2.Items.IndexOf(textBox2.Text) == -1)
                    {
                        listBox2.Items.Add(textBox2.Text);
                    }
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            vFlag = "F";
            ConnectSQL("","BSDATA");
            ConnectORA("");
            for (int k = 0; k <= listBox2.Items.Count - 1; k++)
            {
                Do_Daily_Todo(listBox2.Items[k].ToString() );
                vFlag = "T";
            }
            DisconnectSQL("");
            DisconnectORA("");
            WriteToListbox("[] ========END=======");
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            toolStripDropDownButton1.Text = ((ToolStripMenuItem)sender).Text;
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            DateTime dts,dtrun , dte;
            String dtstr;
            dtstr = "";
            if (e.KeyCode == Keys.Enter)
            {
                listBox2.Items.Clear();
                dts = DateTime.ParseExact(textBox2.Text, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture);
                dte = DateTime.ParseExact(textBox3.Text, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture);
                dtrun = dts;

                //產生日期列表至 listBox2 
                while (dtrun <= dte)
                {                    
                    if (dtrun.DayOfWeek != DayOfWeek.Saturday && dtrun.DayOfWeek != DayOfWeek.Sunday)
                    {
                        dtstr = dtrun.Year.ToString("0000") + dtrun.Month.ToString("00") + dtrun.Day.ToString("00");
                        listBox2.Items.Add(dtstr);
                    }
                    //加一天
                    dtrun = dtrun.AddDays(1);
                }
            }
        }

    }
}
