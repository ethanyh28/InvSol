﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CMADODB5;
using ExtensionMethods;
using System.Runtime.InteropServices;
using System.IO;

namespace CM_TRANS
{
    public partial class F_MAIN : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        // TODO 變數宣告

        // default 為由啟動程式自動轉檔變數 1:自動 else not 
        private String _args;

        //INI 設定檔資訊
        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath + "\\InvestPG.ini";
        StringBuilder data = new StringBuilder(255);


        private CMADODB5.CMConnection cmCnn = new CMConnection();

        //MSSQL connection string 
        string connectionString = null;
        public SqlConnection cnn;
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";
        string Str_err = "";

        SqlCommand cmd;
        string sql = null;

        //MSSQL 連結參數
        private void setSQL_info()
        {
            //組合資料庫 MSSQL
            database_ = "INVEST";

            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 ";
        }

        //MSSQL 資料庫連結
        private void Connect_MSSQL()
        {

            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            cnn.Open();
        }

        public F_MAIN(string value)
        {
            InitializeComponent();
            if (!string.IsNullOrEmpty(value))
            {
                _args = value;
            }

            setSQL_info();
            Connect_MSSQL();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Str_SQL, yyyy, DestinationTableName;

            try
            {
                yyyy = DateTime.Now.ToString("yyyy");
                DestinationTableName = "";
                DataTable dt = null;
                //有4種類公司:1.上市/2.上櫃/3.興櫃/4.公發,依年度不同更新
                Str_SQL = "";
                textBox1.AppendText(DateTime.Now.ToString("yyyyMMdd") + "擷取資料開始..." + Environment.NewLine);
                for (int i = 1; i <= 4; i++)
                {
                    switch (i)
                    {
                        case 1:
                            Str_SQL = "SELECT 股票代號 as '代號',公司名稱,統一編號,getdate() FROM  上市櫃公司基本資料 WHERE 年度 = " + yyyy + " AND 上市上櫃 = 1 ORDER BY 股票代號";
                            DestinationTableName = "上市$";
                            break;
                        case 2:
                            Str_SQL = "SELECT 股票代號 as '代號',公司名稱,統一編號,getdate() FROM  上市櫃公司基本資料 WHERE 年度 = " + yyyy + " AND 上市上櫃 = 2 ORDER BY 股票代號";
                            DestinationTableName = "上櫃$";
                            break;
                        case 3:
                            Str_SQL = "SELECT 代號,公司名稱,統一編號,getdate() FROM  興櫃基本資料 WHERE 年度 = " + yyyy + " ORDER BY 代號";
                            DestinationTableName = "興櫃$";
                            break;
                        case 4:
                            Str_SQL = "SELECT 代號,公司名稱,統一編號,getdate() FROM  公開發行基本資料 WHERE 年度 = " + yyyy + " ORDER BY 代號";
                            DestinationTableName = "公發$";
                            break;
                    }

                    ADODB.Recordset rs = new ADODB.Recordset();
                    rs = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver

                    textBox1.AppendText(DestinationTableName + "資料筆數:"
                                 + rs.RecordCount.ToString() + " "
                                 //+ rs.Fields["代號"].Value + " "
                                 + rs.Fields["公司名稱"].Value + " "
                                 + rs.Fields["統一編號"].Value + " "
                                 + Environment.NewLine);

                    //Recordset to adapter to Datatable
                    dt = new DataTable();
                    dt.TableName = "tmp";
                    System.Data.OleDb.OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
                    adapter.Fill(dt, rs);

                    //刪除資料庫資料
                    SqlCommand sqlComm = new SqlCommand();
                    sqlComm.Connection = cnn;
                    sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 ";
                    sqlComm.ExecuteNonQuery();

                    //批量寫入資料mssql
                    //3. 使用 sqlBulkCopy寫入 SQL資料表
                    using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                    {
                        //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                        bcp.BatchSize = 100; //每次傳輸行數
                        bcp.NotifyAfter = 100; //進度提示的行數
                        bcp.DestinationTableName = DestinationTableName; //目標table 
                        bcp.WriteToServer(dt); //轉寫入MSSQL
                    }
                    sqlComm.Dispose();
                    dt.Dispose();
                    rs.Close();
                }
                textBox1.AppendText(DateTime.Now.ToString("yyyyMMdd") + "擷取資料結束..." + Environment.NewLine);
            }
            catch (Exception ex)
            {
                textBox1.AppendText("錯誤:" + ex.Message  + Environment.NewLine);
                this.Cursor = Cursors.Default;
            }
        }

        private void F_MAIN_Shown(object sender, EventArgs e)
        {
            this.Text = this.Text + "-" + _args;
            if (_args == "1")
            {
                button1.PerformClick();
                this.Close();
            }
        }
    }
}
