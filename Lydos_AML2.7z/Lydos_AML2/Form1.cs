﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Net;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Xml.Linq;
using System.Data.SqlClient;
using ExtensionMethods;
using System.Diagnostics;


namespace Lydos_AML2
{
    public partial class Form1 : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        //INI 設定檔資訊
        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath + "\\Lydos_AML2.ini";
        string dirstr1 = "";

        StringBuilder data = new StringBuilder(255);
        // 判斷是正式區或UAT的 endpoint
        String endpoint_env = "";
        String Appcode_env = "";
        String Unit_env = "";

        // default 為由資料庫轉入
        private String _args ;
        
        //MSSQL connection string 
        string connectionString = null;

        public SqlConnection cnn;
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";

        string loguser_ = Environment.UserName;

        SqlCommand cmd;

        //MSSQL 連結參數
        private void setSQL_info()
        {
            database_ = "INVEST";
            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 ";
        }

        //MSSQL 資料庫連結
        private void Connect_MSSQL()
        {

            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            cnn.Open();
        }

        // exe 無參數
        public Form1()
        {
            InitializeComponent();
            toolStripStatusLabel1.Text = "";
            toolStripStatusLabel2.Text = "";
            toolStripStatusLabel3.Text = "";
            timer1.Enabled = true;
            folderBrowserDialog1.SelectedPath = txt_foldername1.Text;            
            dateTimePicker2.Value = DateTime.Now;
            maskedTextBox4.Text = DateTime.Now.AddDays(0).ToString("yyyyMMdd");
            //if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
            //{
            //    maskedTextBox4.Text = DateTime.Now.AddDays(-3).ToString("yyyyMMdd");
            //}
            //else
            //{
            //    maskedTextBox4.Text = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
            //}

            //指定endpoint環境
            GetPrivateProfileString("ENDPOINT_ENV", "ENV", "", data, 255, dirstr);
            endpoint_env = data.ToString();

            //指定傳送參數-來源應用
            GetPrivateProfileString("ENDPOINT_ENV", "vAppcode", "", data, 255, dirstr);
            Appcode_env = data.ToString();

            //指定傳送參數-來源部門
            GetPrivateProfileString("ENDPOINT_ENV", "vUnit", "", data, 255, dirstr);
            Unit_env = data.ToString();

            //指定傳送參數-預設檢測檔案路徑
            GetPrivateProfileString("PATH-DEFAULT", "FILE", "", data, 255, dirstr);
            txt_foldername1.Text = data.ToString();

            _args = "0";
        }

        //傳入 exe 參數
        public Form1(string value)
        {
            InitializeComponent();

            if (!string.IsNullOrEmpty(value))
            {
                _args = value;
            }

            toolStripStatusLabel1.Text = "";
            toolStripStatusLabel2.Text = "";
            toolStripStatusLabel3.Text = "";
            timer1.Enabled = true;
            folderBrowserDialog1.SelectedPath = txt_foldername1.Text;            
            dateTimePicker2.Value = DateTime.Now;
            maskedTextBox4.Text = DateTime.Now.AddDays(0).ToString("yyyyMMdd");
            //if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
            //{
            //    maskedTextBox4.Text = DateTime.Now.AddDays(-3).ToString("yyyyMMdd");
            //}
            //else
            //{
            //    maskedTextBox4.Text = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
            //}

            //指定endpoint環境
            GetPrivateProfileString("ENDPOINT_ENV", "ENV", "", data, 255, dirstr);
            endpoint_env = data.ToString();

            //指定傳送參數-來源應用
            GetPrivateProfileString("ENDPOINT_ENV", "vAppcode", "", data, 255, dirstr);
            Appcode_env = data.ToString();

            //指定傳送參數-來源部門
            GetPrivateProfileString("ENDPOINT_ENV", "vUnit", "", data, 255, dirstr);
            Unit_env = data.ToString();

            //指定傳送參數-預設檢測檔案路徑
            GetPrivateProfileString("PATH-DEFAULT", "FILE", "", data, 255, dirstr);
            txt_foldername1.Text = data.ToString();

        }

        //建立xml 結點
        public void CreateNode(XmlDocument xmldoc, XmlNode parentnode, string name, string attribute , string value)
        {
            XmlNode node = xmldoc.CreateNode(XmlNodeType.Element, name, null);
            parentnode.AppendChild(node);

            //Create a new attribute
            if (attribute != "")
            {
                XmlAttribute attr = xmldoc.CreateAttribute("Name");
                attr.Value = attribute;
                node.Attributes.SetNamedItem(attr);
            }
            node.InnerText = value;
        }

        //xmldox to str 轉換
        public string xmldoc2Str(XmlDocument xmlDoc)
        {
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter tx = new XmlTextWriter(sw))
                {
                    xmlDoc.WriteTo(tx);
                    string strXmlText = sw.ToString();
                    return strXmlText;
                }
            }
        }

        //產生XML
        private string GEN_XMLDOC(string vCalltype , string vFmt, string  vUsercode, string vUserdata, string vCINO, string vFIELD_Name, string vFIELD_enName,string vprimNat)
        {
            String vAppcode, vUnit, vMessageID ;
            String Sender_str = "";


            vAppcode = Appcode_env; // "GA";
            vUnit = Unit_env;//"INV00";
            //vCalltype = "CIFC";
            vMessageID = "INV4" + System.DateTime.Now.ToString(@"yyyyMMddHHmmss");
            //vFmt = "COPCIF";
            //vUsercode = "";
            //vUserdata = "002523";
            //vCINO = "A111000";
            //vFIELD_Name = "博暉科技股份有限公司";
            //vFIELD_enName = "博暉科技股份有限公司";

            //轉換特殊字元 &
            vFIELD_Name = vFIELD_Name.Replace("&", "&amp;");
            vFIELD_enName = vFIELD_enName.Replace("&", "&amp;");

            XNamespace soapenv = "http://schemas.xmlsoap.org/soap/envelope/";
            XNamespace web = "http://webservice.lyods.com/";
            XElement Envelope = new XElement(soapenv + "Envelope",
                new XAttribute(XNamespace.Xmlns + "soapenv", "http://schemas.xmlsoap.org/soap/envelope/"),
                new XAttribute(XNamespace.Xmlns + "web", "http://webservice.lyods.com/"),
                new XElement(soapenv + "Header"),
                new XElement(soapenv + "Body",
                    new XElement(web + "FofExecCif",
                        new XElement("appCode", vAppcode),
                        new XElement("unit", vUnit),
                        new XElement("callType", vCalltype),
                        new XElement("messageId", vMessageID),
                        new XElement("fmt", vFmt),
                        new XElement("usercode", vUsercode),
                        new XElement("userdata", vUserdata),
                        new XElement("calc", "0"),
                        new XElement("isFull", "true"),
                        new XElement("sendTime", System.DateTime.Now.ToString(@"yyyy-MM-dd HH:mm:ss")),
                        new XElement("xml",
                            new XElement("CDATA",
                                new XElement("cif",
                                    new XElement("CINO", vCINO+"-投資一處"),
                                    new XElement("FIELD", vFIELD_Name,
                                        new XAttribute("name", "Name")
                                    ),
                                    new XElement("FIELD", vFIELD_enName,
                                        new XAttribute("name", "enName")
                                    ),
                                    new XElement("FIELD", vprimNat,
                                        new XAttribute("name", "primNat") //註冊國3碼
                                    )
                                ) //cif
                            )//CDATA
                        )
                    )
                )
            );

            //調整CDATA 標籤
            Sender_str = Envelope.ToString();
            Sender_str = Sender_str.Replace("<CDATA>", "<![CDATA[");
            Sender_str = Sender_str.Replace("</CDATA>", "]]>");
            //MessageBox.Show(Sender_str);
            Sender_str = WebUtility.HtmlDecode(Sender_str);
            //textBox2.AppendText("XML轉換中..." + Environment.NewLine);
            return Sender_str;
        }

        //傳送 requet xml to webservice & get response xml
        private string Send_Request(string send_str)
        {
            string responseString = ""; 
            try
            {
                //textBox2.AppendText("傳送中...." + Environment.NewLine);
                string endpoint = "";

                if (endpoint_env == "PRO")
                {
                    //正式區
                    endpoint = @"http://10.174.5.103:7001/LyodsAMLTWL/ws/FSKWS?wsdl";                    
                }
                else if (endpoint_env == "UAT")
                {
                    //UAT
                    endpoint = @"http://10.174.4.69:7001/LyodsAMLTWL/ws/FSKWS?wsdl";
                }               

                //讀取 request message
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(send_str);

                //ASCIIEncoding encoding = new ASCIIEncoding();
                UTF8Encoding encoding = new UTF8Encoding(); //中文字判讀編碼 對應 charset=utf-8

                string postData = doc.OuterXml;
                //string postData = "950";
                //MessageBox.Show(postData);
                textBox3.Text = postData;

                byte[] data = encoding.GetBytes(postData);
                
                // HTTP POST 請求物件
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(endpoint);
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/soap+xml;charset=utf-8";  //charset=big5
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //textBox2.AppendText("傳送查詢完成!" + Environment.NewLine);
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                //responseString = WebUtility.HtmlDecode(responseString);

                //textBox2.Clear();
                //textBox2.Text = responseString;                
                //textBox2.AppendText("回訊取得完成!" + Environment.NewLine);
            }
            catch (Exception ex)
            {
                responseString = "";
                textBox2.AppendText(ex.Message + Environment.NewLine);
                //MessageBox.Show(ex.Message);
            }
            return responseString;
        }

        //Parser 回訊
        private List<string> Parser_Reponse(string respone_str)
        {
            String match_str = "";
            respone_str = WebUtility.HtmlDecode(respone_str);

            // 利用 RegulareExpression 擷取所要的資訊
            List<String> lists = new List<string>(); //tag name
            List<String> lists_field = new List<string>(); //tag name
            lists.Add("SendTime");
            lists.Add("RetCode");
            lists.Add("ErrMsg");
            lists.Add("HitCount");
            lists.Add("DecType");
            lists.Add("DecState");
            lists.Add("DecDate");
            lists.Add("DecBy");
            lists.Add("DecComments");

            for (int j = 0; j <= lists.Count - 1; j++)
            {

                Match match = Regex.Match(respone_str, @"<" + lists[j] + ">[\\S\\s ]+</" + lists[j]+">");
                if (!match.Success)
                {
                    //MessageBox.Show(lists[j] + "=\"\"");
                    lists_field.Add(lists[j] + "=");
                }
                else
                {
                    for (int i = 0; match.Success; i++)
                    {
                        //MessageBox.Show(match.Groups[i].Value);
                        match_str = match.Groups[i].Value;
                        match_str = match_str.Replace("</"+ lists[j] + ">", "");
                        match_str = match_str.Replace("<", "");
                        match_str = match_str.Replace(">", "=");
                        //MessageBox.Show(match_str);
                        lists_field.Add(match_str);
                        match = match.NextMatch();
                    }
                }                
            }           
            return lists_field ;
        }

        //傳送查詢 button
        private void button4_Click(object sender, EventArgs e)
        {
            String vAppcode, vUnit, vCalltype, vMessageID, vFmt, vUsercode, vUserdata, vCINO, vFIELD_Name, vFIELD_enName,vprimNat,vDate_ ;
            String request_str = "";
            String respones_str = "";
            String respones_str2 = "";
            String targetTb = "Lydos_Daily_Check";
            DateTime sTime, eTime ;
            int Hit_cnt = 0;
            int San_cnt = 0;
            int ls_b = 0;
            List<String> ls_san = new List<string>();
            TimeSpan ts;
            

            this.Cursor = Cursors.WaitCursor;
            if (_args == "0" && listBox1.Items.Count == 0)
            {
                MessageBox.Show("請輸入待檢測對象!!");
            }
            else
            {
                //連結資料庫
                setSQL_info();
                Connect_MSSQL();

                toolStripStatusLabel3.Text = "";
                vAppcode = Appcode_env; // "GA";
                vUnit = Unit_env;//"INV00";
                vCalltype = "CIFC"; //CIFI:個人客戶 ; CIFC:公司客戶
                vMessageID = "INV4_" + System.DateTime.Now.ToString(@"yyyyMMddHHmmss");
                vFmt = "COPCIF"; //PRVCIF:個人客戶上傳 ; COPCIF:公司客戶上傳
                vUsercode = "";
                if (_args == "1" || _args == "2")
                {
                    vUserdata = "002523";
                }
                else
                {
                    vUserdata = loguser_;
                }
                vprimNat = "";

                //宣告一個 DataTABLE
                DataTable s_Datatb = new DataTable();

                //創建欄位抬頭
                List<String> ls_Col = new List<string>();
                ls_Col.Add("CINO");
                ls_Col.Add("FIELD_Name");
                ls_Col.Add("FIELD_enName");
                ls_Col.Add("primNat");
                ls_Col.Add("SendTime");
                ls_Col.Add("RetCode");
                ls_Col.Add("ErrMsg");
                ls_Col.Add("HitCount");
                ls_Col.Add("DecType");
                ls_Col.Add("DecState");
                ls_Col.Add("DecDate");
                ls_Col.Add("DecBy");
                ls_Col.Add("DecComments");

                for (int cc = 0; cc < ls_Col.Count; cc++)
                {
                    s_Datatb.Columns.Add(ls_Col[cc], typeof(String));
                }
                s_Datatb.Columns.Add("Date_", typeof(String));
                s_Datatb.Columns.Add("MessageID", typeof(String));
                s_Datatb.Columns.Add("loguser_", typeof(String));
                s_Datatb.Columns.Add("logdate_", typeof(String));
                s_Datatb.Columns.Add("chkdate_", typeof(String));

                toolStripProgressBar1.Value = 0;
                if (_args == "1" || _args == "2")
                {
                    //寫入 DataTABLE Row -- 來源資料庫
                    DataSet ds = new DataSet();
                    Application.DoEvents();
                    string sql;
                    sql = "EXEC sp_Lydos_ISSUSER @dt ";
                    cmd = new SqlCommand(sql, cnn);
                    cmd.CommandTimeout = 10000;
                    cmd.Parameters.Add(new SqlParameter("dt", maskedTextBox4.Text));
                    //cmd.ExecuteReader();
                    SqlDataAdapter dt = new SqlDataAdapter();
                    dt.SelectCommand = cmd;
                    dt.Fill(ds);

                    toolStripProgressBar1.Maximum = ds.Tables[0].Rows.Count;
                    listBox1.Items.Clear();
                    for (ls_b = 0; ls_b <= ds.Tables[0].Rows.Count - 1; ls_b++)
                    //for (ls_b = 0; ls_b <= 5 - 1; ls_b++)
                    {
                        toolStripProgressBar1.Value = ls_b + 1;

                        //同步寫入 listbox
                        listBox1.Items.Add(ds.Tables[0].Rows[ls_b]["BRK_CHNNM"].ToString() + "," +
                                           ds.Tables[0].Rows[ls_b]["BRK_ENGNM"].ToString() + "," +
                                           ds.Tables[0].Rows[ls_b]["COUNTRY_CD"].ToString());


                        vCINO = ds.Tables[0].Rows[ls_b]["TRAN_BRK"].ToString(); //CINO
                        vFIELD_Name = ds.Tables[0].Rows[ls_b]["BRK_CHNNM"].ToString(); //中文名
                        vFIELD_enName = ds.Tables[0].Rows[ls_b]["BRK_ENGNM"].ToString(); // English name
                        vprimNat = ds.Tables[0].Rows[ls_b]["COUNTRY_CD"].ToString(); // 註冊國
                        vDate_ = ds.Tables[0].Rows[ls_b]["DATE_"].ToString(); //                     

                        DataRow dr = s_Datatb.NewRow();
                        dr["CINO"] = vCINO; //CINO
                        dr["FIELD_Name"] = vFIELD_Name; //FIELD_Name
                        dr["FIELD_enName"] = vFIELD_enName; //FIELD_enName
                        dr["primNat"] = vprimNat; //primNat//註冊國
                        dr["SendTime"] = ""; //SendTime
                        dr["RetCode"] = ""; //RetCode
                        dr["ErrMsg"] = ""; //ErrMsg
                        dr["HitCount"] = ""; //HitCount
                        dr["DecType"] = ""; //DecType
                        dr["DecState"] = ""; //DecState
                        dr["DecDate"] = ""; //DecDate
                        dr["DecBy"] = ""; //DecBy
                        dr["DecComments"] = ""; //DecCommects
                        dr["Date_"] = vDate_; //資料年月日
                        dr["MessageID"] = vMessageID; //MessageID
                        dr["loguser_"] = vUserdata; //
                        dr["logdate_"] = System.DateTime.Now.ToString(@"yyyyMMddHHmmss");  //
                        dr["chkdate_"] = maskedTextBox4.Text;  // 查詢日
                        s_Datatb.Rows.Add(dr);
                    }
                }
                else
                {
                    //寫入 DataTABLE Row -- 來源文字檔
                    toolStripProgressBar1.Maximum = listBox1.Items.Count;
                    for (ls_b = 0; ls_b <= listBox1.Items.Count - 1; ls_b++)
                    {
                        toolStripProgressBar1.Value = ls_b + 1;
                        vCINO = string.Format("{0:D5}", ls_b + 1); //CINO

                        vFIELD_Name = "";
                        vFIELD_enName = "";
                        vprimNat = "";

                        //分析 , 分隔資料

                        string lt_str = listBox1.Items[ls_b].ToString();
                        string[] words = lt_str.Split(',');

                        int lt_index = 0;
                        foreach (var word in words)
                        {
                            switch (lt_index)
                            {
                                case 0:
                                    vFIELD_Name = word.ToString();
                                    break;
                                case 1:
                                    vFIELD_enName = word.ToString();
                                    break;
                                case 2:
                                    vprimNat = word.ToString();
                                    break;
                            }
                            lt_index++;
                        }

                        DataRow dr = s_Datatb.NewRow();
                        dr["CINO"] = vCINO; //CINO
                        dr["FIELD_Name"] = vFIELD_Name; //FIELD_Name
                        dr["FIELD_enName"] = vFIELD_enName; //FIELD_enName
                        dr["primNat"] = vprimNat; //primNat//註冊國
                        dr["SendTime"] = ""; //SendTime
                        dr["RetCode"] = ""; //RetCode
                        dr["ErrMsg"] = ""; //ErrMsg
                        dr["HitCount"] = ""; //HitCount
                        dr["DecType"] = ""; //DecType
                        dr["DecState"] = ""; //DecState
                        dr["DecDate"] = ""; //DecDate
                        dr["DecBy"] = ""; //DecBy
                        dr["DecComments"] = ""; //DecCommects
                        dr["Date_"] = maskedTextBox4.Text; //查詢資料年月日
                        dr["MessageID"] = vMessageID; //MessageID
                        dr["loguser_"] = vUserdata; //
                        dr["logdate_"] = System.DateTime.Now.ToString(@"yyyyMMddHHmmss");  //
                        dr["chkdate_"] = maskedTextBox4.Text;  // 查詢日
                        s_Datatb.Rows.Add(dr);
                    }
                }

                // 查詢公司列表
                textBox2.Clear();
                sTime = System.DateTime.Now;
                Hit_cnt = 0;
                toolStripProgressBar1.Value = 0;
                toolStripProgressBar1.Maximum = s_Datatb.Rows.Count;
                textBox2.AppendText("萊斯批量查詢開始" + s_Datatb.Rows.Count.ToString() + "筆:" + sTime.ToString(@"yyyy-MM-dd HH:mm:ss") + Environment.NewLine);

                for (int k = 0; k <= s_Datatb.Rows.Count - 1; k++)
                {
                    toolStripProgressBar1.Value = k + 1;
                    toolStripStatusLabel3.Text = toolStripProgressBar1.Value.ToString() + "/" + toolStripProgressBar1.Maximum.ToString();
                    Application.DoEvents();
                    vCINO = s_Datatb.Rows[k][0].ToString();
                    vFIELD_Name = s_Datatb.Rows[k][1].ToString();
                    vFIELD_enName = s_Datatb.Rows[k][2].ToString();
                    vprimNat = s_Datatb.Rows[k][3].ToString();

                    if (vFIELD_Name.Trim() != "")
                    {
                        textBox2.AppendText("[" + vCINO + "]" + vFIELD_Name + " 傳送查詢 ***" + Environment.NewLine);
                    }
                    else
                    {
                        textBox2.AppendText("[" + vCINO + "]" + vFIELD_enName + " 傳送查詢 ***" + Environment.NewLine);
                    }

                    if ((vFIELD_Name.Trim() != "") || (vFIELD_enName.Trim() != ""))
                    {
                        //產生 XML request
                        request_str = GEN_XMLDOC(vCalltype, vFmt, vUsercode, vUserdata, vCINO, vFIELD_Name, vFIELD_enName, vprimNat);

                        //傳送 Send_Request 
                        respones_str = Send_Request(request_str);

                        //Parser回訊-特定欄位         
                        List<string> respones_ls = new List<string>();
                        respones_ls = Parser_Reponse(respones_str);

                        //寫入相對應的DataTable 欄位資料
                        respones_str = "";
                        respones_str2 = "";
                        for (int kk = 0; kk <= respones_ls.Count - 1; kk++)
                        {
                            //MessageBox.Show(respones_ls[kk], respones_ls[kk].Substring(respones_ls[kk].IndexOf(respones_ls[kk]+"="),respones_ls[kk].Length));
                            respones_str = respones_str + respones_ls[kk] + ";  ";
                            respones_str2 = respones_ls[kk];
                            if (respones_ls[kk].IndexOf("SendTime") != -1)
                            {
                                s_Datatb.Rows[k][4] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//SendTime
                            }
                            if (respones_ls[kk].IndexOf("RetCode") != -1)
                            {
                                s_Datatb.Rows[k][5] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//RetCode
                            }
                            if (respones_ls[kk].IndexOf("ErrMsg") != -1)
                            {
                                s_Datatb.Rows[k][6] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//ErrMsg
                            }
                            if (respones_ls[kk].IndexOf("HitCount") != -1)
                            {
                                s_Datatb.Rows[k][7] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//HitCount
                                if (s_Datatb.Rows[k][7].ToString() != "0")
                                {
                                    Hit_cnt = Hit_cnt + 1;
                                }
                            }
                            if (respones_ls[kk].IndexOf("DecType") != -1)
                            {
                                s_Datatb.Rows[k][8] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//DecType
                            }
                            if (respones_ls[kk].IndexOf("DecState") != -1)
                            {
                                s_Datatb.Rows[k][9] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//DecState

                                if ((s_Datatb.Rows[k][9].ToString().IndexOf(textBox1.Text) != -1) && (s_Datatb.Rows[k][8].ToString().IndexOf(textBox4.Text) != -1))
                                {
                                    San_cnt = San_cnt + 1;
                                    if (vFIELD_enName != "")
                                    {
                                        ls_san.Add("[" + vCINO + "]" + vFIELD_Name + "(" + vFIELD_enName + ")" + "(" + vprimNat + ")");
                                    }
                                    else
                                    {
                                        ls_san.Add("[" + vCINO + "]" + vFIELD_Name + "(" + vFIELD_enName + ")" + "(" + vprimNat + ")");
                                    }

                                }
                            }
                            if (respones_ls[kk].IndexOf("DecDate") != -1)
                            {
                                s_Datatb.Rows[k][10] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//DecDate
                            }
                            if (respones_ls[kk].IndexOf("DecBy") != -1)
                            {
                                s_Datatb.Rows[k][11] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//DecBy
                            }
                            if (respones_ls[kk].IndexOf("DecComments") != -1)
                            {
                                s_Datatb.Rows[k][12] = respones_ls[kk].Substring(respones_ls[kk].IndexOf("=") + 1);//DecComments
                            }
                            //MessageBox.Show(s_Datatb.Rows[k][3].ToString() + s_Datatb.Rows[k][3].ToString() );
                        }
                        //回訊轉字串
                        //var message = string.Join(Environment.NewLine, Parser_Reponse(respones_str).ToArray());
                        //respones_str = message ;
                        if (vFIELD_Name.Trim() != "")
                        {
                            textBox2.AppendText("[" + vCINO + "]" + vFIELD_Name + "(" + vprimNat + ")" + ": " + respones_str + Environment.NewLine);
                        }
                        else
                        {
                            textBox2.AppendText("[" + vCINO + "]" + vFIELD_enName + "(" + vprimNat + ")" + ": " + respones_str + Environment.NewLine);
                        }

                    }
                }

                eTime = System.DateTime.Now;
                ts = eTime - sTime;
                textBox2.AppendText("結束查詢耗時:" + ts.TotalSeconds.ToString() + "秒; 完成查詢筆數" + s_Datatb.Rows.Count.ToString() + "; 總命中筆數" + Hit_cnt.ToString() + Environment.NewLine);

                //  若有 SAN 的話,額外表示
                if (San_cnt > 0)
                {
                    textBox2.AppendText("****發現命中狀態:" + textBox1.Text + "共" + San_cnt.ToString() + "筆****" + Environment.NewLine);
                    var message = string.Join(Environment.NewLine, ls_san.ToArray());
                    textBox2.AppendText(message + Environment.NewLine);
                    textBox2.AppendText("****發現命中狀態:" + textBox1.Text + "共" + San_cnt.ToString() + "筆****" + Environment.NewLine);
                }
                else
                {
                    textBox2.AppendText("****無發現新命中狀態為NEW 的SAN名單" + Environment.NewLine);
                }


                //寫入資料庫
                if (_args == "1" || _args == "2")
                {
                    // 刪除來源檔資料
                    SqlCommand sqlComm = new SqlCommand();
                    sqlComm.Connection = cnn;
                    sqlComm.CommandText = "DELETE FROM " + targetTb + " WHERE 1=1  AND Date_ = '" + maskedTextBox4.Text + "' ";
                    sqlComm.ExecuteNonQuery();

                    // 使用 sqlBulkCopy寫入 SQL資料表
                    using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.KeepIdentity))
                    {
                        //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                        bcp.BatchSize = 1000; //每次傳輸行數
                        bcp.NotifyAfter = 1000; //進度提示的行數
                                                // finally write to server
                        bcp.DestinationTableName = targetTb; //目標table 
                        bcp.WriteToServer(s_Datatb); //轉寫入MSSQL 轉入來源與目的欄位數必須相同
                        bcp.Close();
                    }
                }
                textBox2.AppendText(Environment.NewLine);
                s_Datatb.Dispose();
                cnn.Close();
                File.WriteAllText(Application.StartupPath + "\\Lydos_AML2_log.txt", textBox2.Text);
                //開啟檔案
                if (_args == "0")
                {
                    Process.Start(Application.StartupPath + "\\Lydos_AML2_log.txt");
                }
                _args = "0";
                this.Text = "萊斯系統批量查詢-" + _args;
            }
            this.Cursor = Cursors.Default;
        }

        //讀取名單 button
        private void button1_Click(object sender, EventArgs e)
        {

            string Currentpath = "" ;
            Currentpath = txt_foldername1.Text;

            _args = "0";
            try
            {
                if (Currentpath != "")
                {                    
                    List<String> lines = new List<string>();
                    using (StreamReader r = new StreamReader(Currentpath))
                    {
                        string line;
                        listBox1.Items.Clear();
                        while ((line = r.ReadLine()) != null)
                        {
                            listBox1.Items.Add(line);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            String vTime = "";
            //String sTime = tb_sTime.Text.Trim();
            //String sTime1 = tb_sTime1.Text.Trim();
            //String sTime2 = tb_sTime2.Text.Trim();
            vTime = DateTime.Now.Hour.ToString("00") + DateTime.Now.Minute.ToString("00") + DateTime.Now.Second.ToString("00");
            toolStripStatusLabel1.Text = DateTime.Now.ToString();
            toolStripStatusLabel2.Text = vTime;
        }

        //讀檔案 button
        private void button2_Click(object sender, EventArgs e)
        {
            string Currentpath = "";
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                Currentpath = folderBrowserDialog1.SelectedPath.ToString();
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            DateTime vvDt;
            vvDt = ((DateTimePicker)sender).Value;
            maskedTextBox4.Text = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (textBox3.Visible)
            { textBox3.Visible = false; }
            else
            { textBox3.Visible = true;  }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            this.Text = "萊斯系統批量查詢-" + _args;
            if (_args == "2")
            {
                button4.PerformClick();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            _args = "1";
            this.Text = "萊斯系統批量查詢-" + _args;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //寫入預設值回ini
            //指定傳送參數-預設檢測檔案路徑
            WritePrivateProfileString("PATH-DEFAULT", "FILE",txt_foldername1.Text, dirstr);
        }
    }
}


//select DISTINCT t.TRAN_BRK , ISNULL(t.BRK_CHNNM,'')BRK_CHNNM , ISNULL(t.BRK_ENGNM,'')BRK_ENGNM
//from SW.BTS002 t
//JOIN SW.BTS702 t1 on t.TRAN_BRK = t1.ID_NO
//JOIN BTSR753TMP1 t2 on t1.STK_CD = t2.STK_CD
//--WHERE t2.DATE_ = '' AND
//UNION
//select DISTINCT t.TRAN_BRK , ISNULL(t.BRK_CHNNM,'')BRK_CHNNM , ISNULL(t.BRK_ENGNM,'')BRK_ENGNM
//from SW.BTS002 t
//JOIN SW.BTS301 t1 on t.TRAN_BRK = t1.ISU_UNIT
//JOIN BTSR308TMP2 t2 on t1.BD_CD = t2.BD_CD
//WHERE t2.DATE_  = '20181105' AND t2.FACE_AMT >0
//ORDER BY t.TRAN_BRK