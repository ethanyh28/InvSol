﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ExtensionMethods;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using CMADODB5;

using Element = Bloomberglp.Blpapi.Element;
using Event = Bloomberglp.Blpapi.Event;
using Message = Bloomberglp.Blpapi.Message;
using Name = Bloomberglp.Blpapi.Name;
using Request = Bloomberglp.Blpapi.Request;
using Service = Bloomberglp.Blpapi.Service;
using Session = Bloomberglp.Blpapi.Session;
using SessionOptions = Bloomberglp.Blpapi.Session;

using ArrayList = System.Collections.ArrayList;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.IO;

namespace Get_bbg_data2
{
    public partial class Form1 : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        // TODO 變數宣告

        // default 為由啟動程式自動轉檔變數 1:自動 else not 
        private String _args;

        //INI 設定檔資訊
        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath + "\\GET_BBG_Data.ini";
        StringBuilder data = new StringBuilder(255);

        private CMADODB5.CMConnection cmCnn = new CMConnection();

        //MSSQL connection string 
        string connectionString = null;
        public SqlConnection cnn;
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";
        string Str_err = "";

        string Str_SQL, str_stk, v_dateb, v_datee, DestinationTableName;

        SqlCommand cmd;
        string sql = null;

        private ArrayList d_securities; // 標的代號

        //MSSQL 連結參數
        private void setSQL_info()
        {
            //組合資料庫 MSSQL
            database_ = "INVEST";

            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 ";
        }

        //MSSQL 資料庫連結
        private void Connect_MSSQL()
        {

            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            cnn.Open();
        }

        public Form1()
        {

            InitializeComponent();

            _args = "0";
            dateTimePicker2.Value = DateTime.Now;
            maskedTextBox4.Text = DateTime.Now.AddDays(0).ToString("yyyyMMdd");

            this.Text = "CMTRANS-0" ;
            setSQL_info();
        }

        //傳入 exe 參數
        public Form1(string value)
        {
            InitializeComponent();

            _args = "0";
            if (!string.IsNullOrEmpty(value))
            {
                _args = value;
            }
            this.Text = "CMTRANS-" + _args;

            dateTimePicker2.Value = DateTime.Now;
            maskedTextBox4.Text = DateTime.Now.AddDays(0).ToString("yyyyMMdd");

            setSQL_info();
        }

        //寫入Textbox
        public void WriteToTextbox(string Newline)
        {
            textBox3.AppendText(Newline + Environment.NewLine);
            //listBox1.Items.Insert(0, listBox1.Items.Count.ToString("000") + " " + Newline + " " + DateTime.Now.ToString());
        }

        //CMoney 轉檔台美港陸股
        private void CM_Volume_data()
        {
            string Str_SQL, str_stk, v_dateb, v_datee, DestinationTableName="";
            string d_CALC_INTERVAL = "250";
            string cm_table1 = ""; //日收盤還原表排行
            string cm_table2 = ""; //美股上市公司基本資料
            string Str_SQL1 = ""; // SQL no1
            string Str_SQL2 = ""; // SQL no2
            string Str_SQL_DEL = ""; //SQL del 
            string vMarket = ""; //市場別
            try
            {
                Connect_MSSQL();
                v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;

                //讀取台/美/陸／港　股資料


                //vkind= 0.台股;1.美股;2.港股;3.陸股
                for (int vkind = 0; vkind <= 3; vkind++)
                {
                    //
                    //刪除資料庫資料
                    if (vkind == 0)
                    {
                        DestinationTableName = "Local_Volume";
                    }
                    else
                    {
                        DestinationTableName = "Foreign_Volume";
                    }

                    //if (vkind == 0 || vkind == 1)
                    //{
                    //    SqlCommand sqlComm = new SqlCommand();
                    //    sqlComm.Connection = cnn;
                    //    //sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and avg_Day = " + d_CALC_INTERVAL + " and BBG_ID like '% US' and [Data_Date] = " + v_datee;
                    //    sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and [Data_Date] = " + v_datee;
                    //    sqlComm.ExecuteNonQuery();
                    //    sqlComm.Dispose();
                    //}

                    //股市欲查詢標的資料擷取
                    DataSet ds = new DataSet();
                    Application.DoEvents();
                    string sql;
                    sql = "EXEC sp_query_stk @dt ,@kind ";
                    cmd = new SqlCommand(sql, cnn);
                    cmd.CommandTimeout = 10000;
                    cmd.Parameters.Add(new SqlParameter("dt", v_datee));
                    cmd.Parameters.Add(new SqlParameter("kind", vkind　));　//0.台股;1.美股;2.港股;3.陸股
                    //cmd.ExecuteReader();
                    SqlDataAdapter sql_dt = new SqlDataAdapter();
                    sql_dt.SelectCommand = cmd;
                    sql_dt.Fill(ds);

                    int run_cnt = 0;
                    run_cnt = ds.Tables[0].Rows.Count;

                    int cnt_interval = 0; //0:250D or 1:20D 
                    str_stk = "";
                    
                    switch (vkind)
                    {
                        case 0://TW
                            vMarket = "台股";
                            cnt_interval = 0; //0:250D
                            //累積查詢標的
                            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                            {
                                str_stk = str_stk
                                         + "'"
                                         + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString()
                                         + "'";
                                if (ls_b != run_cnt - 1)
                                { str_stk = str_stk + ","; }
                            }
                            break ;

                        case 1://US
                            vMarket = "美股";
                            cnt_interval = 1; //0:250D;1:20D
                            //累積查詢標的
                            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                            {
                                str_stk = str_stk
                                         + "'"
                                         + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString()
                                         + "'";
                                if (ls_b != run_cnt - 1)
                                { str_stk = str_stk + ","; }
                            }
                            break ;

                        case 2://HK
                            vMarket = "港股";
                            cnt_interval = 1; //0:250D;1:20D
                            //累積查詢標的
                            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                            {
                                str_stk = str_stk
                                         + "'"
                                         + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString().Replace("H", "")
                                         + "'";
                                if (ls_b != run_cnt - 1)
                                { str_stk = str_stk + ","; }
                            }
                            break ;

                        case 3://CH
                            DestinationTableName = "Foreign_Volume";
                            vMarket = "陸股";
                            cnt_interval = 1; //0:250D;1:20D
                            //累積查詢標的
                            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                            {
                                str_stk = str_stk
                                         + "'"
                                         + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString().Replace("C", "")
                                         + "'";
                                if (ls_b != run_cnt - 1)
                                { str_stk = str_stk + ","; }
                            }
                            break;
                    }

                    // 讀取250日 & 20日平均成交量資料
                    for (int i1 = 0; i1 <= cnt_interval ; ++i1)
                    {
                        // 0: 250D ; 1:20D 二種天數
                        switch (i1)
                        {
                            case 0:
                                d_CALC_INTERVAL = "250";
                                break;

                            case 1:
                                d_CALC_INTERVAL = "20";
                                break;
                        }

                        switch (vkind)
                        {
                            case 0://TW
                                Str_SQL1 = " declare @T_date as nvarchar(8) "
                                         + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from[日收盤表排行] where 股票代號 = 'twa00' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc ";

                                Str_SQL2 = " declare @T_date as nvarchar(8) "
                                         + " set @T_date = (select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from[日收盤表排行] where 股票代號 = 'twa00' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                                         + " select 股票代號 as 代號 , (股票代號+' TT') as BBG , " + v_datee + " as [Data_Date],  " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG(成交量 * 1.0), 2) as [250日成交均量] from[日收盤表排行] "
                                         + " where 日期 >= @T_date "
                                         + " and 股票代號 in (" + str_stk + ")"
                                         //+ " and 股票代號 in (select 股票代號 from[上市櫃公司基本資料] where 股票代號 in (" + str_stk + ") and 年度 = (select MAX(年度) from[上市櫃公司基本資料] )) "
                                         + " group by 股票代號 "
                                         + " order by 股票代號 asc; ";
                                Str_SQL_DEL = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and SUBSTRING(BBG_ID,charindex(' TT',BBG_ID),3) = ' TT'  and [Data_Date] = " + v_datee;
                                break;

                            case 1://US                                
                                Str_SQL1 = " declare @T_date as nvarchar(8) "
                                         + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from[美股日收盤還原表排行] where 代號 = '#GSPC' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc ";

                                Str_SQL2 = " declare @T_date as nvarchar(8) "
                                         + " set @T_date = (select TOP 1 A.日期 from(select TOP " + d_CALC_INTERVAL + " 日期 from[美股日收盤還原表排行] where 代號 = '#GSPC' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                                         + " select 代號 , (代號+' US') as BBG, " + v_datee + " as [Data_Date], " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG(成交量 * 1.0), 2) as [" + d_CALC_INTERVAL + "日成交均量] from[美股日收盤還原表排行] "
                                         + " where 日期 >= @T_date "
                                         + " and 代號 in (select 代號 from[美股上市公司基本資料] where 代號 in (" + str_stk + ") and 年度 = (select MAX(年度) from[美股上市公司基本資料] )) "
                                         + " group by 代號 "
                                         + " order by 代號 asc; ";
                                Str_SQL_DEL = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and SUBSTRING(BBG_ID,charindex(' US',BBG_ID),3) = ' US' and avg_Day = "+ d_CALC_INTERVAL + " and [Data_Date] = " + v_datee;
                                break;

                            case 2://HK
                                Str_SQL1 = " declare @T_date as nvarchar(8) "
                                         + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from [港股日收盤還原表排行] where 代號 = 'HSIREF' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc ";

                                Str_SQL2 = " declare @T_date as nvarchar(8) "
                                         + " set @T_date = (select TOP 1 A.日期 from(select TOP " + d_CALC_INTERVAL + " 日期 from [港股日收盤還原表排行] where 代號 = 'HSIREF' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                                         + " select ('H'+代號) as 代號, (cast(cast(代號 as int) as varchar(15))+' HK') as 代號, " + v_datee + " as [Data_Date], " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG([成交量(千)]*1000.0),2) as [" + d_CALC_INTERVAL + "日成交均量] from[港股日收盤還原表排行] "
                                         + " where 日期 >= @T_date "
                                         + " and 代號 in (select 代號 from[港股上市公司基本資料] where 代號 in (" + str_stk + ") and 年度 = (select MAX(年度) from[港股上市公司基本資料] )) "
                                         + " group by 代號 "
                                         + " order by 代號 asc; ";
                                Str_SQL_DEL = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and SUBSTRING(BBG_ID,charindex(' HK',BBG_ID),3) = ' HK'  and avg_Day = " + d_CALC_INTERVAL  + " and [Data_Date] = " + v_datee;
                                break;

                            case 3://CH
                                Str_SQL1 = " declare @T_date as nvarchar(8) "
                                         + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from [陸股日收盤還原表排行] where 代號 = '000001' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc ";

                                Str_SQL2 = " declare @T_date as nvarchar(8) "
                                         + " set @T_date = (select TOP 1 A.日期 from(select TOP " + d_CALC_INTERVAL + " 日期 from [陸股日收盤還原表排行] where 代號 = '000001' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                                         + " select ('C'+代號) as 代號, (代號+' CH') as 代號, " + v_datee + " as [Data_Date], " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG([成交量(股)]*1.0),2) as [" + d_CALC_INTERVAL + "日成交均量] from[陸股日收盤還原表排行] "
                                         + " where 日期 >= @T_date "
                                         + " and 代號 in (select 代號 from[陸股公司基本資料] where 代號 in (" + str_stk + ") and 年度 = (select MAX(年度) from[陸股公司基本資料] )) "
                                         + " group by 代號 "
                                         + " order by 代號 asc; ";
                                Str_SQL_DEL = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and SUBSTRING(BBG_ID,charindex(' CH',BBG_ID),3) = ' CH'  and avg_Day = " + d_CALC_INTERVAL + "  and [Data_Date] = " + v_datee;
                                break;
                        }

                        // 讀取250日起始日期
                        ADODB.Recordset rs = new ADODB.Recordset();
                        rs = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL1); //cmoneyserver
                        v_dateb = rs.Fields["日期"].Value.ToString();

                        WriteToTextbox(vMarket + "擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量開始...");
                        ADODB.Recordset rs1 = new ADODB.Recordset();
                        rs1 = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL2); //cmoneyserver

                        WriteToTextbox(DestinationTableName + "本日" + d_CALC_INTERVAL + "D成交均量標的筆數:" + rs1.RecordCount.ToString());

                        //Recordset to adapter to Datatable                    
                        DataTable dt = null;
                        dt = new DataTable();
                        dt.TableName = "tmp";
                        System.Data.OleDb.OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
                        adapter.Fill(dt, rs1);

                        //批量寫入資料mssql
                        //批量寫入前資料刪除
                        SqlCommand sqlComm = new SqlCommand();
                        sqlComm.Connection = cnn;
                        sqlComm.CommandText = Str_SQL_DEL;
                        sqlComm.ExecuteNonQuery();
                        sqlComm.Dispose();

                        //3. 使用 sqlBulkCopy寫入 SQL資料表
                        using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                        {
                            //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                            bcp.BatchSize = 100; //每次傳輸行數
                            bcp.NotifyAfter = 100; //進度提示的行數
                            bcp.DestinationTableName = DestinationTableName; //目標table 
                            bcp.WriteToServer(dt); //轉寫入MSSQL
                        }
                        WriteToTextbox(vMarket + "擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量結束...");
                        WriteToTextbox("");

                        dt.Dispose();
                        rs.Close();
                        rs1.Close();
                    }                    
                    
                }             
            }
            catch (Exception ex)
            {
                textBox3.AppendText("美股錯誤:" + ex.Message + Environment.NewLine);
                this.Cursor = Cursors.Default;
            }


        }

        //讀取 CMONEY 250D台股成交均量
        private void button1_Click(object sender, EventArgs e)
        {
            string d_CALC_INTERVAL = "250";

            try
            {
                Connect_MSSQL();
                v_datee = maskedTextBox4.Text ;//DateTime.Now.ToString("yyyyMMdd") ;
                DestinationTableName = "Local_Volume";

                //讀取台股資料
                DataSet ds = new DataSet();
                Application.DoEvents();
                string sql;
                sql = "EXEC sp_query_stk @dt ,@kind ";
                cmd = new SqlCommand(sql, cnn);
                cmd.CommandTimeout = 10000;
                cmd.Parameters.Add(new SqlParameter("dt", v_datee));
                cmd.Parameters.Add(new SqlParameter("kind", 0));
                //cmd.ExecuteReader();
                SqlDataAdapter sql_dt = new SqlDataAdapter();
                sql_dt.SelectCommand = cmd;
                sql_dt.Fill(ds);

                int run_cnt = 0;
                run_cnt = ds.Tables[0].Rows.Count;
                str_stk = "";
                for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                {
                    str_stk = str_stk
                             + "'"
                             + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString()
                             + "'";
                    if (ls_b != run_cnt - 1)
                    { str_stk = str_stk + ","; }
                }
                //MessageBox.Show(str_stk);

                // 讀取250日起始日期
                Str_SQL = " declare @T_date as nvarchar(8) "
                        + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from[日收盤表排行] where 股票代號 = 'twa00' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc " ;
                ADODB.Recordset rs = new ADODB.Recordset();
                rs = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver
                v_dateb = rs.Fields["日期"].Value.ToString();
                
                // 讀取250日平均成交量資料
                Str_SQL = " declare @T_date as nvarchar(8) "
                        + " set @T_date = (select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from[日收盤表排行] where 股票代號 = 'twa00' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                        //+ " set @T_date = (select TOP 1 A.日期 from(select TOP 250 日期 from[日收盤表排行] where 股票代號 = 'twa00'  order by 日期 desc)A order by A.日期 asc) "
                        + " select 股票代號, (股票代號+' TT') as 股票代號, " + v_datee + " as [Data_Date],  " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG(成交量 * 1.0), 2) as [250日成交均量] from[日收盤表排行] "
                        + " where 日期 >= @T_date "
                        + " and 股票代號 in (select 股票代號 from[上市櫃公司基本資料] where 股票代號 in (" + str_stk + ") and 年度 = (select MAX(年度) from[上市櫃公司基本資料] )) "
                        + " group by 股票代號 "
                        + " order by 股票代號 asc; ";
                //textBox3.AppendText(Str_SQL + Environment.NewLine);
                WriteToTextbox("台股擷取[" + v_dateb + "~" + v_datee + "]  " + d_CALC_INTERVAL + "D成交均量開始...");
                ADODB.Recordset rs1 = new ADODB.Recordset();
                rs1 = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver

                WriteToTextbox(DestinationTableName + "本日 " + d_CALC_INTERVAL + "D成交均量標的筆數:" + rs1.RecordCount.ToString() );
                //+ rs1.RecordCount.ToString() + ";"
                //+ rs1.Fields["股票代號"].Value + " "
                //+ rs1.Fields["Data_Date"].Value + " "
                //+ rs1.Fields["Avg_Day"].Value + " "
                //+ rs1.Fields["250日成交均量"].Value + " "
                //+ Environment.NewLine);

                //Recordset to adapter to Datatable
                DataTable dt = null;
                dt = new DataTable();
                dt.TableName = "tmp";
                System.Data.OleDb.OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
                adapter.Fill(dt, rs1);

                
                //刪除資料庫資料
                SqlCommand sqlComm = new SqlCommand();
                sqlComm.Connection = cnn;
                sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and avg_Day = " + d_CALC_INTERVAL + " and BBG_ID like '% TT' and [Data_Date] = " + v_datee;
                sqlComm.ExecuteNonQuery();

                //批量寫入資料mssql
                //3. 使用 sqlBulkCopy寫入 SQL資料表
                using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                {
                    //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                    bcp.BatchSize = 100; //每次傳輸行數
                    bcp.NotifyAfter = 100; //進度提示的行數
                    bcp.DestinationTableName = DestinationTableName; //目標table 
                    bcp.WriteToServer(dt); //轉寫入MSSQL
                }
                sqlComm.Dispose();
                dt.Dispose();
                rs.Close();
                rs1.Close();

                WriteToTextbox("台股擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量結束...");
                WriteToTextbox("");
            }
            catch (Exception ex)
            {
                textBox3.AppendText("台股錯誤:" + ex.Message + Environment.NewLine);
                this.Cursor = Cursors.Default;
            }
        }

        //date picker 控制
        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            DateTime vvDt;
            vvDt = ((DateTimePicker)sender).Value;
            maskedTextBox4.Text = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
        }

        //查詢美股
        /* 美股
        declare @T_date as nvarchar(8),@T_date1 as nvarchar(8)
        set @T_date=(select TOP 1 A.日期 from (select TOP 250 日期 from [美股日收盤還原表排行] where 代號='UN' order by 日期 desc)A order by A.日期 asc)
        set @T_date1=(select TOP 1 A.日期 from (select TOP 250 日期 from [美股日收盤還原表排行] where 代號='UN' order by 日期 desc)A order by A.日期 desc)
        select @T_date,@T_date1,代號,MAX(名稱) as 股票名稱,ROUND(AVG(成交量*1.0),2) as [250日成交均量] from [美股日收盤還原表排行] 
        where 日期 >= @T_date
        and 代號 in (select 代號 from [美股上市公司基本資料]  where 代號 IN ('AINV','A') and 年度=(select MAX(年度) from [美股上市公司基本資料] ))
        group by 代號
        order by  代號 asc
        */        
        private void button3_Click(object sender, EventArgs e)
        {
            string Str_SQL, str_stk, v_dateb, v_datee, DestinationTableName;
            string d_CALC_INTERVAL = "250";

            try
            {
                Connect_MSSQL();
                v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;
                DestinationTableName = "Foreign_Volume";

                //讀取美股資料
                DataSet ds = new DataSet();
                Application.DoEvents();
                string sql;
                sql = "EXEC sp_query_stk @dt ,@kind ";
                cmd = new SqlCommand(sql, cnn);
                cmd.CommandTimeout = 10000;
                cmd.Parameters.Add(new SqlParameter("dt", v_datee));
                cmd.Parameters.Add(new SqlParameter("kind", 1));
                //cmd.ExecuteReader();
                SqlDataAdapter sql_dt = new SqlDataAdapter();
                sql_dt.SelectCommand = cmd;
                sql_dt.Fill(ds);

                int run_cnt = 0;
                run_cnt = ds.Tables[0].Rows.Count;
                str_stk = "";
                for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                {
                    str_stk = str_stk
                             + "'"
                             + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString()
                             + "'";
                    if (ls_b != run_cnt - 1)
                    { str_stk = str_stk + ","; }
                }
                //MessageBox.Show(str_stk);

                // 讀取250日起始日期
                Str_SQL = " declare @T_date as nvarchar(8) "
                        + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from[美股日收盤還原表排行] where 代號 = 'UN' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc ";
                ADODB.Recordset rs = new ADODB.Recordset();
                rs = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver
                v_dateb = rs.Fields["日期"].Value.ToString();

                SqlCommand sqlComm = new SqlCommand();

                // 讀取250日平均成交量資料
                for (int i1 = 0; i1 <= 1; ++i1)
                {
                    // 0: 250D ; 1:20D 二種天數
                    switch (i1)
                    {
                        case 0:
                            d_CALC_INTERVAL = "250";
                            break;

                        case 1:
                            d_CALC_INTERVAL = "20";
                            break;
                    }

                    Str_SQL = " declare @T_date as nvarchar(8) "
                            + " set @T_date = (select TOP 1 A.日期 from(select TOP "+ d_CALC_INTERVAL + " 日期 from[美股日收盤還原表排行] where 代號 = 'UN' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                            + " select 代號, (代號+' US') as 代號, " + v_datee + " as [Data_Date], " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG(成交量 * 1.0), 2) as [" + d_CALC_INTERVAL + "日成交均量] from[美股日收盤還原表排行] "
                            + " where 日期 >= @T_date "
                            + " and 代號 in (select 代號 from[美股上市公司基本資料] where 代號 in (" + str_stk + ") and 年度 = (select MAX(年度) from[美股上市公司基本資料] )) "
                            + " group by 代號 "
                            + " order by 代號 asc; ";
                    //textBox3.AppendText(Str_SQL + Environment.NewLine);
                    WriteToTextbox("美股擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量開始...");
                    ADODB.Recordset rs1 = new ADODB.Recordset();
                    rs1 = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver

                    WriteToTextbox(DestinationTableName + "本日" + d_CALC_INTERVAL + "D成交均量標的筆數:" + rs1.RecordCount.ToString());

                    //Recordset to adapter to Datatable                    
                    DataTable dt = null;
                    dt = new DataTable();
                    dt.TableName = "tmp";
                    System.Data.OleDb.OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
                    adapter.Fill(dt, rs1);


                    //刪除資料庫資料                   
                    sqlComm.Connection = cnn;
                    sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and avg_Day = " + d_CALC_INTERVAL + " and BBG_ID like '% US' and [Data_Date] = " + v_datee;
                    sqlComm.ExecuteNonQuery();

                    //批量寫入資料mssql
                    //3. 使用 sqlBulkCopy寫入 SQL資料表
                    using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                    {
                        //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                        bcp.BatchSize = 100; //每次傳輸行數
                        bcp.NotifyAfter = 100; //進度提示的行數
                        bcp.DestinationTableName = DestinationTableName; //目標table 
                        bcp.WriteToServer(dt); //轉寫入MSSQL
                    }
                    WriteToTextbox("美股擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量結束...");
                    WriteToTextbox("");

                    dt.Dispose();
                    rs1.Close();
                }
                rs.Close();
                sqlComm.Dispose();

            }
            catch (Exception ex)
            {
                textBox3.AppendText("美股錯誤:" + ex.Message + Environment.NewLine);
                this.Cursor = Cursors.Default;
            }
        }

        /* 港股
        declare @T_date as nvarchar(8),@T_date1 as nvarchar(8)
        //樣本代號HSIREF恆生參考指數
        set @T_date=(select TOP 1 A.日期 from (select TOP 250 日期 from [港股日收盤還原表排行] where 代號='HSIREF' order by 日期 desc)A order by A.日期 asc)
        set @T_date1=(select TOP 1 A.日期 from (select TOP 250 日期 from [港股日收盤還原表排行] where 代號='HSIREF' order by 日期 desc)A order by A.日期 desc)
        select @T_date,@T_date1,代號,MAX(名稱) as 股票名稱,ROUND(AVG([成交量(千)]*1000.0),2) as [250日成交均量] from [港股日收盤還原表排行] 
        where 日期 >= @T_date
        and 代號 in (select 代號 from [港股上市公司基本資料]  where 代號 IN ('00001','00267') and 年度=(select MAX(年度) from [港股上市公司基本資料] ))
        group by 代號
        order by  代號 asc
        */
        private void button4_Click(object sender, EventArgs e)
        {
            string Str_SQL,str_stk, v_dateb, v_datee, DestinationTableName;
            string d_CALC_INTERVAL = "250";

            try
            {
                Connect_MSSQL();
                v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;
                DestinationTableName = "Foreign_Volume";

                //讀取港股資料
                DataSet ds = new DataSet();
                Application.DoEvents();
                string sql;
                sql = "EXEC sp_query_stk @dt ,@kind ";
                cmd = new SqlCommand(sql, cnn);
                cmd.CommandTimeout = 10000;
                cmd.Parameters.Add(new SqlParameter("dt", v_datee ));
                cmd.Parameters.Add(new SqlParameter("kind", 2));
                //cmd.ExecuteReader();
                SqlDataAdapter sql_dt = new SqlDataAdapter();
                sql_dt.SelectCommand = cmd;
                sql_dt.Fill(ds);

                int run_cnt = 0;
                run_cnt = ds.Tables[0].Rows.Count;
                str_stk = ""; 
                for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                {
                    str_stk = str_stk
                             + "'"
                             + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString().Replace("H", "")
                             + "'";
                    if (ls_b != run_cnt - 1)
                    { str_stk = str_stk + ",";  }
                }
                //MessageBox.Show(str_stk);

                // 讀取250日起始日期
                Str_SQL = " declare @T_date as nvarchar(8) "
                        + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from [港股日收盤還原表排行] where 代號 = 'HSIREF' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc ";

                ADODB.Recordset rs = new ADODB.Recordset();
                rs = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver
                v_dateb = rs.Fields["日期"].Value.ToString();

                SqlCommand sqlComm = new SqlCommand();

                // 讀取250日平均成交量資料
                for (int i1 = 0; i1 <= 1; ++i1)
                {
                    // 0: 250D ; 1:20D 二種天數
                    switch (i1)
                    {
                        case 0:
                            d_CALC_INTERVAL = "250";
                            break;

                        case 1:
                            d_CALC_INTERVAL = "20";
                            break;
                    }

                    Str_SQL = " declare @T_date as nvarchar(8) "
                            + " set @T_date = (select TOP 1 A.日期 from(select TOP " + d_CALC_INTERVAL + " 日期 from [港股日收盤還原表排行] where 代號 = 'HSIREF' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                            + " select ('H'+代號) as 代號, (cast(cast(代號 as int) as varchar(15))+' HK') as 代號, " + v_datee + " as [Data_Date], " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG([成交量(千)]*1000.0),2) as [" + d_CALC_INTERVAL + "日成交均量] from[港股日收盤還原表排行] "
                            + " where 日期 >= @T_date "
                            + " and 代號 in (select 代號 from[港股上市公司基本資料] where 代號 in ("+ str_stk + ") and 年度 = (select MAX(年度) from[港股上市公司基本資料] )) "
                            + " group by 代號 "
                            + " order by 代號 asc; ";
                    //textBox3.AppendText(Str_SQL + Environment.NewLine);
                    WriteToTextbox("港股擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量開始...");
                    ADODB.Recordset rs1 = new ADODB.Recordset();
                    rs1 = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver

                    WriteToTextbox(DestinationTableName + "本日" + d_CALC_INTERVAL + "D成交均量標的筆數:" + rs1.RecordCount.ToString());

                    //Recordset to adapter to Datatable                    
                    DataTable dt = null;
                    dt = new DataTable();
                    dt.TableName = "tmp";
                    System.Data.OleDb.OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
                    adapter.Fill(dt, rs1);

                    //刪除資料庫資料
                    sqlComm.Connection = cnn;
                    sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and avg_Day = " + d_CALC_INTERVAL + " and BBG_ID like '% HK' and [Data_Date] = " + v_datee;
                    sqlComm.ExecuteNonQuery();

                    //批量寫入資料mssql
                    //3. 使用 sqlBulkCopy寫入 SQL資料表
                    using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                    {
                        //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                        bcp.BatchSize = 100; //每次傳輸行數
                        bcp.NotifyAfter = 100; //進度提示的行數
                        bcp.DestinationTableName = DestinationTableName; //目標table 
                        bcp.WriteToServer(dt); //轉寫入MSSQL
                    }
                    WriteToTextbox("港股擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量結束...");
                    WriteToTextbox("");

                    dt.Dispose();
                    rs1.Close();
                }
                rs.Close();
                sqlComm.Dispose();

            }
            catch (Exception ex)
            {
                textBox3.AppendText("港股錯誤:" + ex.Message + Environment.NewLine);
                this.Cursor = Cursors.Default;
            }
        }

        /* 陸股
        declare @T_date as nvarchar(8),@T_date1 as nvarchar(8)
        set @T_date=(select TOP 1 A.日期 from (select TOP 250 日期 from [陸股日收盤還原表排行] where 代號='000001' order by 日期 desc)A order by A.日期 asc)
        set @T_date1=(select TOP 1 A.日期 from (select TOP 250 日期 from [陸股日收盤還原表排行] where 代號='000001' order by 日期 desc)A order by A.日期 desc)
        select @T_date,@T_date1,代號,MAX(名稱) as 股票名稱,ROUND(AVG([成交量(股)]*1.0),2) as [250日成交均量] from [陸股日收盤還原表排行] 
        where 日期 >= @T_date
        and 代號 in (select 代號 from [陸股公司基本資料]  where 代號 IN ('000001') and 年度=(select MAX(年度) from [陸股公司基本資料] ))
        group by 代號
        order by  代號 asc
        */
        private void button5_Click(object sender, EventArgs e)
        {
            string Str_SQL, str_stk , v_dateb, v_datee, DestinationTableName;
            string d_CALC_INTERVAL = "250";

            try
            {
                Connect_MSSQL();
                v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;
                DestinationTableName = "Foreign_Volume";

                //讀取陸股資料
                DataSet ds = new DataSet();
                Application.DoEvents();
                string sql;
                sql = "EXEC sp_query_stk @dt ,@kind ";
                cmd = new SqlCommand(sql, cnn);
                cmd.CommandTimeout = 10000;
                cmd.Parameters.Add(new SqlParameter("dt", v_datee));
                cmd.Parameters.Add(new SqlParameter("kind", 3));
                //cmd.ExecuteReader();
                SqlDataAdapter sql_dt = new SqlDataAdapter();
                sql_dt.SelectCommand = cmd;
                sql_dt.Fill(ds);

                int run_cnt = 0;
                run_cnt = ds.Tables[0].Rows.Count;
                str_stk = "";
                for (int ls_b = 0; ls_b < run_cnt; ls_b++)
                {
                    str_stk = str_stk
                             + "'"
                             + ds.Tables[0].Rows[ls_b]["STK_CD"].ToString().Replace("C", "")
                             + "'";
                    if (ls_b != run_cnt - 1)
                    { str_stk = str_stk + ","; }
                }

                MessageBox.Show(str_stk);

                // 讀取250日起始日期
                Str_SQL = " declare @T_date as nvarchar(8) "
                        + " select TOP 1 A.日期 from(select TOP  " + d_CALC_INTERVAL + " 日期 from [陸股日收盤還原表排行] where 代號 = '000001' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc ";
                ADODB.Recordset rs = new ADODB.Recordset();
                rs = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver
                v_dateb = rs.Fields["日期"].Value.ToString();

                SqlCommand sqlComm = new SqlCommand();

                // 讀取250日平均成交量資料
                for (int i1 = 0; i1 <= 1; ++i1)
                {
                    // 0: 250D ; 1:20D 二種天數
                    switch (i1)
                    {
                        case 0:
                            d_CALC_INTERVAL = "250";
                            break;

                        case 1:
                            d_CALC_INTERVAL = "20";
                            break;
                    }

                    Str_SQL = " declare @T_date as nvarchar(8) "
                            + " set @T_date = (select TOP 1 A.日期 from(select TOP " + d_CALC_INTERVAL + " 日期 from [陸股日收盤還原表排行] where 代號 = '000001' and 日期 <= " + v_datee + " order by 日期 desc)A order by A.日期 asc) "
                            + " select ('C'+代號) as 代號, (代號+' CH') as 代號, " + v_datee + " as [Data_Date], " + d_CALC_INTERVAL + " as [Avg_Day],ROUND(AVG([成交量(股)]*1.0),2) as [" + d_CALC_INTERVAL + "日成交均量] from[陸股日收盤還原表排行] "
                            + " where 日期 >= @T_date "
                            + " and 代號 in (select 代號 from[陸股公司基本資料] where 代號 in (" + str_stk + ") and 年度 = (select MAX(年度) from[陸股公司基本資料] )) "
                            + " group by 代號 "
                            + " order by 代號 asc; ";
                    textBox3.AppendText(Str_SQL + Environment.NewLine);
                    WriteToTextbox("陸股擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量開始...");
                    ADODB.Recordset rs1 = new ADODB.Recordset();
                    rs1 = cmCnn.CMExecute("5", "10.174.190.85", "", Str_SQL); //cmoneyserver

                    WriteToTextbox(DestinationTableName + "本日" + d_CALC_INTERVAL + "D成交均量標的筆數:" + rs1.RecordCount.ToString());

                    //Recordset to adapter to Datatable                    
                    DataTable dt = null;
                    dt = new DataTable();
                    dt.TableName = "tmp";
                    System.Data.OleDb.OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
                    adapter.Fill(dt, rs1);

                    //刪除資料庫資料
                    sqlComm.Connection = cnn;
                    sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 and avg_Day = " + d_CALC_INTERVAL + " and BBG_ID like '% CH' and [Data_Date] = " + v_datee;
                    sqlComm.ExecuteNonQuery();

                    //批量寫入資料mssql
                    //3. 使用 sqlBulkCopy寫入 SQL資料表
                    using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                    {
                        //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                        bcp.BatchSize = 100; //每次傳輸行數
                        bcp.NotifyAfter = 100; //進度提示的行數
                        bcp.DestinationTableName = DestinationTableName; //目標table 
                        bcp.WriteToServer(dt); //轉寫入MSSQL
                    }
                    WriteToTextbox("陸股擷取[" + v_dateb + "~" + v_datee + "] " + d_CALC_INTERVAL + "D成交均量結束...");
                    WriteToTextbox("");

                    dt.Dispose();
                    rs1.Close();
                }
                rs.Close();
                sqlComm.Dispose();

            }
            catch (Exception ex)
            {
                textBox3.AppendText("陸股錯誤:" + ex.Message + Environment.NewLine);
                this.Cursor = Cursors.Default;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button6.PerformClick(); //讀取CMoney
            button2.PerformClick(); //讀取BBG
            button7.PerformClick(); //執行流動性檢核明細及預警表試算及存檔
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // CMoney 資料擷取
            CM_Volume_data();
            //if (_args == "1")
            //{
            //    //結束此程式
            //    this.Close();
            //}
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            this.Text = "股票流動情檢核資料讀取-" + _args;
            if (_args == "1")
            {
                //MessageBox.Show(" button2.PerformClick()") ;
                this.WindowState = FormWindowState.Minimized;
                button8.PerformClick(); //一次執行三個動作
                this.Close(); //結束程式
            }
        }

        //讀取BBG 250D & 20D國外股票成交均量
        private void button2_Click(object sender, EventArgs e)
        {
            string str = System.IO.Directory.GetCurrentDirectory();

            // BBG send 
            string serverHost = "localhost";
            int serverPort = 8194;
            string d_security = "";
            string d_ticker = "";
            string d_stk_cd = "";
            string d_INTERVAL_AVG = "";
            string d_CALC_INTERVAL = "250D";
            string d_END_DATE_OVERRIDE = "";
            string d_MARKET_DATA_OVERRIDE = "PX_VOLUME";
            string csvstr = "";
            string v_datee = "";
            string Str_SQL_DEL = "";
            string DestinationTableName = "Foreign_Volume";

            d_securities = new ArrayList();

            //讀取查詢資料 指定日期  國外股票 有庫存的
            //寫入 DataTABLE Row -- 來源資料庫
            //連結資料庫
            setSQL_info();
            Connect_MSSQL();
            v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;

            DataSet ds = new DataSet();
            Application.DoEvents();
            string sql;
            sql = "EXEC sp_query_stk @dt ,@kind ";
            cmd = new SqlCommand(sql, cnn);
            cmd.CommandTimeout = 10000;
            cmd.Parameters.Add(new SqlParameter("dt", v_datee));
            cmd.Parameters.Add(new SqlParameter("kind", 4));
            //cmd.ExecuteReader();
            SqlDataAdapter sql_dt = new SqlDataAdapter();
            sql_dt.SelectCommand = cmd;
            sql_dt.Fill(ds);

            // 1.讀入多筆資料Lists           
            d_securities.Clear();

            //手動控制查詢筆數
            int run_cnt = 1;
            run_cnt = ds.Tables[0].Rows.Count;
            //run_cnt = 2;
            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
            {
                d_securities.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() + ";" +
                                 ds.Tables[0].Rows[ls_b]["STK_CD"].ToString());
            }
            //d_securities.Add("6501 JP Equity" + ";" + "JP6501");

            //讀取執行日期
            v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;

            //輸入查詢日期
            d_END_DATE_OVERRIDE = v_datee;

            WriteToTextbox("查詢標的列表...");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (var item in d_securities)
            {
                WriteToTextbox(string.Join("", item));
            }

            //Foreign_Volume 欄位
            //System_ID,BBG_ID,Data_date,Avg_Day,Avg_Volume

            // 2.組合 Request string
            Bloomberglp.Blpapi.SessionOptions sessionOptions = new Bloomberglp.Blpapi.SessionOptions();
            sessionOptions.ServerHost = serverHost;
            sessionOptions.ServerPort = serverPort;

            WriteToTextbox("Connecting to " + serverHost + ":" + serverPort);
            Session session = new Session(sessionOptions);

            bool sessionStarted = session.Start();
            if (!sessionStarted)
            {
                WriteToTextbox("Failed to start session.");
                return;
            }

            if (!session.OpenService("//blp/refdata"))
            {
                WriteToTextbox("Failed to open //blp/refdata");
                return;
            }


            //寫入前刪除  sql
            //批量寫入前資料刪除,非台美港陸股票以外之其他股票
            Str_SQL_DEL = "DELETE FROM dbo." + DestinationTableName 
                        + " WHERE 1 = 1 "
                        + " and SUBSTRING(BBG_ID,charindex(' TT',BBG_ID),3) = ' TT'"
                        + " and SUBSTRING(BBG_ID,charindex(' US',BBG_ID),3) = ' US'"
                        + " and SUBSTRING(BBG_ID,charindex(' HK',BBG_ID),3) = ' HK'"
                        + " and SUBSTRING(BBG_ID,charindex(' CH',BBG_ID),3) = ' CH'"
                        + " and [Data_Date] = " + v_datee;

            SqlCommand sqlComm = new SqlCommand();
            sqlComm.Connection = cnn;
            sqlComm.CommandText = Str_SQL_DEL;
            sqlComm.ExecuteNonQuery();
            sqlComm.Dispose();

            // 3.傳送查詢資料,逐筆
            for (int i = 0; i < d_securities.Count; ++i)
            {
                // paser d_securities
                d_security = (string)d_securities[i];
                d_ticker = d_security.Substring(0, d_security.IndexOf(";"));
                d_stk_cd = d_security.Substring(d_security.IndexOf(";") + 1, d_security.Length - (d_security.IndexOf(";") + 1));

                for (int i1 = 0; i1 <= 1; ++i1)
                {
                    // 0: 250D ; 1:20D 二種天數
                    switch (i1)
                    {
                        case 0:
                            d_CALC_INTERVAL = "250";
                            break;

                        case 1:
                            d_CALC_INTERVAL = "20";
                            break;
                    }

                    //BBG 資料讀取
                    //Service refDataService = session.GetService("//blp/refdata");
                    Service refDataService = session.GetService("//blp/refdata");

                    Request request = refDataService.CreateRequest("ReferenceDataRequest");
                    Element securities = request.GetElement("securities");
                    securities.AppendValue(d_ticker);

                    Element fields = request.GetElement("fields");
                    fields.AppendValue("INTERVAL_AVG");

                    // add overrides
                    Element overrides = request["overrides"];
                    Element override1 = overrides.AppendElement();
                    override1.SetElement("fieldId", "CALC_INTERVAL");
                    override1.SetElement("value", d_CALC_INTERVAL + "D");
                    Element override2 = overrides.AppendElement();
                    override2.SetElement("fieldId", "END_DATE_OVERRIDE");
                    override2.SetElement("value", d_END_DATE_OVERRIDE);
                    Element override3 = overrides.AppendElement();
                    override3.SetElement("fieldId", "MARKET_DATA_OVERRIDE");
                    override3.SetElement("value", d_MARKET_DATA_OVERRIDE);

                    //SendRequest
                    session.SendRequest(request, null);
                    WriteToTextbox("(" + d_ticker + ") Sending Request: "
                                  + Environment.NewLine
                                  + request);
                    //Waiting for Response

                    //變數初始值
                    d_INTERVAL_AVG = "0";

                    // 4.接收查詢回應
                    while (true)
                    {
                        Event eventObj = session.NextEvent();
                        if (eventObj.Type == Event.EventType.RESPONSE)
                        {
                            foreach (Message msg in eventObj)
                            {
                                if (msg.HasElement("responseError"))
                                {
                                    WriteToTextbox("SECURITY FAILED: " + msg.GetElement("responseError"));
                                    d_INTERVAL_AVG = "0";
                                    continue;
                                }
                                else
                                {
                                    WriteToTextbox(msg.AsElement.ToString());

                                    Element rsecurities = msg.GetElement("securityData");
                                    int numSecurities = rsecurities.NumValues;
                                    //WriteToTextbox("Processing " + numSecurities.ToString() + " securities:");
                                    for (int j = 0; j < numSecurities; ++j)
                                    {
                                        Element rsecurity = rsecurities.GetValueAsElement(j);
                                        if (rsecurity.HasElement("securityError"))
                                        {
                                            WriteToTextbox("SECURITY FAILED: " + rsecurity.GetElement("securityError").ToString());
                                            d_INTERVAL_AVG = "0";
                                            continue;
                                        }

                                        Element rfields = rsecurity.GetElement("fieldData");
                                        if (rfields.NumElements > 0)
                                        {
                                            int numElements = rfields.NumElements;
                                            for (int k = 0; k < numElements; ++k)
                                            {
                                                Element rfield = rfields.GetElement(k);
                                                if (rfield.Name.ToString() == "INTERVAL_AVG")
                                                {
                                                    d_INTERVAL_AVG = rfield.GetValueAsString();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            break; //exit loop
                        }
                    }
                    //5.製作成文字檔
                    csvstr = "INSERT INTO INVEST.dbo.Foreign_Volume(System_ID,BBG_ID,Data_Date,Avg_Day,Avg_Volume)"
                            + "VALUES("
                            + "'" + d_stk_cd + "',"
                            + "'" + d_ticker.Replace(" Equity","") + "',"
                            + "'" + v_datee + "',"
                            + d_CALC_INTERVAL + ","
                            + d_INTERVAL_AVG
                            + ")";
                    //MessageBox.Show(csvstr);
                    //寫入資料庫
                    sqlComm.Connection = cnn;
                    sqlComm.CommandText = csvstr;
                    sqlComm.ExecuteNonQuery();
                }
            }

            WriteToTextbox("Finish request.");
            // close sql connection
            cnn.Close();    
        }

        //執行流動性檢核明細及預警表試算及存檔
        private void button7_Click(object sender, EventArgs e)
        {
            v_datee = maskedTextBox4.Text;
            WriteToTextbox(v_datee + " 執行計算流動性檢核資料開始...");
            Connect_MSSQL();            
            SqlCommand sqlComm = new SqlCommand();
            sqlComm.Connection = cnn;
            sqlComm.CommandText = " EXEC sp_CHECK_Daily_LIQUIDITY @DT , @TYPE , @MARKET_TP, @TABLE_TP " ;
            sqlComm.CommandTimeout = 10000;
            sqlComm.Parameters.Add(new SqlParameter("dt", v_datee));
            sqlComm.Parameters.Add(new SqlParameter("TYPE", 'C'));
            sqlComm.Parameters.Add(new SqlParameter("MARKET_TP", '0'));
            sqlComm.Parameters.Add(new SqlParameter("TABLE_TP", '0'));
            WriteToTextbox("執行計算中...");
            sqlComm.ExecuteNonQuery();            
            sqlComm.Dispose();
            cnn.Close();
            WriteToTextbox(v_datee + " 執行計算流動性檢核資料結束...");
        }
    }
}
