﻿using BloombergAutomation.Infrastructure;
using BloombergAutomation.Infrastructure.Enums;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Element = Bloomberglp.Blpapi.Element;
using Event = Bloomberglp.Blpapi.Event;
using Message = Bloomberglp.Blpapi.Message;
using Name = Bloomberglp.Blpapi.Name;
using Request = Bloomberglp.Blpapi.Request;
using Service = Bloomberglp.Blpapi.Service;
using Session = Bloomberglp.Blpapi.Session;
using SessionOptions = Bloomberglp.Blpapi.Session;

using System.Data.SqlClient;
using ExtensionMethods;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;
using ArrayList = System.Collections.ArrayList;
using System.Runtime.InteropServices;


namespace GET_BBG_Data
{
    public partial class Form1 : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        //INI 設定檔資訊
        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath + "\\GET_BBG_Data.ini";
        string dirstr1 = "";
        string savedirstr = "";

        StringBuilder data = new StringBuilder(255);

        private ArrayList d_securities; // 標的代號
        private ArrayList d_fields; //查詢欄位
        private ArrayList d_currency; //查詢幣別
        string str = System.IO.Directory.GetCurrentDirectory();

        // default 為由資料庫轉入
        private String _args = "0";

        //MSSQL connection string 
        string connectionString = null;

        public SqlConnection cnn;
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";

        string loguser_ = Environment.UserName;
        string v_datee = "";

        //bbg帳密
        string bbg_id = "";
        string bbg_pw = "";

        SqlCommand cmd;

        //MSSQL 連結參數
        private void setSQL_info()
        {
            database_ = "INVEST";
            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 ";
        }

        //MSSQL 資料庫連結
        private void Connect_MSSQL()
        {

            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            cnn.Open();
        }

        //無參數
        public Form1()
        {
            InitializeComponent();

            this.Text = "BBG ETF發行總額_csv-" + _args;

            d_securities = new ArrayList();
            d_fields = new ArrayList();
            d_currency = new ArrayList();

            dateTimePicker2.Value = DateTime.Now;
            maskedTextBox4.Text = DateTime.Now.AddDays(0).ToString("yyyyMMdd");

            //讀取申萬基金
            GetPrivateProfileString("C163114", "FUND_TOTAL_ASSETS_DT", "", data, 255, dirstr);
            tb_FUND_TOTAL_ASSETS_DT.Text = data.ToString();
            GetPrivateProfileString("C163114", "CURRENCY", "", data, 255, dirstr);
            tb_CURR.Text = data.ToString();
            GetPrivateProfileString("C163114", "EQY_SH_OUT_REAL", "", data, 255, dirstr);
            tb_EQY_SH_OUT_REAL.Text = data.ToString();
            GetPrivateProfileString("C163114", "FUND_CRNCY_ADJ_TOTAL_ASSETS", "", data, 255, dirstr);
            tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Text = data.ToString();

            //登入BBG帳密
            GetPrivateProfileString("BBG_LOGIN", "ID", "", data, 255, dirstr);
            bbg_id = data.ToString();
            GetPrivateProfileString("BBG_LOGIN", "PW", "", data, 255, dirstr);
            bbg_pw = data.ToString();

            //讀取存入路徑
            GetPrivateProfileString("PATH-DEFAULT", "SAVEFILE", "", data, 255, dirstr);
            tb_savepath.Text = data.ToString();

            if (tb_savepath.Text == "")
            {
                tb_savepath.Text = str;
            }

            setSQL_info();
        }

        //傳入 exe 參數
        public Form1(string value)
        {
            InitializeComponent();

            _args = "0";
            if (!string.IsNullOrEmpty(value))
            {
                _args = value;
            }
            this.Text = "BBG-ETF/基金規模/國外股票-" + _args;

            d_securities = new ArrayList();
            d_fields = new ArrayList();
            d_currency = new ArrayList();

            dateTimePicker2.Value = DateTime.Now;
            maskedTextBox4.Text = DateTime.Now.AddDays(0).ToString("yyyyMMdd");

            //讀取申萬基金
            GetPrivateProfileString("C163114", "FUND_TOTAL_ASSETS_DT", "", data, 255, dirstr);
            tb_FUND_TOTAL_ASSETS_DT.Text = data.ToString();
            GetPrivateProfileString("C163114", "CURRENCY", "", data, 255, dirstr);
            tb_CURR.Text = data.ToString();
            GetPrivateProfileString("C163114", "EQY_SH_OUT_REAL", "", data, 255, dirstr);
            tb_EQY_SH_OUT_REAL.Text = data.ToString();
            GetPrivateProfileString("C163114", "FUND_CRNCY_ADJ_TOTAL_ASSETS", "", data, 255, dirstr);
            tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Text = data.ToString();

            //登入BBG帳密
            GetPrivateProfileString("BBG_LOGIN", "ID", "", data, 255, dirstr);
            bbg_id = data.ToString();
            GetPrivateProfileString("BBG_LOGIN", "PW", "", data, 255, dirstr);
            bbg_pw = data.ToString();

            //讀取存入路徑
            GetPrivateProfileString("PATH-DEFAULT", "SAVEFILE", "", data, 255, dirstr);
            tb_savepath.Text = data.ToString();

            if (tb_savepath.Text == "")
            {
                tb_savepath.Text = str;
            }
           
            setSQL_info();

        }
        
        //寫入Textbox
        public void WriteToTextbox(string Newline)
        {
            textBox1.AppendText(Newline + Environment.NewLine);
            //listBox1.Items.Insert(0, listBox1.Items.Count.ToString("000") + " " + Newline + " " + DateTime.Now.ToString());
        }

        //測試讀取BBG
        private void button1_Click(object sender, EventArgs e)
        {
            string str = System.IO.Directory.GetCurrentDirectory();

            // BBG response messages
            List<string> RESPONSE_Lists = new List<string>();

            string serverHost = "localhost";
            int serverPort = 8194;

            Bloomberglp.Blpapi.SessionOptions sessionOptions = new Bloomberglp.Blpapi.SessionOptions();
            sessionOptions.ServerHost = serverHost;
            sessionOptions.ServerPort = serverPort;

            //System.Console.WriteLine("Connecting to " + serverHost + ":" + serverPort);
            WriteToTextbox("Connecting to " + serverHost + ":" + serverPort);
            Session session = new Session(sessionOptions);
            bool sessionStarted = session.Start();
            if (!sessionStarted)
            {
                //System.Console.WriteLine("Failed to start session.");
                WriteToTextbox("Failed to start session.");
                return;
            }

            if (!session.OpenService("//blp/refdata"))
            {
                //System.Console.Error.WriteLine("Failed to open //blp/refdata");
                WriteToTextbox("Failed to open //blp/refdata");
                return;
            }
            Service refDataService = session.GetService("//blp/refdata");

            Request request = refDataService.CreateRequest("ReferenceDataRequest");
            Element securities = request.GetElement("securities");

            securities.AppendValue("0050 TT Equity");
            securities.AppendValue("IWM US Equity");
            securities.AppendValue("1357 JP Equity");
            Element fields = request.GetElement("fields");
            fields.AppendValue("EQY_SH_OUT_REAL");
            fields.AppendValue("FUND_TOTAL_ASSETS_DT");
            fields.AppendValue("FUND_CRNCY_ADJ_TOTAL_ASSETS");

            // add overrides
            Element overrides = request["overrides"];
            Element override1 = overrides.AppendElement();
            override1.SetElement("fieldId", "FUND_TOTAL_ASSETS_CRNCY");
            override1.SetElement("value", "TWD");


            //System.Console.WriteLine("Sending Request: " + request);
            WriteToTextbox("Sending Request: " + request);
            session.SendRequest(request, null);

            StreamWriter wr = new StreamWriter(str + "\\test.txt", false, System.Text.Encoding.UTF8);
            WriteToTextbox("===ProcessResponseEvent===");

            while (true)
            {
                Event eventObj = session.NextEvent();
                if (eventObj.Type == Event.EventType.RESPONSE)
                {
                    foreach (Message msg in eventObj)
                    {
                        if (msg.HasElement("responseError"))
                        {
                            //   printErrorInfo("REQUEST FAILED: ", msg.GetElement(RESPONSE_ERROR));
                            continue;
                        }
                        else
                        {
                            wr.Write(msg.AsElement + Environment.NewLine);
                            WriteToTextbox(msg.AsElement.ToString());
                            //RESPONSE_Lists.Add(msg.AsElement.ToString() );
                            //get Element
                            Element rsecurities = msg.GetElement("securityData");
                            int numSecurities = rsecurities.NumValues;
                            WriteToTextbox("Processing " + numSecurities.ToString() + " securities:");
                            for (int i = 0; i < numSecurities; ++i)
                            {
                                Element rsecurity = rsecurities.GetValueAsElement(i);
                                string ticker = rsecurity.GetElementAsString("security");
                                WriteToTextbox("TICKER:" + ticker);
                                wr.Write("TICKER:" + ticker + Environment.NewLine);
                                if (rsecurity.HasElement("securityError"))
                                {
                                    WriteToTextbox("SECURITY FAILED: " + rsecurity.GetElement("securityError").ToString());
                                    continue;
                                }

                                WriteToTextbox("get detail data");
                                wr.Write("get detail data" + Environment.NewLine);

                                Element rfields = rsecurity.GetElement("fieldData");
                                if (rfields.NumElements > 0)
                                {
                                    int numElements = rfields.NumElements;
                                    for (int j = 0; j < numElements; ++j)
                                    {
                                        Element rfield = rfields.GetElement(j);
                                        if (rfield.Name.ToString() == "FUND_CRNCY_ADJ_TOTAL_ASSETS")
                                        {
                                            WriteToTextbox(rfield.Name + (rfield.GetValueAsInt64() * 1000000).ToString());
                                            wr.Write(rfield.Name + (rfield.GetValueAsInt64() * 1000000).ToString() + Environment.NewLine);
                                        }
                                        else
                                        {
                                            WriteToTextbox(rfield.Name + rfield.GetValueAsString());
                                            wr.Write(rfield.Name + rfield.GetValueAsString() + Environment.NewLine);
                                        }
                                    }

                                }
                            }
                        }
                    }
                    break;
                }
            }
            WriteToTextbox("Finish request");
            wr.Write("Finish request");
            wr.Dispose();
            wr.Close();
        }

        // Run batch BBG API & get data from DB & write to .csv
        private void button2_Click(object sender, EventArgs e)
        {
            string str = System.IO.Directory.GetCurrentDirectory();

            // BBG send 
            string serverHost = "localhost";
            int serverPort = 8194;
            string d_security = "";
            string d_ticker = "";
            string d_stk_cd = "";
            string d_curr = "";
            string d_stk_type = ""; //07:Reits , 08,11,10 ETF貨幣型
            string d_FUND_TOTAL_ASSETS_DT = "";
            string d_EQY_SH_OUT_REAL = "";
            string d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "";
            string csvstr = "";
            string sqlstr = "";

            //讀取查詢資料 指定日期  ETF 有庫存的
            //寫入 DataTABLE Row -- 來源資料庫
            //連結資料庫
            setSQL_info();
            Connect_MSSQL();

            //查詢日期
            v_datee = maskedTextBox4.Text;

            DataSet ds = new DataSet();
            Application.DoEvents();
            string sql;
            sql = "EXEC sp_query_etf @dt ";
            cmd = new SqlCommand(sql, cnn);
            cmd.CommandTimeout = 10000;
            cmd.Parameters.Add(new SqlParameter("dt", v_datee));
            //cmd.ExecuteReader();
            SqlDataAdapter dt = new SqlDataAdapter();
            dt.SelectCommand = cmd;
            dt.Fill(ds);

            // 1.讀入多筆資料Lists           
            d_securities.Clear();
            listBox1.Items.Clear();

            //手動控制查詢筆數
            int run_cnt = 0;
            if (tb__run_cnt.Text == "0" || tb__run_cnt.Text.Trim() == "")
            {
                run_cnt = ds.Tables[0].Rows.Count;
            }
            else
            {
                run_cnt = Convert.ToInt32(tb__run_cnt.Text.Trim());
            }

            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
            {
                d_securities.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() + ";" +
                                 ds.Tables[0].Rows[ls_b]["CRNCY"].ToString() + ":" +
                                 ds.Tables[0].Rows[ls_b]["STK_CD"].ToString() + "~" +
                                 ds.Tables[0].Rows[ls_b]["STK_TYPE"].ToString() );
                listBox1.Items.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() + ";" +
                                   ds.Tables[0].Rows[ls_b]["CRNCY"].ToString());
            }
            //d_securities.Add("0050 TT Equity;TWD");
            //d_securities.Add("IWM US Equity;USD");
            //d_securities.Add("1357 JP Equity;JPY");
            //d_security = (string)d_securities[0];

            WriteToTextbox("查詢標的列表...");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (var item in d_securities)
            {
                WriteToTextbox(string.Join("", item));
            }

            //d_ticker,d_FUND_TOTAL_ASSETS_DT,d_curr,d_EQY_SH_OUT_REAL,d_FUND_CRNCY_ADJ_TOTAL_ASSETS
            csvstr = "股票代碼,生效日期,幣別,已發行股數,發行總額";
            //若無庫存時,生效日期請留空白
            if (tb_FUND_TOTAL_ASSETS_DT.Text != "")
            {
                csvstr = csvstr + Environment.NewLine
                        + "C163114,"
                        + tb_FUND_TOTAL_ASSETS_DT.Text + ","
                        + tb_CURR.Text + ","
                        + tb_EQY_SH_OUT_REAL.Text + ","
                        + tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Text;
            }

            //寫回ini
            WritePrivateProfileString("C163114", "FUND_TOTAL_ASSETS_DT", tb_FUND_TOTAL_ASSETS_DT.Text, dirstr);
            WritePrivateProfileString("C163114", "CURRENCY", tb_CURR.Text, dirstr);
            WritePrivateProfileString("C163114", "EQY_SH_OUT_REAL", tb_EQY_SH_OUT_REAL.Text, dirstr);
            WritePrivateProfileString("C163114", "FUND_CRNCY_ADJ_TOTAL_ASSETS", tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Text, dirstr);

            // 2.組合 Request string
            Bloomberglp.Blpapi.SessionOptions sessionOptions = new Bloomberglp.Blpapi.SessionOptions();
            sessionOptions.ServerHost = serverHost;
            sessionOptions.ServerPort = serverPort;

            WriteToTextbox("Connecting to " + serverHost + ":" + serverPort);
            Session session = new Session(sessionOptions);

            bool sessionStarted = session.Start();
            if (!sessionStarted)
            {
                WriteToTextbox("Failed to start session.");
                return;
            }

            if (!session.OpenService("//blp/refdata"))
            {
                WriteToTextbox("Failed to open //blp/refdata");
                return;
            }

            // 3.傳送查詢資料,逐筆
            // 3.1 刪除資料庫當日資料
            sqlstr = "DELETE FROM INVEST.dbo.FUNDSIZE WHERE FUNDTYPE = 'ETF' AND FUNDSIZE_DATE='"+ v_datee + "'";
            //MessageBox.Show(sqlstr);
            //寫入資料庫
            SqlCommand sqlComm = new SqlCommand();
            sqlComm.Connection = cnn;
            sqlComm.CommandText = sqlstr;
            sqlComm.ExecuteNonQuery();

            for (int i = 0; i < d_securities.Count; ++i)
            {
                // paser d_securities
                d_security = (string)d_securities[i];
                d_ticker = d_security.Substring(0, d_security.IndexOf(";"));
                d_curr = d_security.Substring(d_security.IndexOf(";") + 1, 3);
                d_stk_cd = d_security.Substring(d_security.IndexOf(":") + 1, d_security.Length - (d_security.IndexOf(":") + 1) - 3);
                d_stk_type = d_security.Substring(d_security.IndexOf("~") + 1, 2);

                Service refDataService = session.GetService("//blp/refdata");

                Request request = refDataService.CreateRequest("ReferenceDataRequest");
                Element securities = request.GetElement("securities");
                securities.AppendValue(d_ticker);

                Element fields = request.GetElement("fields");
                fields.AppendValue("FUND_TOTAL_ASSETS_DT");
                fields.AppendValue("EQY_SH_OUT_REAL");
                fields.AppendValue("FUND_CRNCY_ADJ_TOTAL_ASSETS");

                // add overrides
                Element overrides = request["overrides"];
                Element override1 = overrides.AppendElement();
                override1.SetElement("fieldId", "FUND_TOTAL_ASSETS_CRNCY");
                override1.SetElement("value", d_curr);

                //SendRequest
                session.SendRequest(request, null);
                WriteToTextbox("(" + d_ticker + ") Sending Request: "
                              + Environment.NewLine
                              + request);
                //Waiting for Response

                //變數初始值
                d_FUND_TOTAL_ASSETS_DT = "";
                d_EQY_SH_OUT_REAL = "0";
                d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "0";

                // 4.接收查詢回應
                while (true)
                {
                    Event eventObj = session.NextEvent();
                    if (eventObj.Type == Event.EventType.RESPONSE)
                    {
                        foreach (Message msg in eventObj)
                        {
                            if (msg.HasElement("responseError"))
                            {
                                WriteToTextbox("SECURITY FAILED: " + msg.GetElement("responseError"));
                                d_FUND_TOTAL_ASSETS_DT = "";
                                d_EQY_SH_OUT_REAL = "0";
                                d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "0";
                                continue;
                            }
                            else
                            {
                                Element rsecurities = msg.GetElement("securityData");
                                int numSecurities = rsecurities.NumValues;
                                //WriteToTextbox("Processing " + numSecurities.ToString() + " securities:");
                                for (int j = 0; j < numSecurities; ++j)
                                {
                                    Element rsecurity = rsecurities.GetValueAsElement(j);
                                    if (rsecurity.HasElement("securityError"))
                                    {
                                        WriteToTextbox("SECURITY FAILED: " + rsecurity.GetElement("securityError").ToString());
                                        d_FUND_TOTAL_ASSETS_DT = "";
                                        d_EQY_SH_OUT_REAL = "0";
                                        d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "0";
                                        continue;
                                    }

                                    Element rfields = rsecurity.GetElement("fieldData");
                                    if (rfields.NumElements > 0)
                                    {
                                        int numElements = rfields.NumElements;
                                        for (int k = 0; k < numElements; ++k)
                                        {
                                            Element rfield = rfields.GetElement(k);
                                            if (rfield.Name.ToString() == "FUND_CRNCY_ADJ_TOTAL_ASSETS")
                                            {
                                                d_FUND_CRNCY_ADJ_TOTAL_ASSETS = (rfield.GetValueAsFloat64() * 1000000).ToString();
                                            }
                                            else if (rfield.Name.ToString() == "EQY_SH_OUT_REAL")
                                            {
                                                d_EQY_SH_OUT_REAL = rfield.GetValueAsString();
                                            }
                                            else if (rfield.Name.ToString() == "FUND_TOTAL_ASSETS_DT")
                                            {
                                                d_FUND_TOTAL_ASSETS_DT = rfield.GetValueAsString();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        break; //exit loop
                    }
                }

                //5.製作成文字檔
                if ((d_stk_cd != "511660") && (d_stk_cd != "511810") && (d_stk_cd != "511880") )
                {
                    //因為Reits無fund相關資訊,只有EQY_SH_OUT_REAL,且GA上傳時,total_assets需要值,assign eqy_sh_out_real value to total_assets
                    if (d_stk_type == "07")
                    {
                        d_FUND_TOTAL_ASSETS_DT = v_datee;
                        d_FUND_CRNCY_ADJ_TOTAL_ASSETS = d_EQY_SH_OUT_REAL;
                    }
                    csvstr = csvstr
                                            + Environment.NewLine
                                            + d_stk_cd + ","
                                            + d_FUND_TOTAL_ASSETS_DT.Replace("-", "/") + ","
                                            + d_curr + ","
                                            + d_EQY_SH_OUT_REAL + ","
                                            + d_FUND_CRNCY_ADJ_TOTAL_ASSETS;
                }

                //6.write to DB , 07.REITS  不寫入資料庫,但產生文字上傳檔
                if (d_stk_type != "07")
                {
                    sqlstr = "INSERT INTO INVEST.dbo.FUNDSIZE(BLOOMBERG_CD,CRNCY,OUTSTANDING_UNIT,FUNDSIZE,FUNDSIZE_DATE,FUNDTYPE)"
                            + "VALUES("
                            + "'" + d_ticker + "',"
                            + "'" + d_curr + "',"
                            + d_EQY_SH_OUT_REAL + ","
                            + d_FUND_CRNCY_ADJ_TOTAL_ASSETS + ","
                            + "'" + v_datee + "',"
                            + "'ETF'"
                            + ")";
                    //MessageBox.Show(sqlstr);
                    //寫入資料庫
                    sqlComm.CommandText = sqlstr;
                    sqlComm.ExecuteNonQuery();
                }
            }
            // close sql connection
            sqlComm.Dispose();
            cnn.Close();
            WriteToTextbox("Finish request.");
            // 7.存至指定資料夾
            try
            {
                StreamWriter wr = new StreamWriter(tb_savepath.Text + "\\BTSM035_" + v_datee + ".csv", false, System.Text.Encoding.UTF8);
                wr.Write(csvstr);
                wr.Dispose();
                wr.Close();
                WriteToTextbox("File SaveAs : " + tb_savepath.Text + "\\BTSM035_" + v_datee + ".csv");
            }
            catch
            {
                StreamWriter wr = new StreamWriter(Application.StartupPath + "\\BTSM035_" + v_datee + ".csv", false, System.Text.Encoding.UTF8);
                wr.Write(csvstr);
                wr.Dispose();
                wr.Close();
                WriteToTextbox("File SaveAs : " + Application.StartupPath + "\\BTSM035_" + v_datee + ".csv");
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            DateTime vvDt;
            vvDt = ((DateTimePicker)sender).Value;
            maskedTextBox4.Text = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
        }

        //排程用
        private void Form1_Shown(object sender, EventArgs e)
        {
            this.Text = "BBG-ETF/基金規模/國外股票-" + _args;
            if (_args == "1")
            {
                //MessageBox.Show(" button2.PerformClick()") ;
                this.WindowState = FormWindowState.Minimized;
                button6.PerformClick(); 
                //結束此程式
                this.Close();
            }
        }

        private void tb__run_cnt_Click(object sender, EventArgs e)
        {
            tb__run_cnt.SelectionStart = 0;
        }

        //日均量讀取測試
        private void button3_Click(object sender, EventArgs e)
        {
            string str = System.IO.Directory.GetCurrentDirectory();

            // BBG send 
            string serverHost = "localhost";
            int serverPort = 8194;
            string d_security = "";
            string d_ticker = "";
            string d_stk_cd = "";
            string d_curr = "";
            string d_INTERVAL_AVG = "";
            string d_CALC_INTERVAL = "250D";
            string d_END_DATE_OVERRIDE = "";
            string d_MARKET_DATA_OVERRIDE = "PX_VOLUME";
            string csvstr = "";

            d_securities = new ArrayList();

            //讀取查詢資料 指定日期  國外股票 有庫存的
            //寫入 DataTABLE Row -- 來源資料庫
            //連結資料庫
            setSQL_info();
            Connect_MSSQL();
            v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;

            DataSet ds = new DataSet();
            Application.DoEvents();
            string sql;
            sql = "EXEC sp_query_stk @dt ,@kind ";
            cmd = new SqlCommand(sql, cnn);
            cmd.CommandTimeout = 10000;
            cmd.Parameters.Add(new SqlParameter("dt", v_datee));
            cmd.Parameters.Add(new SqlParameter("kind", 4));
            //cmd.ExecuteReader();
            SqlDataAdapter sql_dt = new SqlDataAdapter();
            sql_dt.SelectCommand = cmd;
            sql_dt.Fill(ds);

            // 1.讀入多筆資料Lists           
            d_securities.Clear();

            //手動控制查詢筆數
            int run_cnt = 1;

            run_cnt = ds.Tables[0].Rows.Count;            
            //run_cnt = 2;
            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
            {
                d_securities.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() +";"+
                                 ds.Tables[0].Rows[ls_b]["STK_CD"].ToString());
            }
            //d_securities.Add("6501 JP Equity" + ";" + "JP6501");

            //讀取執行日期
            v_datee = maskedTextBox4.Text;//DateTime.Now.ToString("yyyyMMdd") ;

            //輸入查詢日期
            d_END_DATE_OVERRIDE = v_datee;

            WriteToTextbox("查詢標的列表...");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (var item in d_securities)
            {
                WriteToTextbox(string.Join("", item));
            }

            //Foreign_Volume 欄位
            //System_ID,BBG_ID,Data_date,Avg_Day,Avg_Volume

            // 2.組合 Request string
            Bloomberglp.Blpapi.SessionOptions sessionOptions = new Bloomberglp.Blpapi.SessionOptions();
            sessionOptions.ServerHost = serverHost;
            sessionOptions.ServerPort = serverPort;

            WriteToTextbox("Connecting to " + serverHost + ":" + serverPort);
            Session session = new Session(sessionOptions);

            bool sessionStarted = session.Start();
            if (!sessionStarted)
            {
                WriteToTextbox("Failed to start session.");
                return;
            }

            if (!session.OpenService("//blp/refdata"))
            {
                WriteToTextbox("Failed to open //blp/refdata");
                return;
            }

            // 3.傳送查詢資料,逐筆
            for (int i = 0; i < d_securities.Count; ++i)
            {
                // paser d_securities
                d_security = (string)d_securities[i];
                d_ticker = d_security.Substring(0, d_security.IndexOf(";"));
                d_stk_cd = d_security.Substring(d_security.IndexOf(";") + 1, d_security.Length - (d_security.IndexOf(";") + 1));

                for (int i1 = 0; i1 <= 0; ++i1)
                {
                    // 0: 250D ; 1:20D 二種天數
                    switch (i1)
                    {
                        case 0:
                            d_CALC_INTERVAL = "250";
                            break;

                        case 1:
                            d_CALC_INTERVAL = "20";
                            break;
                    }

                    //BBG 資料讀取
                    //Service refDataService = session.GetService("//blp/refdata");
                    Service refDataService = session.GetService("//blp/refdata");

                    Request request = refDataService.CreateRequest("ReferenceDataRequest");
                    Element securities = request.GetElement("securities");
                    securities.AppendValue(d_ticker);

                    Element fields = request.GetElement("fields");
                    fields.AppendValue("INTERVAL_AVG");

                    // add overrides
                    Element overrides = request["overrides"];
                    Element override1 = overrides.AppendElement();
                    override1.SetElement("fieldId", "CALC_INTERVAL");
                    override1.SetElement("value", d_CALC_INTERVAL + "D");
                    Element override2 = overrides.AppendElement();
                    override2.SetElement("fieldId", "END_DATE_OVERRIDE");
                    override2.SetElement("value", d_END_DATE_OVERRIDE);
                    Element override3 = overrides.AppendElement();
                    override3.SetElement("fieldId", "MARKET_DATA_OVERRIDE");
                    override3.SetElement("value", d_MARKET_DATA_OVERRIDE);

                    //SendRequest
                    session.SendRequest(request, null);
                    WriteToTextbox("(" + d_ticker + ") Sending Request: "
                                  + Environment.NewLine
                                  + request);
                    //Waiting for Response

                    //變數初始值
                    d_INTERVAL_AVG = "0";

                    // 4.接收查詢回應
                    while (true)
                    {
                        Event eventObj = session.NextEvent();
                        if (eventObj.Type == Event.EventType.RESPONSE)
                        {
                            foreach (Message msg in eventObj)
                            {
                                if (msg.HasElement("responseError"))
                                {
                                    WriteToTextbox("SECURITY FAILED: " + msg.GetElement("responseError"));
                                    d_INTERVAL_AVG = "NA";
                                    continue;
                                }
                                else
                                {
                                    WriteToTextbox(msg.AsElement.ToString());

                                    Element rsecurities = msg.GetElement("securityData");
                                    int numSecurities = rsecurities.NumValues;
                                    //WriteToTextbox("Processing " + numSecurities.ToString() + " securities:");
                                    for (int j = 0; j < numSecurities; ++j)
                                    {
                                        Element rsecurity = rsecurities.GetValueAsElement(j);
                                        if (rsecurity.HasElement("securityError"))
                                        {
                                            WriteToTextbox("SECURITY FAILED: " + rsecurity.GetElement("securityError").ToString());
                                            d_INTERVAL_AVG = "NA";
                                            continue;
                                        }

                                        Element rfields = rsecurity.GetElement("fieldData");
                                        if (rfields.NumElements > 0)
                                        {
                                            int numElements = rfields.NumElements;
                                            for (int k = 0; k < numElements; ++k)
                                            {
                                                Element rfield = rfields.GetElement(k);
                                                if (rfield.Name.ToString() == "INTERVAL_AVG")
                                                {
                                                    d_INTERVAL_AVG = rfield.GetValueAsString();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            break; //exit loop
                        }
                    }
                    //5.製作成文字檔
                    csvstr = "INSERT INTO INVEST.dbo.Foreign_Volume1(System_ID,BBG_ID,Data_Date,Avg_Day,Avg_Volume)"
                            + "VALUES("
                            + "'" + d_stk_cd + "',"
                            + "'" + d_ticker + "',"
                            + "'" + v_datee + "',"
                            + d_CALC_INTERVAL + ","
                            + d_INTERVAL_AVG
                            + ")";
                    //MessageBox.Show(csvstr);
                    //寫入資料庫
                    SqlCommand sqlComm = new SqlCommand();
                    sqlComm.Connection = cnn;
                    sqlComm.CommandText = csvstr;
                    sqlComm.ExecuteNonQuery();
                }
            }

            WriteToTextbox("Finish request.");
            // close sql connection
            cnn.Close();

            //if (_args == "1")
            //{
            //    //結束此程式
            //    this.Close();
            //}
        }

        //轉檔-MF基金規模
        private void button4_Click(object sender, EventArgs e)
        {
            string str = System.IO.Directory.GetCurrentDirectory();

            // BBG send 
            string serverHost = "localhost";
            int serverPort = 8194;
            string d_security = "";
            string d_ticker = "";
            string d_stk_cd = "";
            string d_curr = "";
            string d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "";
            string csvstr = "";
            string sqlstr = "";

            //查詢日期
            v_datee = maskedTextBox4.Text;

            //讀取查詢資料 指定日期  MF 有庫存的
            //寫入 DataTABLE Row -- 來源資料庫
            //連結資料庫
            setSQL_info();
            Connect_MSSQL();

            DataSet ds = new DataSet();
            Application.DoEvents();
            string sql;
            sql = "EXEC sp_query_mf @dt ";
            cmd = new SqlCommand(sql, cnn);
            cmd.CommandTimeout = 10000;
            cmd.Parameters.Add(new SqlParameter("dt", v_datee ));
            //cmd.ExecuteReader();
            SqlDataAdapter dt = new SqlDataAdapter();
            dt.SelectCommand = cmd;
            dt.Fill(ds);

            // 1.讀入多筆資料Lists           
            d_securities.Clear();
            listBox1.Items.Clear();

            //手動控制查詢筆數
            int run_cnt = 0;
            run_cnt = ds.Tables[0].Rows.Count;
            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
            {
                d_securities.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() + ";" +
                                 ds.Tables[0].Rows[ls_b]["CRNCY"].ToString() + ":" +
                                 ds.Tables[0].Rows[ls_b]["CO_FUND_ID"].ToString());
                listBox1.Items.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() + ";" +
                                   ds.Tables[0].Rows[ls_b]["CO_FUND_ID"].ToString());
            }

            WriteToTextbox("查詢標的列表...");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (var item in d_securities)
            {
                WriteToTextbox(string.Join("", item));
            }

            // 2.組合 Request string
            Bloomberglp.Blpapi.SessionOptions sessionOptions = new Bloomberglp.Blpapi.SessionOptions();
            sessionOptions.ServerHost = serverHost;
            sessionOptions.ServerPort = serverPort;

            WriteToTextbox("Connecting to " + serverHost + ":" + serverPort);
            Session session = new Session(sessionOptions);

            bool sessionStarted = session.Start();
            if (!sessionStarted)
            {
                WriteToTextbox("Failed to start session.");
                return;
            }

            if (!session.OpenService("//blp/refdata"))
            {
                WriteToTextbox("Failed to open //blp/refdata");
                return;
            }

            // 3.傳送查詢資料,逐筆
            // 3.1 刪除資料庫當日資料
            sqlstr = "DELETE FROM INVEST.dbo.FUNDSIZE WHERE FUNDTYPE = 'MF' AND FUNDSIZE_DATE='" + v_datee + "'";
            //MessageBox.Show(sqlstr);
            //寫入資料庫
            SqlCommand sqlComm = new SqlCommand();
            sqlComm.Connection = cnn;
            sqlComm.CommandText = sqlstr;
            sqlComm.ExecuteNonQuery();

            for (int i = 0; i < d_securities.Count; ++i)
            {
                // paser d_securities
                d_security = (string)d_securities[i];
                d_ticker = d_security.Substring(0, d_security.IndexOf(";"));
                d_curr = d_security.Substring(d_security.IndexOf(";") + 1, 3);
                d_stk_cd = d_security.Substring(d_security.IndexOf(":") + 1, d_security.Length - (d_security.IndexOf(":") + 1));

                Service refDataService = session.GetService("//blp/refdata");

                Request request = refDataService.CreateRequest("ReferenceDataRequest");
                Element securities = request.GetElement("securities");
                securities.AppendValue(d_ticker);

                
                if (d_curr == "TWD")
                {
                    Element fields = request.GetElement("fields");
                    fields.AppendValue("FUND_TOTAL_ASSETS");
                }
                else
                {
                    Element fields = request.GetElement("fields");
                    fields.AppendValue("FUND_CRNCY_ADJ_TOTAL_ASSETS");
                    // add overrides
                    Element overrides = request["overrides"];
                    Element override1 = overrides.AppendElement();
                    override1.SetElement("fieldId", "FUND_TOTAL_ASSETS_CRNCY");
                    override1.SetElement("value", d_curr);
                }

                //SendRequest
                session.SendRequest(request, null);
                WriteToTextbox("(" + d_ticker + ") Sending Request: "
                              + Environment.NewLine
                              + request);
                //Waiting for Response

                //變數初始值
                d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "0";

                // 4.接收查詢回應
                while (true)
                {
                    Event eventObj = session.NextEvent();
                    if (eventObj.Type == Event.EventType.RESPONSE)
                    {
                        foreach (Message msg in eventObj)
                        {
                            if (msg.HasElement("responseError"))
                            {
                                WriteToTextbox("SECURITY FAILED: " + msg.GetElement("responseError"));
                                d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "0";
                                continue;
                            }
                            else
                            {
                                Element rsecurities = msg.GetElement("securityData");
                                int numSecurities = rsecurities.NumValues;
                                //WriteToTextbox("Processing " + numSecurities.ToString() + " securities:");
                                for (int j = 0; j < numSecurities; ++j)
                                {
                                    Element rsecurity = rsecurities.GetValueAsElement(j);
                                    if (rsecurity.HasElement("securityError"))
                                    {
                                        WriteToTextbox("SECURITY FAILED: " + rsecurity.GetElement("securityError").ToString());
                                        d_FUND_CRNCY_ADJ_TOTAL_ASSETS = "0";
                                        continue;
                                    }

                                    Element rfields = rsecurity.GetElement("fieldData");
                                    if (rfields.NumElements > 0)
                                    {
                                        int numElements = rfields.NumElements;
                                        for (int k = 0; k < numElements; ++k)
                                        {
                                            Element rfield = rfields.GetElement(k);
                                            if ( (rfield.Name.ToString() == "FUND_TOTAL_ASSETS")  || (rfield.Name.ToString() == "FUND_CRNCY_ADJ_TOTAL_ASSETS") )
                                            {
                                                d_FUND_CRNCY_ADJ_TOTAL_ASSETS = (rfield.GetValueAsFloat64() * 1000000).ToString();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        break; //exit loop
                    }
                }

                //5.製作成文字檔
                sqlstr = "INSERT INTO INVEST.dbo.FUNDSIZE(BLOOMBERG_CD,CRNCY,OUTSTANDING_UNIT,FUNDSIZE,FUNDSIZE_DATE,FUNDTYPE)"
                        + "VALUES("
                        + "'" + d_ticker + "',"
                        + "'" + d_curr + "',"
                        + "0,"
                        + d_FUND_CRNCY_ADJ_TOTAL_ASSETS + ","
                        + "'" + v_datee + "',"
                        + "'MF'"
                        + ")";
                //MessageBox.Show(sqlstr);
                //寫入資料庫
                sqlComm.Connection = cnn;
                sqlComm.CommandText = sqlstr;
                sqlComm.ExecuteNonQuery();
            }
            // close sql connection
            sqlComm.Dispose();            
            cnn.Close();
            WriteToTextbox("Finish request.");
        }

        //轉檔-國外股票規模
        private void button5_Click(object sender, EventArgs e)
        {
            string str = System.IO.Directory.GetCurrentDirectory();

            // BBG send 
            string serverHost = "localhost";
            int serverPort = 8194;
            string d_security = "";
            string d_ticker = "";
            string d_stk_cd = "";
            string d_curr = "";
            string d_TOTAL_EQUITY = "";
            string d_FUND_PER = "";
            string csvstr = "";
            string sqlstr = "";
            
            //查詢日期
            v_datee = maskedTextBox4.Text;

            //讀取查詢資料 指定日期  MF 有庫存的
            //寫入 DataTABLE Row -- 來源資料庫
            //連結資料庫
            Connect_MSSQL();

            DataSet ds = new DataSet();
            Application.DoEvents();
            string sql;
            sql = "EXEC sp_query_stk @dt , @KIND ";
            cmd = new SqlCommand(sql, cnn);
            cmd.CommandTimeout = 10000;
            cmd.Parameters.Add(new SqlParameter("dt", v_datee));
            cmd.Parameters.Add(new SqlParameter("KIND", 5));
            //cmd.ExecuteReader();
            SqlDataAdapter dt = new SqlDataAdapter();
            dt.SelectCommand = cmd;
            dt.Fill(ds);

            // 1.讀入多筆資料Lists           
            d_securities.Clear();
            listBox1.Items.Clear();

            int run_cnt = 0;
            run_cnt = ds.Tables[0].Rows.Count;
            
            for (int ls_b = 0; ls_b < run_cnt; ls_b++)
            {
                d_securities.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() + ";" +
                                 ds.Tables[0].Rows[ls_b]["CRNCY"].ToString() + ":" +
                                 ds.Tables[0].Rows[ls_b]["STK_CD"].ToString());
                listBox1.Items.Add(ds.Tables[0].Rows[ls_b]["BLOOMBERG_CODE"].ToString() + ";" +
                                   ds.Tables[0].Rows[ls_b]["STK_CD"].ToString());
            }

            WriteToTextbox("查詢標的列表...");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (var item in d_securities)
            {
                WriteToTextbox(string.Join("", item));
            }

            // 2.組合 Request string
            Bloomberglp.Blpapi.SessionOptions sessionOptions = new Bloomberglp.Blpapi.SessionOptions();
            sessionOptions.ServerHost = serverHost;
            sessionOptions.ServerPort = serverPort;

            WriteToTextbox("Connecting to " + serverHost + ":" + serverPort);
            Session session = new Session(sessionOptions);

            bool sessionStarted = session.Start();
            if (!sessionStarted)
            {
                WriteToTextbox("Failed to start session.");
                return;
            }

            if (!session.OpenService("//blp/refdata"))
            {
                WriteToTextbox("Failed to open //blp/refdata");
                return;
            }

            // 3.傳送查詢資料,逐筆
            // 3.1 刪除資料庫當日資料
            sqlstr = "DELETE FROM INVEST.dbo.TOTALEQ WHERE [DATE] ='" + v_datee + "'";
            //MessageBox.Show(sqlstr);
            //寫入資料庫
            SqlCommand sqlComm = new SqlCommand();
            sqlComm.Connection = cnn;
            sqlComm.CommandText = sqlstr;
            sqlComm.ExecuteNonQuery();

            for (int i = 0; i < d_securities.Count; ++i)
            {
                // paser d_securities
                d_security = (string)d_securities[i];
                d_ticker = d_security.Substring(0, d_security.IndexOf(";"));
                d_curr = d_security.Substring(d_security.IndexOf(";") + 1, 3);
                d_stk_cd = d_security.Substring(d_security.IndexOf(":") + 1, d_security.Length - (d_security.IndexOf(":") + 1));

                Service refDataService = session.GetService("//blp/refdata");

                Request request = refDataService.CreateRequest("ReferenceDataRequest");
                Element securities = request.GetElement("securities");
                if (d_stk_cd == "PR601288") //中國農業銀行特別股
                { securities.AppendValue("601288 CH Equity"); }
                else if ((d_stk_cd == "PRC601398")||(d_stk_cd == "PRU601398"))  //中國工商銀行特別股
                { securities.AppendValue("601398 CH Equity"); }
                else
                { securities.AppendValue(d_ticker);  }
                

                Element fields = request.GetElement("fields");
                fields.AppendValue("TOTAL EQUITY");

                //變數初始值
                d_TOTAL_EQUITY = "0";
                for (int i1 = 1; i1 <= 3; i1++)
                {
                    switch (i1)
                    {
                        case 1 :
                            d_FUND_PER = "Q";
                            break;
                        case 2:
                            d_FUND_PER = "S";
                            break;
                        case 3:
                            d_FUND_PER = "Y";
                            break;
                    }

                    if (d_TOTAL_EQUITY == "0")
                    {
                        // add overrides
                        Element overrides = request["overrides"];
                        Element override1 = overrides.AppendElement();
                        override1.SetElement("fieldId", "FUND_PER");
                        override1.SetElement("value", d_FUND_PER);

                        Element override2 = overrides.AppendElement();
                        override2.SetElement("fieldId", "SCALING_FORMAT");
                        override2.SetElement("value", "MLN");

                        Element override3 = overrides.AppendElement();
                        override3.SetElement("fieldId", "EQY_FUND_CRNCY");
                        override3.SetElement("value", "TWD");

                        //SendRequest
                        session.SendRequest(request, null);
                        WriteToTextbox("(" + d_ticker + ") Sending Request: "
                                      + Environment.NewLine
                                      + request);
                        //Waiting for Response


                        // 4.接收查詢回應
                        while (true)
                        {
                            Event eventObj = session.NextEvent();
                            if (eventObj.Type == Event.EventType.RESPONSE)
                            {
                                foreach (Message msg in eventObj)
                                {
                                    if (msg.HasElement("responseError"))
                                    {
                                        WriteToTextbox("SECURITY FAILED: " + msg.GetElement("responseError"));
                                        d_TOTAL_EQUITY = "0";
                                        continue;
                                    }
                                    else
                                    {
                                        Element rsecurities = msg.GetElement("securityData");
                                        int numSecurities = rsecurities.NumValues;
                                        //WriteToTextbox("Processing " + numSecurities.ToString() + " securities:");
                                        for (int j = 0; j < numSecurities; ++j)
                                        {
                                            Element rsecurity = rsecurities.GetValueAsElement(j);
                                            if (rsecurity.HasElement("securityError"))
                                            {
                                                WriteToTextbox("SECURITY FAILED: " + rsecurity.GetElement("securityError").ToString());
                                                d_TOTAL_EQUITY = "0";
                                                continue;
                                            }

                                            Element rfields = rsecurity.GetElement("fieldData");
                                            if (rfields.NumElements > 0)
                                            {
                                                int numElements = rfields.NumElements;
                                                for (int k = 0; k < numElements; ++k)
                                                {
                                                    Element rfield = rfields.GetElement(k);
                                                    if (rfield.Name.ToString() == "TOTAL EQUITY")
                                                    {
                                                        d_TOTAL_EQUITY = (rfield.GetValueAsFloat64() * 1000000).ToString();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                break; //exit loop
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                //5.製作成文字檔
                csvstr = "INSERT INTO INVEST.dbo.TOTALEQ(STK_CD,BLOOMBERG_CD,CRNCY,TOTAL_EQUITY,[DATE])"
                        + "VALUES("
                        + "'" + d_stk_cd + "',"
                        + "'" + d_ticker + "',"
                        + "'TWD',"
                        + d_TOTAL_EQUITY + ","
                        + "'" + v_datee + "'"
                        + ")";
                //MessageBox.Show(csvstr);
                //寫入資料庫
                sqlComm.CommandText = csvstr;
                sqlComm.ExecuteNonQuery();
            }
            // close sql connection
            sqlComm.Dispose();
            cnn.Close();

            WriteToTextbox("Finish request.");
        }

        //全部按鍵運行
        private void button6_Click(object sender, EventArgs e)
        {
            if (_args == "1")
            {
                button7.PerformClick(); //relog Bloomberg
            }            
            button2.PerformClick(); //ETF
            button4.PerformClick(); //MF
            button5.PerformClick(); //STK-國外
            WriteToTextbox("ETF/REITs/MF/國外股票 作業完成");
        }

        // BBG Login
        private void button7_Click(object sender, EventArgs e)
        {
            using (BloombergDDEBase bloombergDDE = new BloombergDDEBase())
            {
                WriteToTextbox("Ready to Login");
                bloombergDDE.InputLoginUser(bbg_id, bbg_pw);
                WriteToTextbox("Login complete");
            }
        }
    }
}