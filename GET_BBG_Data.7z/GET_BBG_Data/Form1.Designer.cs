﻿namespace GET_BBG_Data
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tb_FUND_TOTAL_ASSETS_DT = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS = new System.Windows.Forms.TextBox();
            this.tb_EQY_SH_OUT_REAL = new System.Windows.Forms.TextBox();
            this.tb_CURR = new System.Windows.Forms.TextBox();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb__run_cnt = new System.Windows.Forms.MaskedTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_savepath = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(33, 130);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(234, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Single Run";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tb_savepath);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tb__run_cnt);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.maskedTextBox4);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 193);
            this.panel1.TabIndex = 108;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tb_FUND_TOTAL_ASSETS_DT);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS);
            this.groupBox1.Controls.Add(this.tb_EQY_SH_OUT_REAL);
            this.groupBox1.Controls.Add(this.tb_CURR);
            this.groupBox1.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(321, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 85);
            this.groupBox1.TabIndex = 113;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "C163114 申萬資訊維護(季)";
            // 
            // tb_FUND_TOTAL_ASSETS_DT
            // 
            this.tb_FUND_TOTAL_ASSETS_DT.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb_FUND_TOTAL_ASSETS_DT.Location = new System.Drawing.Point(7, 52);
            this.tb_FUND_TOTAL_ASSETS_DT.Mask = "0000/00/00";
            this.tb_FUND_TOTAL_ASSETS_DT.Name = "tb_FUND_TOTAL_ASSETS_DT";
            this.tb_FUND_TOTAL_ASSETS_DT.PromptChar = ' ';
            this.tb_FUND_TOTAL_ASSETS_DT.Size = new System.Drawing.Size(82, 25);
            this.tb_FUND_TOTAL_ASSETS_DT.TabIndex = 114;
            this.tb_FUND_TOTAL_ASSETS_DT.Text = "20180630";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(239, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 16);
            this.label8.TabIndex = 113;
            this.label8.Text = "發行總額";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(132, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 16);
            this.label7.TabIndex = 112;
            this.label7.Text = "已發行股數";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(86, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 16);
            this.label6.TabIndex = 111;
            this.label6.Text = "幣別";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(4, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 110;
            this.label4.Text = "生效日期";
            // 
            // tb_FUND_CRNCY_ADJ_TOTAL_ASSETS
            // 
            this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Location = new System.Drawing.Point(242, 52);
            this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Name = "tb_FUND_CRNCY_ADJ_TOTAL_ASSETS";
            this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Size = new System.Drawing.Size(105, 25);
            this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.TabIndex = 109;
            this.tb_FUND_CRNCY_ADJ_TOTAL_ASSETS.Text = "371924693.2";
            // 
            // tb_EQY_SH_OUT_REAL
            // 
            this.tb_EQY_SH_OUT_REAL.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb_EQY_SH_OUT_REAL.Location = new System.Drawing.Point(136, 52);
            this.tb_EQY_SH_OUT_REAL.Name = "tb_EQY_SH_OUT_REAL";
            this.tb_EQY_SH_OUT_REAL.Size = new System.Drawing.Size(105, 25);
            this.tb_EQY_SH_OUT_REAL.TabIndex = 108;
            this.tb_EQY_SH_OUT_REAL.Text = "325969673.9";
            // 
            // tb_CURR
            // 
            this.tb_CURR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tb_CURR.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb_CURR.Location = new System.Drawing.Point(89, 52);
            this.tb_CURR.MaxLength = 3;
            this.tb_CURR.Name = "tb_CURR";
            this.tb_CURR.Size = new System.Drawing.Size(45, 25);
            this.tb_CURR.TabIndex = 107;
            this.tb_CURR.Text = "CNY";
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.maskedTextBox4.Location = new System.Drawing.Point(114, 12);
            this.maskedTextBox4.Mask = "00000000";
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.PromptChar = ' ';
            this.maskedTextBox4.Size = new System.Drawing.Size(87, 27);
            this.maskedTextBox4.TabIndex = 108;
            this.maskedTextBox4.Text = "20180630";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyymmdd";
            this.dateTimePicker2.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(201, 12);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(20, 27);
            this.dateTimePicker2.TabIndex = 112;
            this.dateTimePicker2.TabStop = false;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(36, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 111;
            this.label2.Text = "資料日期";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(33, 79);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(234, 45);
            this.button2.TabIndex = 110;
            this.button2.Text = "執行轉檔";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("PMingLiU", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(325, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(545, 52);
            this.label1.TabIndex = 109;
            this.label1.Text = "EXCEL API 指令範例:\r\n=BDP(0050 TT Equity,EQY_SH_OUT_REAL)\r\n=BDP(0050 TT Equity,FUND_C" +
    "RNCY_ADJ_TOTAL_ASSETS,FUND_TOTAL_ASSETS_CRNCY=TWD)\r\n=BDP(0050 TT Equity,FUND_TOT" +
    "AL_ASSETS_DT)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(36, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 16);
            this.label3.TabIndex = 115;
            this.label3.Text = "查詢筆數(零為不限數量)";
            // 
            // tb__run_cnt
            // 
            this.tb__run_cnt.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb__run_cnt.Location = new System.Drawing.Point(218, 44);
            this.tb__run_cnt.Mask = "#9";
            this.tb__run_cnt.Name = "tb__run_cnt";
            this.tb__run_cnt.PromptChar = ' ';
            this.tb__run_cnt.Size = new System.Drawing.Size(49, 27);
            this.tb__run_cnt.TabIndex = 116;
            this.tb__run_cnt.Click += new System.EventHandler(this.tb__run_cnt_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.listBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 193);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(886, 355);
            this.panel2.TabIndex = 109;
            // 
            // listBox1
            // 
            this.listBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(0, 0);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(886, 124);
            this.listBox1.Sorted = true;
            this.listBox1.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(0, 124);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(886, 231);
            this.textBox1.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(325, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 16);
            this.label5.TabIndex = 117;
            this.label5.Text = "預計存檔路徑";
            // 
            // tb_savepath
            // 
            this.tb_savepath.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb_savepath.Location = new System.Drawing.Point(435, 103);
            this.tb_savepath.Name = "tb_savepath";
            this.tb_savepath.Size = new System.Drawing.Size(435, 25);
            this.tb_savepath.TabIndex = 118;
            this.tb_savepath.Text = "Z:\\";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 548);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BBG-ETF 基金規模";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox tb_FUND_TOTAL_ASSETS_DT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_FUND_CRNCY_ADJ_TOTAL_ASSETS;
        private System.Windows.Forms.TextBox tb_EQY_SH_OUT_REAL;
        private System.Windows.Forms.TextBox tb_CURR;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox tb__run_cnt;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_savepath;
    }
}

