﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvestPG
{
    public partial class FSameTrader : Form
    {
        public FSameTrader()
        {
            InitializeComponent();
        }

        private void FSameTrader_Load(object sender, EventArgs e)
        {

            // 資料庫連結,建立DataTable
            //DataLoad();

            //// GridView 抬頭說明及控制
            //dataGridView1.ReadOnly = true;
            //dataGridView1.Columns[0].Visible = false;
            //dataGridView1.Columns[1].HeaderText = "登記姓名";
            //dataGridView1.Columns[2].HeaderText = "預計外出日期";
            //dataGridView1.Columns[3].HeaderText = "預計外出時間";
            //dataGridView1.Columns[4].HeaderText = "外出說明";
            //dataGridView1.Columns[5].HeaderText = "同行人數(含本人)";
            //dataGridView1.Columns[6].HeaderText = "建立人員";
            //dataGridView1.Columns[7].HeaderText = "建立時間";
            //dataGridView1.Columns[8].HeaderText = "更新人員";
            //dataGridView1.Columns[9].HeaderText = "更新時間";
            //dataGridView1.Columns[10].HeaderText = "FLAG";
            //dataGridView1.Columns[6].Visible = false;
            //dataGridView1.Columns[7].Visible = false;
            //dataGridView1.Columns[8].Visible = false;
            //dataGridView1.Columns[9].Visible = false;
            //dataGridView1.Columns[10].Visible = false;
            //dataGridView1.AutoGenerateColumns = false;

            ////資料繫結
            //DataBind();

            ////調整控制元件 Enable
            //Edit_Status(true);
        }
    }
}
