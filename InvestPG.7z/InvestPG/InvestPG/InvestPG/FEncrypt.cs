﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExtensionMethods;
using System.Management; //This namespace is used to work with WMI classes. For using this namespace add reference of System.Management.dll 


namespace InvestPG
{
    public partial class F_Encrypt : Form
    {
        private string loguser_ ;

        public string Loguser_
        {
            set
            {
                loguser_ = value;
            }
        }

        public void SetValue()
        {
            loguser_ = loguser_ ;
        }

        public F_Encrypt()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (text_input.Text == "" )
            {
                 text_Encrypt.Text = "" ;
                 text_Decrypt.Text = "" ;
            }
            else 
            {
                if (label1.Text == "欲加密字串")
                {
                    text_Encrypt.Text = ExtensionMethods.MyExtensions.Encrypt(text_input.Text);
                    text_Decrypt.Text = ExtensionMethods.MyExtensions.Decrypt(text_Encrypt.Text);
                }
                else
                {
                    text_Encrypt.Text = ExtensionMethods.MyExtensions.Encrypt1(text_input.Text);
                    text_Decrypt.Text = ExtensionMethods.MyExtensions.Decrypt1(text_Encrypt.Text);
                }

            }

        }

        private void label1_DoubleClick(object sender, EventArgs e)
        {
            if (label1.Text == "欲加密字串")
            {label1.Text = "欲加密字串1";}
            else
            {label1.Text = "欲加密字串";}
            
        }

        private void label2_DoubleClick(object sender, EventArgs e)
        {
            if (label2.Text == "加密字串")
            {
                label2.Text = "加密字串UL";
                text_Encrypt.ReadOnly = false;
            }
            else
            {
                label2.Text = "加密字串";
                text_Encrypt.ReadOnly = true ;
            }
        }

        private void text_Encrypt_Leave(object sender, EventArgs e)
        {
            try
            {
                if ((label2.Text == "加密字串UL") || (text_input.Text == ""))
                {
                    if (text_Encrypt.Text == "")
                    { text_Decrypt.Text = ""; }
                    else
                    { text_Decrypt.Text = ExtensionMethods.MyExtensions.Decrypt1(text_Encrypt.Text); }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManagementClass MyClass = new ManagementClass("Win32_Processor");
            ManagementObjectCollection MyCollection = MyClass.GetInstances();
            string MyINFO = "";

            tx_InforBox.Clear();
            foreach (ManagementObject MyObject in MyCollection)
            {
                MyINFO = MyObject.Properties["ProcessorID"].Value.ToString();
                tx_InforBox.AppendText("CPU編號:" + MyINFO + Environment.NewLine);
                break;
            }
            ManagementClass MyClass1 = new ManagementClass("Win32_ComputerSystem");
            ManagementObjectCollection MyCollection1 = MyClass1.GetInstances();

            foreach (ManagementObject MyObject1 in MyCollection1)
            {
                MyINFO = MyObject1.Properties["TotalPhysicalMemory"].Value.ToString();
                tx_InforBox.AppendText("記憶體:" + MyINFO + Environment.NewLine);
                break;
            }

            ManagementObjectSearcher my = new ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard");

            foreach (ManagementObject MyObject2 in my.Get() )
            {
                MyINFO = MyObject2["Manufacturer"].ToString();
                tx_InforBox.AppendText("主機板製造商:" + MyINFO + Environment.NewLine);
                MyINFO = MyObject2["Product"].ToString();
                tx_InforBox.AppendText("產品:" + MyINFO + Environment.NewLine);
                MyINFO = MyObject2["SerialNumber"].ToString();
                tx_InforBox.AppendText("主機板序號:" + MyINFO + Environment.NewLine);
                break;
            }

            ManagementClass MyClass3 = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection MyCollection3 = MyClass3.GetInstances();

            foreach (ManagementObject MyObject3 in MyCollection3)
            {
                if ((bool)MyObject3["IPEnabled"] == true)
                {
                    System.Array ar;
                    ar = (System.Array)(MyObject3.Properties["IpAddress"].Value);

                    tx_InforBox.AppendText("IP:" + ar.GetValue(0).ToString() + Environment.NewLine);
                }                
                break;
            }

        }
    }
}
