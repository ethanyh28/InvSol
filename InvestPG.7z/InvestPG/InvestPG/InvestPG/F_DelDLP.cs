﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Text.RegularExpressions;


namespace InvestPG
{
        
    public partial class F_DelDLP : Form
    {
        public F_DelDLP()
        {
            
            InitializeComponent();
        }

        private void FindDir(string dir)
        {
            checkedListBox2.Items.Add(dir);

            String str = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (str != null)
            {
                checkedListBox2.Items.Add(str.Replace("\\Desktop","\\"));
            }

            //String str1 = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            //if (str1 != null)
            //{
            //    checkedListBox2.Items.Add(str1);
            //}

            //String str2 = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            //if (str2 != null)
            //{
            //    checkedListBox2.Items.Add(str2);
            //}

            //String str3 = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            //if (str3 != null)
            //{
            //    checkedListBox2.Items.Add(str3);
            //}
            Application.DoEvents();
        }

        private void FindFile(string dir)
        {
            ////在指定目錄下查詢文件，若符合查詢條件，將檔案寫入lsFile控制元件
            //DirectoryInfo Dir = new DirectoryInfo(dir);
            //try
            //{                
            //    foreach (DirectoryInfo d in Dir.GetDirectories())//查詢子目錄    
            //    {
            //        FindFile(Dir + d.ToString() + "\\");
            //        Application.DoEvents();
            //    }
                
            //    foreach (FileInfo f in Dir.GetFiles("*.dmp"))//查詢附檔名為dmp的文件  
            //    {
            //        Regex regex = new Regex(@"");//查詢檔案名稱中有關鍵字friend的文件
            //        Match m = regex.Match(f.ToString());
            //        if (m.Success == true)
            //        {
            //            checkedListBox1.Items.Add(Dir + f.ToString());
            //        }
            //        Application.DoEvents();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    //MessageBox.Show(ex.Message);
            //}

            Application.DoEvents();
        }

        private void F_DelDLP_Load(object sender, EventArgs e)
        {
            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach (DriveInfo drive in drives)
            {
                if (drive.DriveType.ToString() == "Fixed") 
                {
                    comboBox1.Items.Add(drive.ToString());
                }                
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            checkedListBox2.Items.Clear();
            FindDir(comboBox1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //            checkedListBox1.Items.Clear();
            //            FindFile(checkedListBox2.SelectedItem.ToString());
            //DialogResult myResult = MessageBox.Show("是否刪除檔案.dmp", "", MessageBoxButtons.YesNo);
            //string cmdstr = "";
            //if (myResult == DialogResult.Yes)
            //{

            //    System.Diagnostics.Process p = new System.Diagnostics.Process();
            //    p.StartInfo.FileName = "cmd.exe";
            //    p.StartInfo.Arguments = "/c del /F /S /Q /A " + "D:" + "\\外出登記簿.xls";
            //    MessageBox.Show(p.StartInfo.Arguments);
            //    //p.StartInfo.Arguments = "/F /S /Q /A " + checkedListBox2.SelectedItem.ToString()  + "\\*.dmp";
            //    p.StartInfo.UseShellExecute = false;
            //    p.StartInfo.RedirectStandardInput = true;
            //    p.StartInfo.RedirectStandardOutput = true;
            //    p.StartInfo.RedirectStandardError = true;
            //    p.StartInfo.CreateNoWindow = true;
            //    p.Start();
            //    p.Dispose();
            //}
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            for (int i = 0; i <= checkedListBox2.Items.Count -1 ;  i++)
            {
                if (checkedListBox2.GetItemChecked(i) )
                {
                    //MessageBox.Show(checkedListBox2.Items[i].ToString() );
                    
                    p.StartInfo.FileName = "cmd.exe";
                    //p.StartInfo.Arguments = "/c del /F /S /Q /A " + "D:" + "\\外出登記簿.xls";                    
                    p.StartInfo.Arguments = "/c del /F /S /Q /A " + checkedListBox2.Items[i].ToString() + "*.dmp";
                    //MessageBox.Show(p.StartInfo.Arguments);
                    p.StartInfo.UseShellExecute = false;
                    p.StartInfo.RedirectStandardInput = true;
                    p.StartInfo.RedirectStandardOutput = true;
                    p.StartInfo.RedirectStandardError = true;
                    p.StartInfo.CreateNoWindow = true;
                    p.Start();
                    
                }                
            }
            p.Dispose();
        }

    }
}
