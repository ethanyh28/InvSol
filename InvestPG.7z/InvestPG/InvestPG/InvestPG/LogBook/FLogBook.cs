﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Runtime.InteropServices;

namespace IvLogBook
{
    public partial class MainForm1 : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        string dirstr = System.IO.Directory.GetCurrentDirectory();

        //Connect Access DB 2007 Encrypt password
        string connectionString = null;
        string sql = null;
        OleDbDataAdapter datadapter;
        DataTable myDataTable;
        DataView myDataView;
        String DataStatus ; //A:add ; E:edit ; D:Del
        DataRowView drv;

        public MainForm1()
        {
            InitializeComponent();
        }

        private void MainForm1_Load(object sender, EventArgs e)
        {
            
            comboBox1.SelectedIndex = 0;
            timer1.Enabled = true;

            dateTimePicker2.Value = System.DateTime.Now.AddDays(60); //計算45天後
            dateTimePicker1.Value = System.DateTime.Now.AddDays(-90); //計算90天前
            stlUSER.Text = "登錄人員: "+ Environment.UserName ; 

           
            // 資料庫連結,建立DataTable
            DataLoad();
            
            // GridView 抬頭說明及控制
            dataGridView1.ReadOnly = true;
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].HeaderText = "登記姓名";
            dataGridView1.Columns[2].HeaderText = "預計外出日期";
            dataGridView1.Columns[3].HeaderText = "預計外出時間";
            dataGridView1.Columns[4].HeaderText = "外出說明";
            dataGridView1.Columns[5].HeaderText = "同行人數(含本人)";
            dataGridView1.Columns[6].HeaderText = "建立人員";
            dataGridView1.Columns[7].HeaderText = "建立時間";
            dataGridView1.Columns[8].HeaderText = "更新人員";
            dataGridView1.Columns[9].HeaderText = "更新時間";
            dataGridView1.Columns[10].HeaderText = "FLAG";
            dataGridView1.Columns[6].Visible = false;
            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns[8].Visible = false;
            dataGridView1.Columns[9].Visible = false;
            dataGridView1.Columns[10].Visible = false;
            dataGridView1.AutoGenerateColumns = false;

            //資料繫結
            DataBind();

            //調整控制元件 Enable
            Edit_Status(true);
        }

        //讀取資料庫資料--查詢
        private void DataLoad()
        {
            connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + dirstr + "\\Logbookdb.accdb;Persist Security Info=True;Jet OLEDB:Database Password=logbook";
            sql = "select * from logItem  ";
            //     + "Where flag_ <> 'D' and [日期] BETWEEN '" + dateTimePicker1.Text + "' and '" + dateTimePicker2.Text + "'  ";
            //if (txt_query.Text.Trim() != "")
            //{
            //    sql = sql + "and [" + comboBox1.Text.Trim() + "] LIKE '%" + txt_query.Text.Trim() + "%'";
            //}
            sql = sql + "order by  [登記人] ,[日期] DESC , [時間] DESC ";

            //資料庫連結,建立DataTable
            using (OleDbConnection cnn = new OleDbConnection(connectionString))
            {
                cnn.Open();
                using (OleDbCommand cmd = new OleDbCommand(sql, cnn))
                {
                    using (OleDbDataReader DataReader = cmd.ExecuteReader())
                    {
                        using (DataTable dt = new DataTable())
                        {
                            dt.Load(DataReader);
                            dt.DefaultView.RowFilter = "flag_ <> 'D' ";
                            dt.DefaultView.RowFilter = dt.DefaultView.RowFilter
                                                      + " AND ( [日期] >= '" + dateTimePicker1.Text + "' AND [日期] <= '" + dateTimePicker2.Text + "') ";
                            if (txt_query.Text.Trim() != "")
                            {
                                dt.DefaultView.RowFilter = dt.DefaultView.RowFilter
                                                         + "and [" + comboBox1.Text.Trim() + "] LIKE '%" + txt_query.Text.Trim() + "%'";
                            }
                            myDataTable = dt;
                        }
                    }
                }
            }
            myDataView = new DataView(myDataTable);
            myDataView.AllowEdit = true;
            myDataView.AllowNew = true;
            myDataView.AllowDelete = true;

            bindingSource1.DataSource = myDataTable;

            bindingNavigator1.BindingSource = bindingSource1;

            dataGridView1.DataSource = bindingSource1;
        }

        //編輯元件資料繫結
        private void DataBind()
        {
            txt_USERID.DataBindings.Clear();
            txt_num.DataBindings.Clear();
            txt_Desc.DataBindings.Clear();
            txt_bookdate.DataBindings.Clear();
            txt_booktime.DataBindings.Clear();

            txt_USERID.DataBindings.Add("Text", bindingSource1, "登記人");
            txt_num.DataBindings.Add("Text", bindingSource1, "隨行人數");
            txt_Desc.DataBindings.Add("Text", bindingSource1, "外出說明");
            txt_bookdate.DataBindings.Add("Text", bindingSource1, "日期");
            txt_booktime.DataBindings.Add("Text", bindingSource1, "時間");
        }

        //按鈕控制
        private void Edit_Status(Boolean vBool)
        {            
            bindingNavigatorMovePreviousItem.Enabled = vBool;
            bindingNavigatorMoveNextItem.Enabled = vBool;
            bindingNavigatorMoveFirstItem.Enabled = vBool;
            bindingNavigatorMoveLastItem.Enabled = vBool;
            toolStripButton1.Enabled = vBool;
            toolStripButton2.Enabled = vBool;
            toolStripButton5.Enabled = vBool;

            toolStripButton3.Enabled = !vBool;
            toolStripButton4.Enabled = !vBool;

            //編輯區控制
            txt_USERID.ReadOnly = vBool;
            txt_bookdate.ReadOnly = vBool;
            txt_booktime.ReadOnly = vBool;
            txt_num.ReadOnly = vBool;
            txt_Desc.ReadOnly = vBool;

        }

        //資料異動控制,新增刪除修改後,資料重讀及定位
        private void DataUpdate(String vRecordStatus)
        {
            String vUser = "";
            String vDate = "";
            String vTime = "";

            OleDbConnection cnn = new OleDbConnection(connectionString);
            cnn.Open();            
            OleDbDataAdapter dtapter = new OleDbDataAdapter(sql, cnn);

            if (vRecordStatus == "A" || vRecordStatus == "E")
            {
                // 判斷是否有重覆資料 登記人+日期+時間
                sql = " select  * from logItem"
                     +" WHERE 登記人 = '" + txt_USERID.Text + "' "
                     +" AND 日期 = '" + txt_bookdate.Text + "' "
                     +" AND 時間 = '" + txt_booktime.Text + "' " ;

                dtapter.SelectCommand = cnn.CreateCommand() ;
                dtapter.SelectCommand.CommandText = sql;
                DataSet ds = new DataSet();
                dtapter.Fill(ds, "logItem");

                if (ds.Tables[0].Rows.Count == 0)
                {
                    sql = "INSERT INTO logItem(登記人,日期,時間,外出說明,隨行人數,建立人員,建立時間,loguser_,logdate_,flag_) "
                         + "VALUES(@登記人,@日期,@時間,@外出說明,@隨行人數,@建立人員,@建立時間,@loguser_,@logdate_,@flag_)";
                    dtapter.InsertCommand = cnn.CreateCommand();
                    dtapter.InsertCommand.CommandText = sql;
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("登記人", txt_USERID.Text));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("日期", txt_bookdate.Text));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("時間", txt_booktime.Text));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("外出說明", txt_Desc.Text.Trim()));
                    if (txt_num.Text.Trim() != "")
                    {
                        dtapter.InsertCommand.Parameters.Add(new OleDbParameter("隨行人數", Convert.ToInt32(txt_num.Text.Trim()).ToString()));
                    }
                    else
                    {
                        dtapter.InsertCommand.Parameters.Add(new OleDbParameter("隨行人數", "1"));
                    }
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("建立人員", Environment.UserName));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("建立時間", System.DateTime.Now.ToString()));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("loguser_", Environment.UserName));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("logdate_", System.DateTime.Now.ToString()));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("flag_", "A"));
                    dtapter.InsertCommand.ExecuteNonQuery();

                    
                }
                else 
                {

                    sql = "UPDATE logItem SET flag_ = @flag_ , 隨行人數 = @隨行人數 ,loguser_ = @loguser_  ,logdate_ = @logdate_ ,外出說明 = @外出說明 "
                         + " WHERE 登記人 = @登記人 AND 日期 = @日期 AND 時間 = @時間 ";
                    dtapter.UpdateCommand = cnn.CreateCommand();
                    dtapter.UpdateCommand.CommandText = sql;
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("flag_", "M"));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("隨行人數", Convert.ToInt32(txt_num.Text.Trim()).ToString()));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("loguser_", Environment.UserName));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("logdate_", System.DateTime.Now.ToString()));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("外出說明", txt_Desc.Text.Trim()));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("登記人", txt_USERID.Text));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("日期", txt_bookdate.Text));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("時間", txt_booktime.Text));                    
                    if (vRecordStatus == "A")
                    {
                        DialogResult result = MessageBox.Show("此筆資料已存在，是否繼續異動資料??", "新增提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (result == DialogResult.Yes)
                        { 
                            dtapter.UpdateCommand.ExecuteNonQuery();  
                        }                        
                    }
                    else
                    {
                        dtapter.UpdateCommand.ExecuteNonQuery();
                    }
                    
                }
            }
            else if (vRecordStatus == "D")
            {
                sql = "UPDATE logItem SET flag_ = @flag_ ,loguser_ = @loguser_  ,logdate_ = @logdate_ "
                     + " WHERE 登記人 = @登記人 AND 日期 = @日期 AND 時間 = @時間 ";
                dtapter.UpdateCommand = cnn.CreateCommand();
                dtapter.UpdateCommand.CommandText = sql;
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("flag_", "D"));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("loguser_", Environment.UserName));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("logdate_", System.DateTime.Now.ToString()));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("登記人", txt_USERID.Text));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("日期", txt_bookdate.Text));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("時間", txt_booktime.Text));
                dtapter.UpdateCommand.ExecuteNonQuery();
            }
            dtapter.Dispose();
            System.Threading.Thread.Sleep(600); //延遲處理時,等待完成異動!
            //按鈕控制
            vUser = txt_USERID.Text;
            vDate = txt_bookdate.Text;
            vTime = txt_booktime.Text;

            Edit_Status(true);
            DataLoad();

            // 定位回編輯資料
            int row = this.dataGridView1.Rows.Count;

            for (int i = 0; i < row; i++)
            {
                if ((vUser == dataGridView1[1, i].Value.ToString())
                   && (vDate == dataGridView1[2, i].Value.ToString())
                   && (vTime == dataGridView1[3, i].Value.ToString()))
                {
                    this.dataGridView1.CurrentCell = this.dataGridView1[1, i];//定位到相同的儲存格
                    break;
                }
            }
            tabControl1.SelectedIndex = 0;
        }
     

        private void timer1_Tick(object sender, EventArgs e)
        {
            stlbl_date.Text = System.DateTime.Now.ToLongDateString() ;
            stlbl_time.Text = System.DateTime.Now.ToLongTimeString() ;
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            
        }

        private void dp_bookdate_ValueChanged(object sender, EventArgs e)
        {
            txt_bookdate.Text = dp_bookdate.Text;
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                DialogResult result = MessageBox.Show("是否繼續刪除此筆資料??", "刪除提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                   DataStatus = "D";
                   DataUpdate("D");
                }
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            DataStatus = "A";
            tabControl1.SelectedIndex = 1 ;
            tabPage1.Text = "資料明細-新增";
            txt_USERID.Focus();
            Edit_Status(false);
            ////建立DataView
            myDataView = new DataView(myDataTable);
            DataRowView drv = myDataView.AddNew();
            txt_USERID.Text = Environment.UserName;
            dp_bookdate.Value = System.DateTime.Now;
            txt_bookdate.Text = dp_bookdate.Value.ToString("yyyyMMdd");
            txt_booktime.Text = System.DateTime.Now.ToString("HH:mm");
            txt_num.Text = "1";
            txt_Desc.Text = "";
            drv["登記人"] = txt_USERID.Text;
            drv["日期"] = txt_bookdate.Text;
            drv["時間"] = txt_booktime.Text;
            drv["隨行人數"] = txt_num.Text;
            drv["外出說明"] = txt_Desc.Text.Trim();
            //drv.EndEdit();
        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btn_Query_Click(object sender, EventArgs e)
        {
            DataLoad();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (txt_USERID.Text.Trim() == "")
            {
                MessageBox.Show("請輸入登記姓名!");
                txt_USERID.Focus();
                return;
            }

            if (txt_bookdate.Text.Trim() == "")
            {
                MessageBox.Show("請輸入外出日期!");
                txt_bookdate.Focus();
                return;
            }

            if (txt_booktime.Text.Trim() == ":")
            {
                MessageBox.Show("請輸入外出時間!");
                txt_booktime.Focus();
                return;
            }

            if (txt_Desc.Text.Trim() == "")
            {
                MessageBox.Show("請輸入外出說明!");
                txt_Desc.Focus();
                return;
            }
            //資料庫異動
            DataUpdate(DataStatus);
            DataStatus = "";
            tabPage1.Text = "資料明細";
            //System.Threading.Thread.Sleep(500); //延遲處理時,等待完成異動!
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            //重讀資料
            DataLoad();
            //控制按鈕狀態
            Edit_Status(true);
            DataStatus = "";
            tabPage1.Text = "資料明細";
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                DataStatus = "E";
                tabControl1.SelectedIndex = 1;
                tabPage1.Text = "資料明細-修改";
                Edit_Status(false); 
            }
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (DataStatus == "A" || DataStatus =="E") 
            {
                tabControl1.SelectTab(1);
            }

        }

        private void 顯示其他欄位ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Columns[6].Visible)
            {
                FieldDs_MenuItem.Text = "顯示其他資訊";
            }
            else
            {
                FieldDs_MenuItem.Text = "隱藏其他資訊";
            }
            dataGridView1.Columns[6].Visible = !dataGridView1.Columns[6].Visible ;
            dataGridView1.Columns[7].Visible = !dataGridView1.Columns[7].Visible;
            dataGridView1.Columns[8].Visible = !dataGridView1.Columns[8].Visible;
            dataGridView1.Columns[9].Visible = !dataGridView1.Columns[9].Visible;
        }
    }
}
