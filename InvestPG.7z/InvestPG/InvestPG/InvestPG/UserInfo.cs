﻿///<summary>
///User info class
///</summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvestPG
{
    public class UserInfo
    {
        private string strUserName;
        private string strPassword;

        public string UserName
        {
            get { return strUserName; }
            set { strUserName = value; }
        }

        public string Password
        {
            get { return strPassword; }
            set { strPassword = value; }
        }

        public UserInfo()
        {
            strUserName = "";
            strPassword = "";
        }
    }
}
