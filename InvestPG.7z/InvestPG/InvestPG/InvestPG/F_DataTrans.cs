﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using ExtensionMethods;
using System.Data.OracleClient;

namespace InvestPG
{
    public partial class F_DataTrans : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);


        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath;

        //寫入SQL 資料庫
        string connectionString = null;
        public SqlConnection cnn;
        public SqlConnection Excel_cnn;

        //MSSQL connection string 
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";

        string loguser_ = "";

        SqlCommand cmd;
        string sql = null;

        //Oracle connection string 
        public OracleConnection cnn_ora;
        string connectionString_ora = null;
        string server_ora = "";
        string database_ora = "";
        string user_ora = "";
        string password_ora = "";

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release to Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public F_DataTrans()
        {
            InitializeComponent();
            loguser_ = Environment.UserName;

            //取得ini檔案路徑
            dirstr = dirstr + "\\InvestPG.ini";
            dateTimePicker1.Value = DateTime.Now;
            timer1.Enabled = true;
            toolStripStatusLabel2.Text = "";
        }

        public void ConnectDB(string database_str)
        {
            //連絡資料庫 MSSQL
            StringBuilder data = new StringBuilder(255);
            database_ = database_str ;
            //讀取資料庫連結參數
            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();
            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 ";
            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            // Connection 連結 Open
            cnn.Open();
        }

        public void ConnectDB_ORA(string database_str)
        {
            //連結資料 ORA_CTLGA
            StringBuilder data_ora = new StringBuilder(255);
            database_ora = database_str;//"ORA_CTLGA";

            GetPrivateProfileString(database_ora, "server_", "", data_ora, 255, dirstr);
            server_ora = data_ora.ToString();
            GetPrivateProfileString(database_ora, "user_", "", data_ora, 255, dirstr);
            user_ora = data_ora.ToString();
            GetPrivateProfileString(database_ora, "password_", "", data_ora, 255, dirstr);
            password_ora = data_ora.ToString();

            connectionString_ora = "Data Source=" + server_ora
                                    + ";Persist Security Info = True; User ID=" + user_ora
                                    + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_ora)
                                    + ";Unicode = True ";

            if (cnn_ora != null)
            {
                cnn_ora.Close();
                cnn_ora.ConnectionString = connectionString_ora;
            }
            else
            {
                cnn_ora = new OracleConnection(connectionString_ora);
            }

            cnn_ora.Open();
        }

        private void label1_DoubleClick(object sender, EventArgs e)
        {
            if (listBox2.Visible == true)
            {
                listBox2.Visible = false;
            }
            else
            { listBox2.Visible = true; }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string vDt_;
            DateTime vvDt;
            vvDt = dateTimePicker1.Value;
            vDt_ = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");

            ConnectDB("PositionDB");
            int i = 1;
            if (cnn != null && cnn.State == ConnectionState.Open)
            {
                // 執行轉檔
                this.Cursor = Cursors.WaitCursor;
                for (i = 1; i <= 4; i++)
                {
                    switch (i)
                    {
                        case 1:
                            sql = "EXEC pr_man_performance_rpt0_I9 @dt ,'0' ";
                            break;
                        case 2:
                            sql = "EXEC pr_man_performance_rpt0_I9 @dt ,'1' ";
                            break;
                        case 3:
                            sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'1','0' ";
                            break;
                        case 4:
                            sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'0','0' ";
                            break;
                            //case 4:
                            //    sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'1','2' ";
                            //    break;
                            //case 5:
                            //    sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'1','3' ";
                            //    break;
                            //case 6:
                            //    sql = "EXEC pr_man_performance_rpt4_I9 @dt ,'0' ";
                            //    break;
                    }
                    cmd = new SqlCommand(sql, cnn);
                    cmd.CommandTimeout = 10000;
                    cmd.Parameters.Add(new SqlParameter("dt", vDt_));
                    cmd.ExecuteNonQuery();
                    Application.DoEvents();
                    cmd.Dispose();
                    //MessageBox.Show(sql);
                }
                this.Cursor = Cursors.Default;
                MessageBox.Show("轉檔完成!!");

            }
            else
            {
                MessageBox.Show("資料庫連結失敗,請查明原因!!");
            }
        }

        private void checkBox2_Click(object sender, EventArgs e)
        {
            // 全選與全不選
            for (int i = 0; i <= checkedListBox2.Items.Count - 1; i++)
            {
                checkedListBox2.SetItemChecked(i, checkBox2.Checked);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ConnectDB("BSDATA");
                ConnectDB_ORA("ORA_CTLGA");
                // 執行轉檔
                String vSelstr, TableName;
                vSelstr = "";
                TableName = "";
                int i = 1;
                int ii = 0;
                int j = 0;

                this.Cursor = Cursors.WaitCursor ;

                for (i = 0; i <= checkedListBox2.Items.Count - 1; i++)
                {
                    if (checkedListBox2.GetItemChecked(i))
                    {
                        vSelstr = vSelstr + "Y";
                        ii = ii + 1;
                    }
                    else
                    { vSelstr = vSelstr + "N"; }
                }

                if (ii > 0)
                {
                    //轉入原始TABLE
                    for (j = 0; j <= listBox2.Items.Count - 1; j++)
                    {
                        
                        TableName = listBox2.Items[j].ToString();
                        if (TableName.Substring(0, 3) == "SW.") //只轉SW.
                        {
                            toolStripStatusLabel2.Text = TableName;
                            OracleCommand OraComm = new OracleCommand();                           
                            OraComm.Connection = cnn_ora;
                            OraComm.CommandText = "SELECT * FROM " + TableName;
                            OracleDataReader oraReader = OraComm.ExecuteReader();

                            SqlCommand sqlComm = new SqlCommand();
                            sqlComm.Connection = cnn;

                            if (oraReader.HasRows)
                            {
                                sqlComm.CommandText = "DELETE FROM " + TableName;
                                sqlComm.ExecuteNonQuery();
                                // 讀取 ORA資料
                                OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm);

                                DataSet OraDataSet = new DataSet();
                                OraDataSet.Clear();
                                oraDataadapter.Fill(OraDataSet, TableName);

                                // 大量寫入
                                SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                                sqlbulkcopy.BatchSize = 1000; //每次傳輸行數
                                sqlbulkcopy.NotifyAfter = 1000; //進度提示的行數
                                sqlbulkcopy.BulkCopyTimeout = 0;
                                sqlbulkcopy.DestinationTableName = TableName;
                                sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                                Application.DoEvents();

                            }
                            oraReader.Close();
                            OraComm.Dispose();
                            sqlComm.Dispose();
                        }
                    }

                    // 寫入組合基本資料                    
                    sql = "EXEC pr_updatedata_ga @selectitems ";
                    cmd = new SqlCommand(sql, cnn);
                    cmd.CommandTimeout = 1000;
                    cmd.Parameters.Add(new SqlParameter("selectitems", vSelstr));
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                cnn_ora.Close();
                cnn_ora.Dispose();

                cnn.Close();
                cnn.Dispose();
                toolStripStatusLabel2.Text =  "" ;
                this.Cursor = Cursors.Default;
                MessageBox.Show("轉檔完成!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                toolStripStatusLabel2.Text = "";
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //String vTime = "";
            //vTime = DateTime.Now.Hour.ToString("00") + DateTime.Now.Minute.ToString("00") + DateTime.Now.Second.ToString("00");
            //toolStripStatusLabel1.Text = DateTime.Now.ToString();
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
