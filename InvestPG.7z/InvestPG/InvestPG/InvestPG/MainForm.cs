﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using IvLogBook;
//using MDIForm;
using ExtensionMethods;

namespace InvestPG
{
    public partial class FMain : Form
    {

        string loguser_ = "";
        string dirstr = "";

        private UserInfo uiLogin;

        public FMain()
        {
            InitializeComponent();
            stlUSER.Text = "登入者：" + Environment.UserName;
            loguser_ = Environment.UserName; ;
            // INI 設定檔資訊
            //string dirstr = System.IO.Directory.GetCurrentDirectory();
            menuStrip1.MdiWindowListItem = mumWindow; //子表單名稱清單顯示在 numWindows項目中

            //ActiveForm("mumDataTrans");
            ActiveForm("mumBalTrans");
        }

        private void ActiveForm(String vName)
        {

            if (vName == "mumClose") 
            {
                this.Close();
            }
            //else if (vName == "munLogBook") //外出登記簿
            //{
            //    WF_Logbook frmChild = new WF_Logbook();   //宣告frmChild為表單實體
            //    int num = this.MdiChildren.Length;         //取得子表單的數量
            //    frmChild.Text = frmChild.Text;  //設定子表單標題文字
            //    MDIChildShow(frmChild);
            //    ////frmChild.cnn = cnn;
            //    ////frmChild.loguser_ = loguser_;
            //}
            //else if (vName == "mumSameTrader")
            //{
            //    FSameTrader frmChild = new FSameTrader();   //宣告frmChild為表單實體
            //    int num = this.MdiChildren.Length;         //取得子表單的數量
            //    frmChild.Text = frmChild.Text;  //設定子表單標題文字
            //    MDIChildShow(frmChild);
            //    ////frmChild.cnn = cnn;
            //    ////frmChild.loguser_ = loguser_;
            //}
            else if (vName == "mumEncrypt")
            {
                F_Encrypt frmChild = new F_Encrypt();   //宣告frmChild為表單實體
                int num = this.MdiChildren.Length;         //取得子表單的數量
                frmChild.Text = frmChild.Text;  //設定子表單標題文字                
                MDIChildShow(frmChild);
                ////frmChild.cnn = cnn;
                ////frmChild.loguser_ = loguser_;
            }
            else if (vName == "mumDataTrans")
            {
                F_DataTrans frmChild = new F_DataTrans();   //宣告frmChild為表單實體
                int num = this.MdiChildren.Length;         //取得子表單的數量
                frmChild.Text = frmChild.Text;  //設定子表單標題文字                
                MDIChildShow(frmChild);
                ////frmChild.cnn = cnn;
                ////frmChild.loguser_ = loguser_;
                
            }
            else if (vName == "mumNewTrans")
            {
                F_BalTrans frmChild = new F_BalTrans();   //宣告frmChild為表單實體
                int num = this.MdiChildren.Length;         //取得子表單的數量
                frmChild.Text = frmChild.Text;  //設定子表單標題文字    
                frmChild.Loguser_ = loguser_;
                //frmChild.Dirstr_ = dirstr ;
                MDIChildShow(frmChild);
            }
            //else if (vName == "mumDlpLog")
            //{
            //    F_DelDLP frmChild = new F_DelDLP();   //宣告frmChild為表單實體
            //    int num = this.MdiChildren.Length;         //取得子表單的數量
            //    frmChild.Text = frmChild.Text;  //設定子表單標題文字
            //    MDIChildShow(frmChild);
            //    ////frmChild.cnn = cnn;
            //    ////frmChild.loguser_ = loguser_;
            //}
            //else if (vName == "mumCmoneyTrans")
            //{                
            //    //F_GetCMoneyData frmChild = new F_GetCMoneyData();   //宣告frmChild為表單實體
            //    //int num = this.MdiChildren.Length;         //取得子表單的數量
            //    //frmChild.Text = frmChild.Text;  //設定子表單標題文字
            //    //MDIChildShow(frmChild);
            //    ////frmChild.cnn = cnn;
            //    ////frmChild.loguser_ = loguser_;
            //}
            else if (vName == "mumBalTrans")
            {
                F_BalTrans frmChild = new F_BalTrans();   //宣告frmChild為表單實體
                int num = this.MdiChildren.Length;         //取得子表單的數量
                frmChild.Text = frmChild.Text;  //設定子表單標題文字    
                frmChild.Loguser_ = loguser_;
                //frmChild.Dirstr_ = dirstr ;
                MDIChildShow(frmChild);
            }
        }

        private void MDIChildShow(Form newMDIChild)
        {
            //檢查父視窗每一個子視窗
            foreach (Form f in this.MdiChildren)
            {
                //如果子視窗已經存在
                if (f.Name == newMDIChild.Name)
                {
                    //將該子視窗設為視窗
                    f.Focus();
                    return;
                }
            }
            newMDIChild.MdiParent = this;                        //指定父表單 
            newMDIChild.WindowState = FormWindowState.Maximized;
            newMDIChild.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            stlbl_date.Text = System.DateTime.Now.ToLongDateString();
            stlbl_time.Text = System.DateTime.Now.ToLongTimeString()
                             + "  ("
                             + System.DateTime.Now.ToString("dddd", new System.Globalization.CultureInfo("zh-cn"))
                             + ")";
        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void horizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void verticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void munLogBook_Click(object sender, EventArgs e)
        {
            ActiveForm(((ToolStripMenuItem)sender).Name);
        }

        private void FMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult Result = MessageBox.Show("是否關閉平台??", "結束平台", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (Result == DialogResult.No)
            {
                  e.Cancel = true ;
            }
        }

    }
}
