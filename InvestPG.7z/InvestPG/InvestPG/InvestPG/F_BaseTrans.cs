﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using ExtensionMethods;
using System.Data.OracleClient;


namespace InvestPG
{
    public partial class F_BaseTrans : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath;

        //寫入SQL 資料庫
        string connectionString = null;
        public SqlConnection cnn;
        public SqlConnection Excel_cnn;

        //MSSQL connection string 
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";

        string loguser_ = "";

        SqlCommand cmd;
        string sql = null;

        //Oracle connection string 
        public OracleConnection cnn_ora;
        string connectionString_ora = null;
        string server_ora = "";
        string database_ora = "";
        string user_ora = "";
        string password_ora = "";

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release to Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public F_BaseTrans()
        {
            InitializeComponent();
            loguser_ = Environment.UserName;
            //取得ini檔案路徑
            dirstr = dirstr + "\\InvestPG.ini";

        }

        private void checkBox2_Click(object sender, EventArgs e)
        {
            // 全選與全不選
            for (int i = 0; i <= checkedListBox2.Items.Count - 1; i++)
            {
                checkedListBox2.SetItemChecked(i, checkBox2.Checked);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //連絡資料庫 MSSQL
            StringBuilder data = new StringBuilder(255);
            database_ = "BSDATA";
            //database_ = "InvestDB";
            int i = 0;
            int ii = 0;
            int j = 0;

            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 "; 
            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            cnn.Open();

            //連結資料 ORA_CTLGA
            StringBuilder data_ora = new StringBuilder(255);
            database_ora = "ORA_CTLGA";

            GetPrivateProfileString(database_ora, "server_", "", data_ora, 255, dirstr);
            server_ora = data_ora.ToString();
            GetPrivateProfileString(database_ora, "user_", "", data_ora, 255, dirstr);
            user_ora = data_ora.ToString();
            GetPrivateProfileString(database_ora, "password_", "", data_ora, 255, dirstr);
            password_ora = data_ora.ToString();

            connectionString_ora = "Data Source=" + server_ora
                                    + ";Persist Security Info = True; User ID=" + user_ora
                                    + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_ora)
                                    + ";Unicode = True ";

            if (cnn_ora != null)
            {
                cnn_ora.Close();
                cnn_ora.ConnectionString = connectionString_ora;
            }
            else
            {
                cnn_ora = new OracleConnection(connectionString_ora);
            }

            cnn_ora.Open();


            if (cnn != null && cnn.State == ConnectionState.Open)
            {
                // 執行轉檔
                String vSelstr , TableName;
                vSelstr = "";
                TableName = "";

                for (i = 0; i <= checkedListBox2.Items.Count - 1; i++)
                {
                    if (checkedListBox2.GetItemChecked(i))
                    {
                        vSelstr = vSelstr + "Y";
                        ii = ii + 1;
                    }
                    else
                    { vSelstr = vSelstr + "N"; }
                }

                if (ii > 0)
                {
                    //轉入原始TABLE
                    for (j = 0; j <= listBox2.Items.Count - 1; j++)
                    {
                        TableName = listBox2.Items[j].ToString();

                        OracleCommand OraComm = new OracleCommand();
                        OraComm.Connection = cnn_ora;
                        OraComm.CommandText = "SELECT * FROM " + TableName ;
                        OracleDataReader oraReader = OraComm.ExecuteReader();

                        SqlCommand sqlComm = new SqlCommand();
                        sqlComm.Connection = cnn;

                        if (oraReader.HasRows)
                        {
                            sqlComm.ExecuteNonQuery();
                            sqlComm.CommandText = "DELETE FROM " + TableName;
                            // 讀取 ORA資料
                            OracleDataAdapter oraDataadapter = new OracleDataAdapter(OraComm);

                            DataSet OraDataSet = new DataSet();
                            OraDataSet.Clear();
                            oraDataadapter.Fill(OraDataSet, TableName);

                            // 大量寫入庫存
                            SqlBulkCopy sqlbulkcopy = new SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction);
                            sqlbulkcopy.BatchSize = 10000;
                            sqlbulkcopy.DestinationTableName = TableName;
                            sqlbulkcopy.WriteToServer(OraDataSet.Tables[0]);
                            Application.DoEvents();

                        }
                        oraReader.Close();
                        OraComm.Dispose();
                        sqlComm.Dispose();
                    }



                    // 寫入組合基本資料
                    this.Cursor = Cursors.WaitCursor;
                    sql = "EXEC pr_updatedata_ga @selectitems ";

                    cmd = new SqlCommand(sql, cnn);
                    cmd.CommandTimeout = 1000;
                    cmd.Parameters.Add(new SqlParameter("selectitems", vSelstr));
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();

                    //sql = " EXEC pr_pos_class @dt";
                    //cmd = new SqlCommand(sql, cnn);
                    //cmd.CommandTimeout = 1000;
                    //cmd.Parameters.Add(new SqlParameter("dt", System.DateTime.Now));
                    //cmd.ExecuteNonQuery();
                    //cmd.Dispose();
                    this.Cursor = Cursors.Default;
                    MessageBox.Show("轉檔完成!!");
                }

            }
            else
            {
                MessageBox.Show("資料庫連結失敗,請查明原因!!");
            }
        }

        private void label2_DoubleClick(object sender, EventArgs e)
        {
            if (label2.Text == "庫存資料A")
            { label2.Text = "庫存資料M"; }
            else if (label2.Text == "庫存資料M")
            { label2.Text = "庫存資料U"; }
            else if (label2.Text == "庫存資料U")
            { label2.Text = "庫存資料A"; }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string vDt_ ;
            DateTime vvDt ;
            vvDt = dateTimePicker1.Value ;
            vDt_ = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");

            //連絡資料庫 MSSQL
            StringBuilder data = new StringBuilder(255);
            database_ = "PositionDB";
            int i = 1;

            //讀取資料庫連結參數
            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_);
            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            // Connection 連結 Open
            cnn.Open(); 
            if (cnn != null && cnn.State == ConnectionState.Open)
            {
                // 執行轉檔
                this.Cursor = Cursors.WaitCursor;
                for (i = 1; i <= 6; i++ )
                {
                    switch (i)
                    {
                        case 1: sql = "EXEC pr_man_performance_rpt0 @dt ,'0' ";
                            break;
                        case 2: sql = "EXEC pr_man_performance_rpt0 @dt ,'1' ";
                            break;
                        case 3: sql = "EXEC pr_man_performance_rpt3 @dt ,'1','0' ";
                            break;
                        case 4: sql = "EXEC pr_man_performance_rpt3 @dt ,'1','2' ";
                            break;
                        case 5: sql = "EXEC pr_man_performance_rpt3 @dt ,'1','3' ";
                            break;
                        case 6: sql = "EXEC pr_man_performance_rpt4 @dt ,'0' ";
                            break;
                    }
                    cmd = new SqlCommand(sql, cnn);
                    cmd.CommandTimeout = 10000;
                    cmd.Parameters.Add(new SqlParameter("dt", vDt_));
                    cmd.ExecuteNonQuery();
                    Application.DoEvents();
                    cmd.Dispose();
                    //MessageBox.Show(sql);
                }
                this.Cursor = Cursors.Default;
                MessageBox.Show("轉檔完成!!");

            }
            else
            {
                MessageBox.Show("資料庫連結失敗,請查明原因!!");
            }
        }

        private void F_BaseTrans_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Now;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

//login information
//
//[PositionDB]
//server_=P-2523-600G1\SQLEXPRESS
//database_=PositionDB
//user_=ppview
//password_=Ir2Os7aFV7ABdLNs1i9Pww==
//[InvestDB]
//server_=P-2523-600G1\SQLEXPRESS
//database_=InvestDB
//user_=invuser
//password_=VoY7um5JnYqH7GoSCZZAAA==
//[OR_CTLGA]
//database_=CTLGA
//user_=niiuser
//password_=zbmTkmT8GbXLj822qTkimA==
//[OR_METUAT]
//database_=METUAT
//user_=sw
//password_=il/vWRUBS0s=
//[OR_CTLUAT]
//database_=CTLUAT
//user_=sw
//password_=il/vWRUBS0s=
