﻿namespace InvestPG
{
    partial class F_Encrypt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.text_input = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.text_Encrypt = new System.Windows.Forms.TextBox();
            this.text_Decrypt = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tx_InforBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(38, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "欲加密字串";
            this.label1.DoubleClick += new System.EventHandler(this.label1_DoubleClick);
            // 
            // text_input
            // 
            this.text_input.Location = new System.Drawing.Point(126, 58);
            this.text_input.Name = "text_input";
            this.text_input.Size = new System.Drawing.Size(273, 22);
            this.text_input.TabIndex = 1;
            this.text_input.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(38, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "加密字串";
            this.label2.DoubleClick += new System.EventHandler(this.label2_DoubleClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(38, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "解密字串";
            // 
            // text_Encrypt
            // 
            this.text_Encrypt.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.text_Encrypt.Location = new System.Drawing.Point(126, 105);
            this.text_Encrypt.Name = "text_Encrypt";
            this.text_Encrypt.ReadOnly = true;
            this.text_Encrypt.Size = new System.Drawing.Size(273, 22);
            this.text_Encrypt.TabIndex = 4;
            this.text_Encrypt.Leave += new System.EventHandler(this.text_Encrypt_Leave);
            // 
            // text_Decrypt
            // 
            this.text_Decrypt.BackColor = System.Drawing.SystemColors.Info;
            this.text_Decrypt.Location = new System.Drawing.Point(126, 148);
            this.text_Decrypt.Name = "text_Decrypt";
            this.text_Decrypt.ReadOnly = true;
            this.text_Decrypt.Size = new System.Drawing.Size(273, 22);
            this.text_Decrypt.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 219);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 30);
            this.button1.TabIndex = 6;
            this.button1.Text = "查詢電腦資訊";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tx_InforBox
            // 
            this.tx_InforBox.BackColor = System.Drawing.Color.White;
            this.tx_InforBox.Location = new System.Drawing.Point(126, 218);
            this.tx_InforBox.Multiline = true;
            this.tx_InforBox.Name = "tx_InforBox";
            this.tx_InforBox.ReadOnly = true;
            this.tx_InforBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tx_InforBox.Size = new System.Drawing.Size(374, 310);
            this.tx_InforBox.TabIndex = 7;
            this.tx_InforBox.TabStop = false;
            // 
            // F_Encrypt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 590);
            this.Controls.Add(this.tx_InforBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.text_Decrypt);
            this.Controls.Add(this.text_Encrypt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.text_input);
            this.Controls.Add(this.label1);
            this.Name = "F_Encrypt";
            this.ShowIcon = false;
            this.Text = "加解密字串";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_input;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox text_Encrypt;
        private System.Windows.Forms.TextBox text_Decrypt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tx_InforBox;
    }
}