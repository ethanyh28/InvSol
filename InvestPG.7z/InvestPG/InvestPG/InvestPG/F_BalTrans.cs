﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using ExtensionMethods;
using System.Data.OleDb;
using System.IO;
using System.Diagnostics;

using Event = Bloomberglp.Blpapi.Event;
using Message = Bloomberglp.Blpapi.Message;
using Name = Bloomberglp.Blpapi.Name;
using Request = Bloomberglp.Blpapi.Request;
using Service = Bloomberglp.Blpapi.Service;
using Session = Bloomberglp.Blpapi.Session;
using SessionOptions = Bloomberglp.Blpapi.SessionOptions;
using Element = Bloomberglp.Blpapi.Element;

using Excel = Microsoft.Office.Interop.Excel;


namespace InvestPG
{
    public partial class F_BalTrans : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        // TODO 變數宣告

        //INI 設定檔資訊
        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath + "\\InvestPG.ini";
        StringBuilder data = new StringBuilder(255);

        // MDI 傳遞變變到子form
        private string loguser_;
        public string Loguser_
        {
            set
            {
                loguser_ = value ;
            }
        }

        public void SetValue()
        {
            loguser_ = loguser_;
        }
       
        //MSSQL connection string 
        string connectionString = null;
        public SqlConnection cnn;
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";
        string Str_err = "";

        SqlCommand cmd;
        string sql = null;

        //EXCEL connection strging
        public SqlConnection Excel_cnn;

        //日期
        DateTime vvDt;
        string running_time = "";

        //MSSQL 連結參數
        private void setSQL_info()
        {
            //組合資料庫 MSSQL
            if (tabControl1.SelectedTab.Name == "tabPage1") //績效表
            {
                database_ = "PositionDB";
            }
            else if (tabControl1.SelectedTab.Name == "tabPage4") //信用額度
            {
                database_ = "CPCredit";
            }
            else if (tabControl1.SelectedTab.Name == "tabPage5") //金控報表F18_F19
            {
                database_ = "FH-PRT";
            }
            else if (tabControl1.SelectedTab.Name == "tabPage99") //BBG-GET
            {
                database_ = "PositionDB";
            }
            else //累積分層表 or 利關人比對表 
            {
                database_ = "INVEST";
            }

            GetPrivateProfileString(database_, "server_", "", data, 255, dirstr);
            server_ = data.ToString();
            GetPrivateProfileString(database_, "database_", "", data, 255, dirstr);
            database_ = data.ToString();
            GetPrivateProfileString(database_, "user_", "", data, 255, dirstr);
            user_ = data.ToString();
            GetPrivateProfileString(database_, "password_", "", data, 255, dirstr);
            password_ = data.ToString();

            connectionString = "Data Source=" + server_
                              + ";Initial Catalog=" + database_
                              + ";User ID=" + user_
                              + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
                              + ";connection timeout = 0 ";
        }

        //MSSQL 資料庫連結
        private void Connect_MSSQL()
        {

            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            cnn.Open();
        }

        //讀取目錄檔案名-
        private void readfilename()
        {
            string sourceDirectory = "";
            int r_index = 0;


            if (tabControl1.SelectedTab.Text == "投一海外績效表")
            {
                checkedListBox1.Items.Clear();
                sourceDirectory = txt_foldername1.Text;
            }
            else if (tabControl1.SelectedTab.Text == "累計分層授權預警表")
            {
                checkedListBox3.Items.Clear();
                sourceDirectory = txt_foldername2.Text;
            }
            else if (tabControl1.SelectedTab.Text == "GA-利關人檢核")
            {
                checkedListBox2.Items.Clear();
                sourceDirectory = txt_foldername3.Text;
            }
            else if (tabControl1.SelectedTab.Text == "信用額度")
            {
                checkedListBox4.Items.Clear();
                sourceDirectory = txt_foldername4.Text;
            }
            else if (tabControl1.SelectedTab.Text == "金控報表F18_F19")
            {
                checkedListBox5.Items.Clear();
                sourceDirectory = txt_foldername5.Text;
            }

            if (Directory.Exists(sourceDirectory))
            {
                //var file_ls;
                //                    file_ls = Directory.EnumerateFiles(sourceDirectory, "*.xls").OrderByDescending(f => f); //檔名降冪排序
                //file_ls = Directory.EnumerateFiles(sourceDirectory, "*.xls").OrderBy(p => p.CreationTime); //檔名降冪排序 

                //排序選擇
                DirectoryInfo info = new DirectoryInfo(sourceDirectory);

               
                string filter_files = "*.xls";

                // 排序初始值
                FileInfo[] files = info.GetFiles(filter_files).OrderByDescending(p => p.LastWriteTime).ToArray();

                //取得排序選項
                if (
                    (radioButton11.Checked && tabControl1.SelectedTab.Text == "投一海外績效表" )||
                    (radioButton21.Checked && tabControl1.SelectedTab.Text == "累計分層授權預警表") ||
                    (radioButton31.Checked && tabControl1.SelectedTab.Text == "GA-利關人檢核") ||
                    (radioButton41.Checked && tabControl1.SelectedTab.Text == "信用額度") ||
                    (radioButton51.Checked && tabControl1.SelectedTab.Text == "金控報表F18_F19")
                   )
                    r_index = 0;
                if (
                    (radioButton12.Checked && tabControl1.SelectedTab.Text == "投一海外績效表") ||
                    (radioButton22.Checked && tabControl1.SelectedTab.Text == "累計分層授權預警表") ||
                    (radioButton32.Checked && tabControl1.SelectedTab.Text == "GA-利關人檢核") ||
                    (radioButton42.Checked && tabControl1.SelectedTab.Text == "信用額度") ||
                    (radioButton52.Checked && tabControl1.SelectedTab.Text == "金控報表F18_F19")
                   )
                    r_index = 1;
                if (
                    (radioButton13.Checked && tabControl1.SelectedTab.Text == "投一海外績效表") ||
                    (radioButton23.Checked && tabControl1.SelectedTab.Text == "累計分層授權預警表") ||
                    (radioButton33.Checked && tabControl1.SelectedTab.Text == "GA-利關人檢核") ||
                    (radioButton43.Checked && tabControl1.SelectedTab.Text == "信用額度") ||
                    (radioButton53.Checked && tabControl1.SelectedTab.Text == "金控報表F18_F19")
                   )
                    r_index = 2;
                if (
                    (radioButton14.Checked && tabControl1.SelectedTab.Text == "投一海外績效表") ||
                    (radioButton24.Checked && tabControl1.SelectedTab.Text == "累計分層授權預警表") ||
                    (radioButton34.Checked && tabControl1.SelectedTab.Text == "GA-利關人檢核") ||
                    (radioButton44.Checked && tabControl1.SelectedTab.Text == "信用額度") ||
                    (radioButton54.Checked && tabControl1.SelectedTab.Text == "金控報表F18_F19")
                   )
                    r_index = 3;

                if (r_index == 0) //檔名升幂
                {
                    files = info.GetFiles(filter_files).OrderBy(p => p.Name).ToArray();
                }
                else if (r_index == 1)//檔名降幂
                {
                    files = info.GetFiles(filter_files).OrderByDescending(p => p.Name).ToArray();
                }
                else if (r_index == 2)//最後修改時間升幂
                {
                    files = info.GetFiles(filter_files).OrderBy(p => p.LastWriteTime).ToArray();
                }
                else if (r_index == 3)//最後修改時間降幂
                {
                    files = info.GetFiles(filter_files).OrderByDescending(p => p.LastWriteTime).ToArray();
                }
                                   

                foreach (FileInfo file in files)
                {
                    if (tabControl1.SelectedTab.Text == "投一海外績效表")
                    {
                        checkedListBox1.Items.Add(Path.GetFileName(file.Name));
                        txt_foldername1.Text = Path.GetDirectoryName(file.FullName);
                    }
                    else if (tabControl1.SelectedTab.Text == "累計分層授權預警表")
                    {
                        checkedListBox3.Items.Add(Path.GetFileName(file.Name));
                        txt_foldername2.Text = Path.GetDirectoryName(file.FullName);
                    }
                    else if (tabControl1.SelectedTab.Text == "GA-利關人檢核")
                    {
                        checkedListBox2.Items.Add(Path.GetFileName(file.Name));
                        txt_foldername3.Text = Path.GetDirectoryName(file.FullName);
                    }
                    else if (tabControl1.SelectedTab.Text == "信用額度")
                    {
                        checkedListBox4.Items.Add(Path.GetFileName(file.Name));
                        txt_foldername4.Text = Path.GetDirectoryName(file.FullName);
                    }
                    else if (tabControl1.SelectedTab.Text == "金控報表F18_F19")
                    {
                        checkedListBox5.Items.Add(Path.GetFileName(file.Name));
                        txt_foldername5.Text = Path.GetDirectoryName(file.FullName);
                    }
                }
                //填寫待選檔案
                //foreach (string fi in file_ls)
                //{
                //    if (tabControl1.SelectedTab.Text == "投一海外績效表")
                //    {
                //        checkedListBox1.Items.Add(Path.GetFileName(fi));
                //        txt_foldername1.Text = Path.GetDirectoryName(fi);
                //    }
                //    else if (tabControl1.SelectedTab.Text == "累計分層授權預警表")
                //    {
                //        checkedListBox3.Items.Add(Path.GetFileName(fi));
                //        txt_foldername2.Text = Path.GetDirectoryName(fi);
                //    }
                //    else if (tabControl1.SelectedTab.Text == "GA-利關人檢核")
                //    {
                //        checkedListBox2.Items.Add(Path.GetFileName(fi));
                //        txt_foldername3.Text = Path.GetDirectoryName(fi);
                //    }
                //    else if (tabControl1.SelectedTab.Text == "信用額度")
                //    {
                //        checkedListBox4.Items.Add(Path.GetFileName(fi));
                //        txt_foldername4.Text = Path.GetDirectoryName(fi);
                //    }
                //    else if (tabControl1.SelectedTab.Text == "金控報表F18_F19")
                //    {
                //        checkedListBox5.Items.Add(Path.GetFileName(fi));
                //        txt_foldername5.Text = Path.GetDirectoryName(fi);
                //    }
                //}

                // 預設打勾
                if (tabControl1.SelectedTab.Text == "投一海外績效表")
                {
                    for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
                    {
                        checkedListBox1.SetItemChecked(i, true);
                    }
                }
            }
            else
            {
                MessageBox.Show("路徑:"+ sourceDirectory + "不存在!! 請確認!!");
            }

        }

        //Release 物件
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release to Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        //進度顯示
        void bcp_SqlRowsCopied(object sender, System.Data.SqlClient.SqlRowsCopiedEventArgs e)
        {
            this.Text = e.RowsCopied.ToString();
            this.Update();
        }

        // EXCLE to MSSQL - 直轉無條件table
        public void TransferDataXLS(string excelFile,string Val )
        {
            string strxls, SourceTb, targetTb , vCols_Mapping , vField_Mapping , vFieldstr , vDelstr ;
            DataTable schemaTable;

            try
            {
                vCols_Mapping = "";
                vField_Mapping = "";
                vFieldstr = "*";
                vDelstr = "";
                //1. 讀取Excel資料表
                string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + excelFile
                                 + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";

                OleDbConnection xlsconn = new OleDbConnection(strConn);
                xlsconn.Open();

                DataSet ds = new DataSet();
                //利用GetOleDbSchemaTable取得工作表名稱
                schemaTable = xlsconn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new Object[] { null, null, null, "TABLE" });

                for (int i = 0; i < schemaTable.Rows.Count; i++)
                {
                    SourceTb = schemaTable.Rows[i]["TABLE_NAME"].ToString();
                    SourceTb = SourceTb.Replace("'", "");
                    // 顯示的sheet 才轉檔
                    if (SourceTb.EndsWith("$") == true)
                    {
                        // 取得計劃中轉檔 Sheet
                        GetPrivateProfileString(tabControl1.SelectedTab.Text, SourceTb, "", data, 255, dirstr);
                        targetTb = data.ToString();

                        if (targetTb != "")
                        {
                            //取得預讀取欄位資訊
                            GetPrivateProfileString(targetTb + "-MAP", "FIELDS", "", data, 255, dirstr);
                            vFieldstr = data.ToString();

                            if (vFieldstr == "")
                            {
                                vFieldstr = "*";
                            }

                            strxls = string.Format("SELECT "+ vFieldstr + " FROM [{0}]", SourceTb);

                            OleDbDataAdapter oleda = new OleDbDataAdapter(strxls, xlsconn);
                            ds.Clear();
                            oleda.Fill(ds, SourceTb);

                            dataGridView5.DataSource = ds.Tables[ds.Tables.Count - 1];

                            //2. 清除目標資料表資料~
                            GetPrivateProfileString(targetTb + "-MAP", "FILTER_FIELD", "", data, 255, dirstr);
                            vFieldstr = data.ToString();
                            //讀取來源資料過濾欄位值
                            if (vFieldstr != "")
                            {
                                Val = ds.Tables[0].Rows[0][vFieldstr].ToString();
                            }

                            SqlCommand sqlComm = new SqlCommand();
                            sqlComm.Connection = cnn;
                            sqlComm.CommandText = "DELETE FROM " + targetTb + " WHERE 1=1 ";

                            if (vFieldstr != "")
                            {
                                sqlComm.CommandText = sqlComm.CommandText
                                                     +" AND " + vFieldstr + " = '" + Val + "'";
                            }                            
                            sqlComm.ExecuteNonQuery();

                            //3. 使用 sqlBulkCopy寫入 SQL資料表
                            using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.KeepIdentity))
                            {
                                //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                                bcp.BatchSize = 500; //每次傳輸行數
                                bcp.NotifyAfter = 500; //進度提示的行數

                                // Add column mappings here                               
                                for (int j = 0; j <= ds.Tables[ds.Tables.Count - 1].Columns.Count - 1; j++)
                                {
                                    if (ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName != "")
                                    {
                                        if (GetPrivateProfileString(targetTb + "-MAP", "FIELDS", "", data, 255, dirstr) != 0)
                                        {   //取得mapping 資訊
                                            GetPrivateProfileString(targetTb + "-MAP", ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName, "", data, 255, dirstr);
                                            vField_Mapping = data.ToString();

                                            bcp.ColumnMappings.Add(ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName, vField_Mapping);
                                        }
                                        else //無取得mapping 資訊,表示來源欄位=目的欄位
                                        {
                                            bcp.ColumnMappings.Add(ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName, ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName);
                                        }
                                    }
                                }
                                // finally write to server
                                bcp.DestinationTableName = targetTb; //目標table 
                                //MessageBox.Show(ds.Tables[ds.Tables.Count - 1].Columns.Count.ToString());
                                bcp.WriteToServer(ds.Tables[ds.Tables.Count - 1]); //轉寫入MSSQL 轉入來源與目的欄位數必須相同
                                bcp.Close();
                            }

                            // 刪除指定欄位為null的資料
                            GetPrivateProfileString(targetTb + "-MAP", "CHK_FIELD", "", data, 255, dirstr);
                            vField_Mapping = data.ToString();
                            if (vField_Mapping != "")
                            {
                                vDelstr = "AND " + vField_Mapping + " IS NULL";
                                sqlComm.CommandText = "DELETE FROM " + targetTb + " WHERE 1=1 " + vDelstr;
                                sqlComm.ExecuteNonQuery();
                            }

                            oleda.Dispose();
                            sqlComm.Dispose();
                        }
                    }
                }
                xlsconn.Close();
                xlsconn.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(excelFile + "轉檔失敗!" + "  " +ex.ToString());
            }
        }
 
        // 累積分層授權表
        public void TransferDataXLS2SQL(string excelFile)
        {
            string strxls, SourceTb, targetTb;
            DataTable schemaTable;

            try
            {
                //1. 讀取Excel資料表
                string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + excelFile
                                 + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";

                OleDbConnection xlsconn = new OleDbConnection(strConn);
                xlsconn.Open();

                DataSet ds = new DataSet();
                //利用GetOleDbSchemaTable取得工作表名稱
                schemaTable = xlsconn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new Object[] { null, null, null, "TABLE" });

                for (int i = 0; i < schemaTable.Rows.Count; i++)
                {
                    SourceTb = schemaTable.Rows[i]["TABLE_NAME"].ToString();
                    // 顯示的sheet 才轉檔
                    if (SourceTb.EndsWith("$") == true)
                    {
                        // 取得計劃中轉檔 Sheet
                        GetPrivateProfileString(tabControl1.SelectedTab.Text, SourceTb, "", data, 255, dirstr);
                        targetTb = data.ToString();

                        if (targetTb != "")
                        {
                            strxls = string.Format("SELECT * FROM [{0}]", SourceTb);

                            OleDbDataAdapter oleda = new OleDbDataAdapter(strxls, xlsconn);
                            ds.Clear();
                            oleda.Fill(ds, SourceTb);

                            //2. 檢查是否有當日資料,若有刪之~
                            SqlCommand sqlComm = new SqlCommand();
                            sqlComm.Connection = cnn;
                            sqlComm.CommandText = "DELETE FROM " + targetTb + " WHERE [評價日期] = '" + ds.Tables[ds.Tables.Count - 1].Rows[0][0].ToString() + "'";
                            sqlComm.ExecuteNonQuery();

                            //3. 使用 sqlBulkCopy寫入 SQL資料表
                            using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                            {
                                //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                                bcp.BatchSize = 500; //每次傳輸行數
                                bcp.NotifyAfter = 500; //進度提示的行數

                                // Add column mappings here
                                for (int j = 0; j <= ds.Tables[ds.Tables.Count - 1].Columns.Count -1 ; j++)
                                {
                                    if (ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName != "")
                                    {
                                        bcp.ColumnMappings.Add(ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName, ds.Tables[ds.Tables.Count - 1].Columns[j].ColumnName);
                                    }                                    
                                }
                                // finally write to server
                                bcp.DestinationTableName = targetTb; //目標table 
                                bcp.WriteToServer(ds.Tables[ds.Tables.Count - 1]); //轉寫入MSSQL
                            }

                            //4.清除多餘資料
                            sqlComm.Connection = cnn;
                            sqlComm.CommandText = "DELETE FROM " + targetTb + " WHERE [交易所] is null";
                            sqlComm.ExecuteNonQuery();
                            oleda.Dispose();
                            sqlComm.Dispose();
                        }
                    }
                }
                xlsconn.Close();
                xlsconn.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        // BTSR402 共同基金績效表
        public void TransferDataXLS2SQL2(string excelFile)
        {
            String v_Str,  pfno_ , pnotype_, type_, class_, DestinationTableName;
            DateTime date_;
            int rowIndex, colIndex , idx_pnotype ;
//            SourceTb = Path.GetFileNameWithoutExtension(excelFile);

            try
            {
                DataSet ds = null;
                DataTable dt = null;
                idx_pnotype = 0;

                //1. 讀取Excel文件流
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = null;
                Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
                Microsoft.Office.Interop.Excel.Sheets sheets = null;
                Microsoft.Office.Interop.Excel.Range range = null;

                object missing = System.Reflection.Missing.Value;

                workbook = excel.Workbooks.Open(excelFile, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing);
                
                // 取得所有 sheet 表
                sheets = workbook.Worksheets;

                ds = new DataSet();

                DestinationTableName = "mf_balance";

                for (int i = 1; i <= sheets.Count ; i++)
                {
                    //取得第一個表
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)sheets.get_Item(i);
                    Application.DoEvents();
                    textBox3.AppendText(running_time + "-->" + i.ToString() + "/" + (sheets.Count).ToString() + "." + worksheet.Name + Environment.NewLine);

                    v_Str = "";
                    //MessageBox.Show(worksheet.Name);
                    if (worksheet.Name.Substring(0,4) == "基金明細")
                    {
                        int rowCount = worksheet.UsedRange.Rows.Count;
                        int colCount = worksheet.UsedRange.Columns.Count;

                        //判斷初始列數
                        v_Str = worksheet.Cells[8, 2].Value.ToString();
                        //MessageBox.Show(v_Str.IndexOf("原幣/記帳幣：").ToString());
                        if (v_Str.IndexOf("原幣/記帳幣：") > -1) //投資單位別
                        {
                            rowIndex = 12; //起始行為 12
                            colIndex = 2;  //起始列為 2

                            //判斷是原幣或記帳幣  type_
                            v_Str = worksheet.Cells[8, 2].Value.ToString();
                            type_ = v_Str.Replace("原幣/記帳幣：", "");
                            class_ = "投資單位";
                        }
                        else //部位別
                        {
                            rowIndex = 13; //起始行為 13
                            colIndex = 2;  //起始列為 2                           
                            //判斷是原幣或記帳幣  type_
                            v_Str = worksheet.Cells[9, 2].Value.ToString();
                            type_ = v_Str.Replace("原幣/記帳幣：", "");
                            class_ = "部位";
                        }

                        //取得庫存日期
                        v_Str = worksheet.Cells[4, 2].Value.ToString();
                        v_Str = v_Str.Replace("庫存日期：", "");

                        IFormatProvider culture = new System.Globalization.CultureInfo("zh-TW", true);
                        date_ = DateTime.ParseExact(v_Str, "yyyy/MM/dd", culture);

                        DataColumn dc;
                        dt = new DataTable();
                        dt.TableName = DestinationTableName ;

                        //建立表格欄位
                        dt.Columns.Add("checkout_", typeof(String));
                        dt.Columns.Add("date_", typeof(DateTime));
                        dt.Columns.Add("deskno_", typeof(String));
                        dt.Columns.Add("pfno_", typeof(String));
                        dt.Columns.Add("pfname_", typeof(String));
                        dt.Columns.Add("pnotype_", typeof(String));
                        dt.Columns.Add("secondtp_", typeof(String));
                        dt.Columns.Add("fundno_", typeof(String));
                        dt.Columns.Add("bloombergcode_", typeof(String));
                        dt.Columns.Add("name_", typeof(String));
                        dt.Columns.Add("cur_", typeof(String));
                        dt.Columns.Add("unit_", typeof(Double));
                        dt.Columns.Add("avg_", typeof(Double));
                        dt.Columns.Add("amt_", typeof(Double));
                        dt.Columns.Add("reset_avg_", typeof(Double));
                        dt.Columns.Add("reset_amt_", typeof(Double));
                        dt.Columns.Add("close_", typeof(Double));
                        dt.Columns.Add("mv_", typeof(Double));
                        dt.Columns.Add("cashdiv_", typeof(Double));
                        dt.Columns.Add("yrebate_", typeof(Double));
                        dt.Columns.Add("ysell_amt_", typeof(Double));
                        dt.Columns.Add("ygain_", typeof(Double));
                        dt.Columns.Add("yttl_gian_", typeof(Double));
                        dt.Columns.Add("ungian_px_", typeof(Double));
                        dt.Columns.Add("ungian_fx_", typeof(Double));
                        dt.Columns.Add("ygian_px_", typeof(Double));
                        dt.Columns.Add("ygian_fx_", typeof(Double));
                        dt.Columns.Add("per_return_", typeof(Double));
                        dt.Columns.Add("logdate_", typeof(DateTime));
                        dt.Columns.Add("loguser_", typeof(String));
                        dt.Columns.Add("type_", typeof(String));
                        dt.Columns.Add("class_", typeof(String));

                        //設定String長度
                        dt.Columns["checkout_"].MaxLength = 2;
                        dt.Columns["deskno_"].MaxLength = 255;
                        dt.Columns["pfno_"].MaxLength = 255;
                        dt.Columns["pfname_"].MaxLength = 255;
                        dt.Columns["pnotype_"].MaxLength = 255;
                        dt.Columns["secondtp_"].MaxLength = 255;
                        dt.Columns["fundno_"].MaxLength = 255;
                        dt.Columns["bloombergcode_"].MaxLength = 255;
                        dt.Columns["name_"].MaxLength = 255;
                        dt.Columns["cur_"].MaxLength = 3;
                        dt.Columns["loguser_"].MaxLength = 255;
                        dt.Columns["type_"].MaxLength = 20;
                        dt.Columns["class_"].MaxLength = 20;

                        //設定預設值
                        dt.Columns["checkout_"].DefaultValue = "" ;
                        dt.Columns["deskno_"].DefaultValue = "";
                        dt.Columns["pfno_"].DefaultValue = "";
                        dt.Columns["pfname_"].DefaultValue = "";
                        dt.Columns["pnotype_"].DefaultValue = "";
                        dt.Columns["secondtp_"].DefaultValue = "";
                        dt.Columns["fundno_"].DefaultValue = "";
                        dt.Columns["bloombergcode_"].DefaultValue = "";
                        dt.Columns["name_"].DefaultValue = "";
                        dt.Columns["cur_"].DefaultValue = "";
                        dt.Columns["unit_"].DefaultValue = 0;
                        dt.Columns["avg_"].DefaultValue = 0;
                        dt.Columns["amt_"].DefaultValue = 0;
                        dt.Columns["reset_avg_"].DefaultValue = 0;
                        dt.Columns["reset_amt_"].DefaultValue = 0;
                        dt.Columns["close_"].DefaultValue = 0;
                        dt.Columns["mv_"].DefaultValue = 0;
                        dt.Columns["cashdiv_"].DefaultValue = 0;
                        dt.Columns["yrebate_"].DefaultValue = 0;
                        dt.Columns["ysell_amt_"].DefaultValue = 0;
                        dt.Columns["ygain_"].DefaultValue = 0;
                        dt.Columns["yttl_gian_"].DefaultValue = 0;
                        dt.Columns["ungian_px_"].DefaultValue = 0;
                        dt.Columns["ungian_fx_"].DefaultValue = 0;
                        dt.Columns["ygian_px_"].DefaultValue = 0;
                        dt.Columns["ygian_fx_"].DefaultValue = 0;
                        dt.Columns["per_return_"].DefaultValue = 0;

                        //轉寫EXCEL    
                        //textBox1.AppendText(running_time + "-->" + vDt + "0/" + Environment.NewLine);
                        for (int k = rowIndex; k <= rowCount; k++)
                        {
                            if (worksheet.Cells[k, 2].Value == null)
                            {
                                break;
                            }
                            else if (worksheet.Cells[k, 2].Value != null)
                            {
                                DataRow dr = dt.NewRow();
                                if (class_ == "投資單位") //投資單位
                                {
                                    dr[0] = worksheet.Cells[k, 30].Value.ToString(); // checkout_
                                    dr[1] = date_.ToString("yyyy/MM/dd") ; // date_
                                    dr[2] = worksheet.Cells[k, 3].Value.ToString(); // deskno_
                                    dr[3] = "" ; // pfno_
                                    dr[4] = "" ; // pfname_
                                    // pnotype_
                                    if (type_ == "原幣")
                                    {
                                        idx_pnotype = 32;
                                    }
                                    else
                                    {
                                        idx_pnotype = 31;
                                    }

                                    if (worksheet.Cells[k, idx_pnotype].Value == null)
                                    {
                                        pnotype_ = "";
                                    }
                                    else
                                    {
                                        pnotype_ = worksheet.Cells[k, idx_pnotype].Value.ToString();
                                        if (pnotype_.Substring(0,2) == "02" )
                                        {
                                            dr[5] = "PL-AFS";
                                        }
                                        else if (pnotype_.Substring(0, 2) == "11")
                                        {
                                            dr[5] = "PL-Trading";
                                        }
                                        else if (pnotype_.Substring(0, 2) == "12")
                                        {
                                            dr[5] = "PL-AFS";
                                        }
                                        else
                                        {
                                            pnotype_ = pnotype_.Substring(3, pnotype_.Length-3);
                                            dr[5] = pnotype_;
                                        }
                                        
                                    }
                                    

                                    // secondtp_ 
                                    if (worksheet.Cells[k, 2].Value == null) 
                                    { dr[6] = ""; }
                                    else
                                    { dr[6] = worksheet.Cells[k, 2].Value.ToString(); }

                                    // fundno_ 
                                    if (worksheet.Cells[k, 6].Value == null) 
                                    { dr[7] = ""; }
                                    else
                                    { dr[7] = worksheet.Cells[k, 6].Value.ToString(); }

                                    // bloombergcode_
                                    if (worksheet.Cells[k, 7].Value == null)  
                                    { dr[8] = ""; }
                                    else
                                    { dr[8] = worksheet.Cells[k, 7].Value.ToString(); }
                                    Str_err = k.ToString() + "~~" +worksheet.Cells[k, 7].Value.ToString() ; 

                                    // name_
                                    if (worksheet.Cells[k, 4].Value == null)
                                    { dr[9] = ""; }
                                    else
                                    { dr[9] = worksheet.Cells[k, 4].Value.ToString(); }

                                    // cur_
                                    if (worksheet.Cells[k, 5].Value == null)
                                    { dr[10] = ""; }
                                    else
                                    { dr[10] = worksheet.Cells[k, 5].Value.ToString(); }

                                    // unit_
                                    if (worksheet.Cells[k, 10].Value == null)
                                    { dr[11] = 0 ; }
                                    else
                                    { dr[11] = worksheet.Cells[k, 10].Value.ToString(); }

                                    // avg_
                                    if (worksheet.Cells[k, 14].Value == null)
                                    { dr[12] = 0; }
                                    else
                                    { dr[12] = worksheet.Cells[k, 14].Value.ToString(); }

                                    // amt_
                                    if (worksheet.Cells[k, 13].Value == null)
                                    { dr[13] = 0; }
                                    else
                                    { dr[13] = worksheet.Cells[k, 13].Value.ToString(); }
                                    
                                    // reset_avg_
                                    if (worksheet.Cells[k, 14].Value == null)
                                    { dr[14] = 0; }
                                    else
                                    { dr[14] = worksheet.Cells[k, 14].Value.ToString(); }

                                    // reset_amt_
                                    if (worksheet.Cells[k, 13].Value == null)
                                    { dr[15] = 0; }
                                    else
                                    { dr[15] = worksheet.Cells[k, 13].Value.ToString(); }

                                    // close_
                                    if (worksheet.Cells[k, 15].Value == null)
                                    { dr[16] = 0; }
                                    else
                                    { dr[16] = worksheet.Cells[k, 15].Value.ToString(); }

                                    // mv_
                                    if (worksheet.Cells[k, 16].Value == null)
                                    { dr[17] = 0; }
                                    else
                                    { dr[17] = worksheet.Cells[k, 16].Value.ToString(); }

                                    // cashdiv_
                                    if (worksheet.Cells[k, 22].Value == null)
                                    { dr[18] = 0; }
                                    else
                                    { dr[18] = worksheet.Cells[k, 22].Value.ToString(); }

                                    // yrebate_
                                    if (worksheet.Cells[k, 24].Value == null)
                                    {  dr[19] = 0;   }
                                    else
                                    { dr[19] = worksheet.Cells[k, 24].Value.ToString() ; }

                                    // ysell_amt_
                                    if (worksheet.Cells[k, 25].Value == null)
                                    { dr[20] = 0; }
                                    else
                                    { dr[20] = worksheet.Cells[k, 25].Value.ToString(); }

                                    // ygain_
                                    if (worksheet.Cells[k, 28].Value == null)
                                    { dr[21] = 0; }
                                    else
                                    { dr[21] = worksheet.Cells[k, 28].Value.ToString(); }

                                    // yttl_gian_
                                    if (worksheet.Cells[k, 29].Value == null)
                                    { dr[22] = 0; }
                                    else
                                    { dr[22] = worksheet.Cells[k, 29].Value.ToString(); }

                                    // ungian_px_
                                    if (worksheet.Cells[k, 17].Value == null)
                                    { dr[23] = 0; }
                                    else
                                    { dr[23] = worksheet.Cells[k, 17].Value.ToString(); }

                                    // ungian_fx_
                                    if (worksheet.Cells[k, 18].Value == null)
                                    { dr[24] = 0; }
                                    else
                                    { dr[24] = worksheet.Cells[k, 18].Value.ToString(); }

                                    // ygian_px_
                                    if (worksheet.Cells[k, 26].Value == null)
                                    { dr[25] = 0; }
                                    else
                                    { dr[25] = worksheet.Cells[k, 26].Value.ToString(); }

                                    // ygian_fx_
                                    if (worksheet.Cells[k, 27].Value == null)
                                    { dr[26] = 0; }
                                    else
                                    { dr[26] = worksheet.Cells[k, 27].Value.ToString(); }

                                    // per_return_
                                    dr[27] = 0;

                                }
                                else if (class_ == "部位")//部位
                                {
                                    // checkout_
                                    if (worksheet.Cells[k, 31].Value == null)
                                    { dr[0] = ""; }
                                    else
                                    { dr[0] = worksheet.Cells[k, 31].Value.ToString(); }
                                
                                    dr[1] = date_; // date_
                                    
                                    // deskno_
                                    if (worksheet.Cells[k, 4].Value == null)
                                    { dr[2] = ""; }
                                    else
                                    { dr[2] = worksheet.Cells[k, 4].Value.ToString(); }

                                    // pfno_
                                    if (worksheet.Cells[k, 3].Value == null)
                                    { dr[3] = ""; }
                                    else
                                    { dr[3] = worksheet.Cells[k, 3].Value.ToString(); }
                                 
                                    dr[4] = "" ; // pfname_

                                    // pnotype_
                                    if (type_ == "原幣")
                                    {
                                        idx_pnotype = 33;
                                    }
                                    else
                                    {
                                        idx_pnotype = 32;
                                    }

                                    if (worksheet.Cells[k, idx_pnotype].Value == null)
                                    {
                                        pnotype_ = "";
                                    }
                                    else
                                    {
                                        pnotype_ = worksheet.Cells[k, idx_pnotype].Value.ToString();
                                        if (pnotype_.Substring(0, 2) == "02")
                                        {
                                            dr[5] = "PL-AFS";
                                        }
                                        else if (pnotype_.Substring(0, 2) == "11")
                                        {
                                            dr[5] = "PL-Trading";
                                        }
                                        else if (pnotype_.Substring(0, 2) == "12")
                                        {
                                            dr[5] = "PL-AFS";
                                        }
                                        else
                                        {
                                            pnotype_ = pnotype_.Substring(3, pnotype_.Length - 3);
                                            dr[5] = pnotype_;
                                        }

                                    }

                                    // secondtp_ 
                                    if (worksheet.Cells[k, 2].Value == null)
                                    { dr[6] = ""; }
                                    else
                                    { dr[6] = worksheet.Cells[k, 2].Value.ToString(); }

                                    // fundno_ 
                                    if (worksheet.Cells[k, 7].Value == null)
                                    { dr[7] = ""; }
                                    else
                                    { dr[7] = worksheet.Cells[k, 7].Value.ToString(); }

                                    // bloombergcode_
                                    if (worksheet.Cells[k, 8].Value == null)
                                    { dr[8] = ""; }
                                    else
                                    { dr[8] = worksheet.Cells[k, 8].Value.ToString(); }

                                    // name_
                                    if (worksheet.Cells[k, 5].Value == null)
                                    { dr[9] = ""; }
                                    else
                                    { dr[9] = worksheet.Cells[k, 5].Value.ToString(); }

                                    // cur_
                                    if (worksheet.Cells[k, 6].Value == null)
                                    { dr[10] = ""; }
                                    else
                                    { dr[10] = worksheet.Cells[k, 6].Value.ToString(); }

                                    // unit_
                                    if (worksheet.Cells[k, 11].Value == null)
                                    { dr[11] = 0; }
                                    else
                                    { dr[11] = worksheet.Cells[k, 11].Value.ToString(); }

                                    // avg_
                                    if (worksheet.Cells[k, 15].Value == null)
                                    { dr[12] = 0; }
                                    else
                                    { dr[12] = worksheet.Cells[k, 15].Value.ToString(); }

                                    // amt_
                                    if (worksheet.Cells[k, 14].Value == null)
                                    { dr[13] = 0; }
                                    else
                                    { dr[13] = worksheet.Cells[k, 14].Value.ToString(); }

                                    // reset_avg_
                                    if (worksheet.Cells[k, 15].Value == null)
                                    { dr[14] = 0; }
                                    else
                                    { dr[14] = worksheet.Cells[k, 15].Value.ToString(); }

                                    // reset_amt_
                                    if (worksheet.Cells[k, 14].Value == null)
                                    { dr[15] = 0; }
                                    else
                                    { dr[15] = worksheet.Cells[k, 14].Value.ToString(); }

                                    // close_
                                    if (worksheet.Cells[k, 16].Value == null)
                                    { dr[16] = 0; }
                                    else
                                    { dr[16] = worksheet.Cells[k, 16].Value.ToString(); }

                                    // mv_
                                    if (worksheet.Cells[k, 17].Value == null)
                                    { dr[17] = 0; }
                                    else
                                    { dr[17] = worksheet.Cells[k, 17].Value.ToString(); }

                                    // cashdiv_
                                    if (worksheet.Cells[k, 23].Value == null)
                                    { dr[18] = 0; }
                                    else
                                    { dr[18] = worksheet.Cells[k, 23].Value.ToString(); }

                                    // yrebate_
                                    if (worksheet.Cells[k, 25].Value == null)
                                    { dr[19] = 0; }
                                    else
                                    { dr[19] = worksheet.Cells[k, 25].Value.ToString(); }

                                    // ysell_amt_
                                    if (worksheet.Cells[k, 26].Value == null)
                                    { dr[20] = 0; }
                                    else
                                    { dr[20] = worksheet.Cells[k, 26].Value.ToString(); }

                                    // ygain_
                                    if (worksheet.Cells[k, 29].Value == null)
                                    { dr[21] = 0; }
                                    else
                                    { dr[21] = worksheet.Cells[k, 29].Value.ToString(); }

                                    // yttl_gian_
                                    if (worksheet.Cells[k, 30].Value == null)
                                    { dr[22] = 0; }
                                    else
                                    { dr[22] = worksheet.Cells[k, 30].Value.ToString(); }

                                    // ungian_px_
                                    if (worksheet.Cells[k, 18].Value == null)
                                    { dr[23] = 0; }
                                    else
                                    { dr[23] = worksheet.Cells[k, 18].Value.ToString(); }

                                    // ungian_fx_
                                    if (worksheet.Cells[k, 19].Value == null)
                                    { dr[24] = 0; }
                                    else
                                    { dr[24] = worksheet.Cells[k, 19].Value.ToString(); }

                                    // ygian_px_
                                    if (worksheet.Cells[k, 27].Value == null)
                                    { dr[25] = 0; }
                                    else
                                    { dr[25] = worksheet.Cells[k, 27].Value.ToString(); }

                                    // ygian_fx_
                                    if (worksheet.Cells[k, 28].Value == null)
                                    { dr[26] = 0; }
                                    else
                                    { dr[26] = worksheet.Cells[k, 28].Value.ToString(); }

                                    // per_return_
                                    dr[27] = 0;
                                }
                                dr[28] = DateTime.Now.ToString() ; // logdate_
                                dr[29] = loguser_; // loguser_
                                dr[30] = type_; // type_
                                dr[31] = class_; // class_
                                dt.Rows.Add(dr); 
                                //MessageBox.Show(worksheet.Cells[k, colIndex + 2].Value.ToString());
                                //MessageBox.Show(worksheet.Cells[k, colIndex + 9].Value.ToString());
                                //MessageBox.Show(worksheet.Cells[k, colIndex + 12].Value.ToString());                                                               
                            }
                        }

                        //MessageBox.Show(dt.Rows.Count.ToString());
                        //寫入 MSSQL
                        //2. 檢查是否有當日資料,若有刪之~
                        SqlCommand sqlComm = new SqlCommand();
                        sqlComm.Connection = cnn;
                        sqlComm.CommandText = "DELETE FROM "+ DestinationTableName + " WHERE 1 = 1 AND date_ = '" + date_.ToString("yyyy/MM/dd") + "'  AND type_ = '" + type_ + "' AND class_ = '" + class_ + "' ";
                        sqlComm.ExecuteNonQuery();

                        //3. 使用 sqlBulkCopy寫入 SQL資料表
                        using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                        {
                            //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                            bcp.BatchSize = 100; //每次傳輸行數
                            bcp.NotifyAfter = 100; //進度提示的行數
                            bcp.DestinationTableName = DestinationTableName ; //目標table 
                            bcp.WriteToServer(dt); //轉寫入MSSQL
                        }
                        sqlComm.Dispose();
                    }
                }

                //關閉退出
                workbook.Close();

                excel.Quit();

                //釋放 COM Objects
                Marshal.ReleaseComObject(worksheet);
                Marshal.ReleaseComObject(workbook);
                Marshal.ReleaseComObject(excel);

                worksheet = null;
                workbook = null;
                excel = null;

                GC.Collect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Str_err + " "+ex.ToString());
            }
        }

        // BTSR719 海外股票績效表
        public void TransferDataXLS2SQL3(string excelFile)
        {
            String v_Str, pfno_ , pfname_  , pnotype_ , cur_, type_, class_, datafrom_, DestinationTableName ;
            DateTime date_;
            int rowIndex , colIndex ;
            Double   qty_ , ungain_ , gain_ , cashdiv_ ;
            //            SourceTb = Path.GetFileNameWithoutExtension(excelFile);

            try
            {
                pfno_ = "";
                pfname_ = "";
                pnotype_ = "";

                DataSet ds = null;
                DataTable dt = null;

                //1. 讀取Excel文件流
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = null;
                Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
                Microsoft.Office.Interop.Excel.Sheets sheets = null;
                Microsoft.Office.Interop.Excel.Range range = null;

                object missing = System.Reflection.Missing.Value;

                workbook = excel.Workbooks.Open(excelFile, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing);

                // 取得所有 sheet 表
                sheets = workbook.Worksheets;

                ds = new DataSet();

                //建立主表
                dt = new DataTable();
                dt.TableName = "stk_balance";
                DestinationTableName = "stk_balance";

                //建立表格欄位
                dt.Columns.Add("date_", typeof(DateTime));
                dt.Columns.Add("pfno_", typeof(String));
                dt.Columns.Add("pfname_", typeof(String));
                dt.Columns.Add("pnotype_", typeof(String));
                dt.Columns.Add("secondtp_", typeof(String));
                dt.Columns.Add("stkno_", typeof(String));
                dt.Columns.Add("bloombergcode_", typeof(String));
                dt.Columns.Add("name_", typeof(String));
                dt.Columns.Add("cur_", typeof(String));
                dt.Columns.Add("qty_", typeof(Double));
                dt.Columns.Add("avg_", typeof(Double));
                dt.Columns.Add("amt_", typeof(Double));
                dt.Columns.Add("reset_avg_", typeof(Double));
                dt.Columns.Add("reset_amt_", typeof(Double));
                dt.Columns.Add("close_", typeof(Double));
                dt.Columns.Add("updown_", typeof(Double));
                dt.Columns.Add("mv_", typeof(Double));
                dt.Columns.Add("ungain_", typeof(Double));
                dt.Columns.Add("reset_ungain_", typeof(Double));
                dt.Columns.Add("gain_", typeof(Double));
                dt.Columns.Add("reset_gain_", typeof(Double));
                dt.Columns.Add("cashdiv_", typeof(Double));
                dt.Columns.Add("ttl_gain_", typeof(Double));
                dt.Columns.Add("reset_ttl_gain_", typeof(Double));
                dt.Columns.Add("ungain_px_", typeof(Double));
                dt.Columns.Add("ungain_fx_", typeof(Double));
                dt.Columns.Add("reset_ungain_px_", typeof(Double));
                dt.Columns.Add("reset_ungain_fx_", typeof(Double));
                dt.Columns.Add("gain_px_", typeof(Double));
                dt.Columns.Add("gain_fx_", typeof(Double));
                dt.Columns.Add("reset_gain_px_", typeof(Double));
                dt.Columns.Add("reset_gain_fx_", typeof(Double));
                dt.Columns.Add("logdate_", typeof(DateTime));
                dt.Columns.Add("loguser_", typeof(String));
                dt.Columns.Add("type_", typeof(String));
                dt.Columns.Add("class_", typeof(String));
                dt.Columns.Add("datafrom_", typeof(String));

                //設定String長度
                dt.Columns["pfno_"].MaxLength = 100;
                dt.Columns["pfname_"].MaxLength = 100;
                dt.Columns["pnotype_"].MaxLength = 100;
                dt.Columns["secondtp_"].MaxLength = 100;
                dt.Columns["bloombergcode_"].MaxLength = 10;
                dt.Columns["name_"].MaxLength = 100;
                dt.Columns["cur_"].MaxLength = 3;
                dt.Columns["loguser_"].MaxLength = 100;
                dt.Columns["type_"].MaxLength = 20;
                dt.Columns["class_"].MaxLength = 20;
                dt.Columns["datafrom_"].MaxLength = 20;

                //設定預設值
                dt.Columns["pfno_"].DefaultValue = "";
                dt.Columns["pfname_"].DefaultValue = "";
                dt.Columns["pnotype_"].DefaultValue = "";
                dt.Columns["pfname_"].DefaultValue = "";
                dt.Columns["secondtp_"].DefaultValue = "";
                dt.Columns["stkno_"].DefaultValue = "";
                dt.Columns["bloombergcode_"].DefaultValue = "";
                dt.Columns["cur_"].DefaultValue = "";
                dt.Columns["qty_"].DefaultValue = 0;
                dt.Columns["avg_"].DefaultValue = 0;
                dt.Columns["amt_"].DefaultValue = 0;
                dt.Columns["reset_avg_"].DefaultValue = 0;
                dt.Columns["reset_amt_"].DefaultValue = 0;
                dt.Columns["updown_"].DefaultValue = 0;
                dt.Columns["mv_"].DefaultValue = 0;
                dt.Columns["ungain_"].DefaultValue = 0;
                dt.Columns["reset_ungain_"].DefaultValue = 0;
                dt.Columns["gain_"].DefaultValue = 0;
                dt.Columns["reset_gain_"].DefaultValue = 0;
                dt.Columns["cashdiv_"].DefaultValue = 0;
                dt.Columns["ttl_gain_"].DefaultValue = 0;
                dt.Columns["reset_ttl_gain_"].DefaultValue = 0;
                dt.Columns["ungain_px_"].DefaultValue = 0;
                dt.Columns["ungain_fx_"].DefaultValue = 0;
                dt.Columns["reset_ungain_px_"].DefaultValue = 0;
                dt.Columns["reset_ungain_fx_"].DefaultValue = 0;
                dt.Columns["gain_px_"].DefaultValue = 0;
                dt.Columns["gain_fx_"].DefaultValue = 0;
                dt.Columns["reset_gain_px_"].DefaultValue = 0;
                dt.Columns["reset_gain_fx_"].DefaultValue = 0;

                // 擷取資料-sheet迴圈
                for (int i = 1; i <= sheets.Count; i++)
                {
                    //取得第一個表
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)sheets.get_Item(i);
                    v_Str = "";
                    //MessageBox.Show(worksheet.Name);
                    Application.DoEvents();
                    textBox3.AppendText(running_time + "-->" + i.ToString() + "/" + (sheets.Count).ToString() + "." + worksheet.Name + Environment.NewLine);
                    if (worksheet.Name != "XLR_NoRangeSheet")
                    {
                        int rowCount = worksheet.UsedRange.Rows.Count;
                        int colCount = worksheet.UsedRange.Columns.Count;

                        //判斷初始列數
                        if (worksheet.Cells[7, 3].Value == null)
                        { v_Str = "";  }
                        else
                        { v_Str = worksheet.Cells[7, 3].Value.ToString();  };
                        
                        //MessageBox.Show(v_Str.IndexOf("原幣/記帳幣：").ToString());
                        if (v_Str.IndexOf("金額類別：") == -1) //投資單位別
                        {
                            rowIndex = 10; //起始行為 1
                            colIndex = 2;  //起始列為 2                           
                            //判斷是原幣或記帳幣  type_
                            v_Str = worksheet.Cells[6, 3].Value.ToString();
                            type_ = v_Str.Replace("金額類別：", "");
                            class_ = "投資單位";
                        }
                        else //部位別
                        {
                            rowIndex = 11; //起始行為 12
                            colIndex = 2;  //起始列為 2
                            //判斷是原幣或記帳幣  type_
                            v_Str = worksheet.Cells[7, 3].Value.ToString();
                            type_ = v_Str.Replace("金額類別：", "");
                            class_ = "部位";
                        }
                        datafrom_ = "BTSR719";
                        pfno_ = worksheet.Name.Substring(0, worksheet.Name.Length - 3);
                        cur_ = worksheet.Name.Right(3);

                        //取得庫存日期
                        v_Str = worksheet.Cells[2, 3].Value.ToString();
                        v_Str = v_Str.Replace("日期：", "");

                        IFormatProvider culture = new System.Globalization.CultureInfo("zh-TW", true);
                        date_ = DateTime.ParseExact(v_Str, "yyyy/MM/dd", culture);

                        //轉寫EXCEL    
                        //textBox1.AppendText(running_time + "-->" + vDt + "0/" + Environment.NewLine);
                        for (int k = rowIndex; k <= rowCount; k++)
                        {
                            if (worksheet.Cells[k, 3].Value == "總計")
                            {
                                break;
                            }
                            else if (worksheet.Cells[k, 2].Value == null && worksheet.Cells[k, 3].Value != null )
                            {
                                //
                            }
                            else if (worksheet.Cells[k, 2].Value != null)
                            {
                                // qty_
                                if (worksheet.Cells[k, 7].Value == null)
                                { qty_ = 0; }
                                else
                                { qty_ = worksheet.Cells[k, 7].Value ; }

                                // ungain_
                                if (worksheet.Cells[k, 15].Value == null)
                                { ungain_ = 0; }
                                else
                                { ungain_ = worksheet.Cells[k, 15].Value ; }

                                // gain_
                                if (worksheet.Cells[k, 20].Value == null)
                                { gain_ = 0; }
                                else
                                { gain_ = worksheet.Cells[k, 20].Value ; }

                                // cashdiv_
                                if (worksheet.Cells[k, 19].Value == null)
                                { cashdiv_ = 0; }
                                else
                                { cashdiv_ = worksheet.Cells[k, 19].Value ; }

                                //排除庫存為零且當年度無股利息+已實(含匯差)+未實(含匯差) 之資料
                                if ( (Math.Abs(qty_) + Math.Abs(ungain_) + Math.Abs(gain_) + Math.Abs(cashdiv_) ) != 0 )
                                {
                                    DataRow dr = dt.NewRow();
                                    dr[0] = date_.ToString("yyyy/MM/dd"); // date_
                                    dr[1] = pfno_; //pfno_

                                    // pfname_ 
                                    if (worksheet.Cells[k, 2].Value == null)
                                    { dr[2] = ""; }
                                    else
                                    { dr[2] = worksheet.Cells[k, 2].Value.ToString(); }

                                    // pnotype_ 
                                    if (worksheet.Cells[k, 3].Value == null)
                                    { dr[3] = ""; }
                                    else
                                    { dr[3] = worksheet.Cells[k, 3].Value.ToString(); }

                                    // secondtp_ 
                                    if (worksheet.Cells[k, 4].Value == null)
                                    { dr[4] = ""; }
                                    else
                                    { dr[4] = worksheet.Cells[k, 4].Value.ToString(); }

                                    // stkno_ 
                                    if (worksheet.Cells[k, 5].Value == null)
                                    { dr[5] = ""; }
                                    else
                                    { dr[5] = worksheet.Cells[k, 5].Value.ToString(); }

                                    // bloombergcode_
                                    dr[6] = "";

                                    // name_
                                    if (worksheet.Cells[k, 6].Value == null)
                                    { dr[7] = ""; }
                                    else
                                    { dr[7] = worksheet.Cells[k, 6].Value.ToString(); }

                                    // cur_
                                    dr[8] = cur_;

                                    // qty_
                                    dr[9] = qty_;

                                    // avg_
                                    if (worksheet.Cells[k, 8].Value == null)
                                    { dr[10] = 0; }
                                    else
                                    { dr[10] = worksheet.Cells[k, 8].Value.ToString(); }

                                    // amt_
                                    if (worksheet.Cells[k, 9].Value == null)
                                    { dr[11] = 0; }
                                    else
                                    { dr[11] = worksheet.Cells[k, 9].Value.ToString(); }

                                    // reset_avg_
                                    if (worksheet.Cells[k, 10].Value == null)
                                    { dr[12] = 0; }
                                    else
                                    { dr[12] = worksheet.Cells[k, 10].Value.ToString(); }

                                    // reset_amt_
                                    if (worksheet.Cells[k, 11].Value == null)
                                    { dr[13] = 0; }
                                    else
                                    { dr[13] = worksheet.Cells[k, 11].Value.ToString(); }

                                    // close_
                                    if (worksheet.Cells[k, 12].Value == null)
                                    { dr[14] = 0; }
                                    else
                                    { dr[14] = worksheet.Cells[k, 12].Value.ToString(); }

                                    // updown_
                                    if (worksheet.Cells[k, 13].Value == null)
                                    { dr[15] = 0; }
                                    else
                                    { dr[15] = worksheet.Cells[k, 13].Value.ToString(); }

                                    // mv_
                                    if (worksheet.Cells[k, 14].Value == null)
                                    { dr[16] = 0; }
                                    else
                                    { dr[16] = worksheet.Cells[k, 14].Value.ToString(); }

                                    // ungain_
                                    dr[17] = ungain_;

                                    // reset_ungain_
                                    if (worksheet.Cells[k, 17].Value == null)
                                    { dr[18] = 0; }
                                    else
                                    { dr[18] = worksheet.Cells[k, 17].Value.ToString(); }

                                    // gain_
                                    dr[19] = gain_;

                                    // reset_gain_
                                    if (worksheet.Cells[k, 21].Value == null)
                                    { dr[20] = 0; }
                                    else
                                    { dr[20] = worksheet.Cells[k, 21].Value.ToString(); }

                                    // cashdiv_
                                    dr[21] = cashdiv_;

                                    // ttl_gain_
                                    if (worksheet.Cells[k, 22].Value == null)
                                    { dr[22] = 0; }
                                    else
                                    { dr[22] = worksheet.Cells[k, 22].Value.ToString(); }

                                    // reset_ttl_gain_
                                    if (worksheet.Cells[k, 23].Value == null)
                                    { dr[23] = 0; }
                                    else
                                    { dr[23] = worksheet.Cells[k, 23].Value.ToString(); }

                                    // 以下為擴增for記帳幣使用
                                    // ungain_px_
                                    dr[24] = ungain_;

                                    // ungain_fx_
                                    dr[25] = 0;

                                    // reset_ungain_px_
                                    if (worksheet.Cells[k, 17].Value == null)
                                    { dr[26] = 0; }
                                    else
                                    { dr[26] = worksheet.Cells[k, 17].Value.ToString(); }

                                    // reset_ungain_fx_
                                    dr[27] = 0;

                                    // gain_px_
                                    dr[28] = gain_;

                                    // gain_fx_
                                    dr[29] = 0;

                                    // reset_gain_px_
                                    if (worksheet.Cells[k, 21].Value == null)
                                    { dr[30] = 0; }
                                    else
                                    { dr[30] = worksheet.Cells[k, 21].Value.ToString(); }

                                    // reset_gain_fx_
                                    dr[31] = 0;

                                    //// 遇到記帳幣時重新予值
                                    if (type_ == "記帳幣")
                                    {
                                        // ungain_px_
                                        if (worksheet.Cells[k, 24].Value == null)
                                        { dr[24] = 0; }
                                        else
                                        { dr[24] = worksheet.Cells[k, 24].Value.ToString(); }

                                        // ungain_fx_
                                        if (worksheet.Cells[k, 25].Value == null)
                                        { dr[25] = 0; }
                                        else
                                        { dr[25] = worksheet.Cells[k, 25].Value.ToString(); }

                                        // reset_ungain_px_
                                        if (worksheet.Cells[k, 26].Value == null)
                                        { dr[26] = 0; }
                                        else
                                        { dr[26] = worksheet.Cells[k, 26].Value.ToString(); }

                                        // reset_ungain_fx_
                                        if (worksheet.Cells[k, 27].Value == null)
                                        { dr[27] = 0; }
                                        else
                                        { dr[27] = worksheet.Cells[k, 27].Value.ToString(); }

                                        // gain_px_
                                        if (worksheet.Cells[k, 28].Value == null)
                                        { dr[28] = 0; }
                                        else
                                        { dr[28] = worksheet.Cells[k, 28].Value.ToString(); }

                                        // gain_fx_
                                        if (worksheet.Cells[k, 30].Value == null)
                                        { dr[29] = 0; }
                                        else
                                        { dr[29] = worksheet.Cells[k, 30].Value.ToString(); }

                                        // reset_gain_px_
                                        if (worksheet.Cells[k, 29].Value == null)
                                        { dr[30] = 0; }
                                        else
                                        { dr[30] = worksheet.Cells[k, 29].Value.ToString(); }

                                        // reset_gain_fx_
                                        if (worksheet.Cells[k, 31].Value == null)
                                        { dr[31] = 0; }
                                        else
                                        { dr[31] = worksheet.Cells[k, 31].Value.ToString(); }
                                    }

                                    dr[32] = DateTime.Now.ToString(); //logdate_
                                    dr[33] = loguser_; // loguser_
                                    dr[34] = type_; // type_
                                    dr[35] = class_; // class_
                                    dr[36] = datafrom_; // class_
                                    dt.Rows.Add(dr);
                                }                                                                                                           
                            }
                        }
                        //MessageBox.Show(dt.Rows.Count.ToString());
                        //寫入 MSSQL
                        //2. 檢查是否有當日資料,若有刪之~
                        if (i == 1)
                        {
                            SqlCommand sqlComm = new SqlCommand();
                            sqlComm.Connection = cnn;
                            sqlComm.CommandText = "DELETE FROM " + DestinationTableName + " WHERE 1 = 1 AND date_ = '" + date_.ToString("yyyy/MM/dd") + "'  AND type_ = '" + type_ + "' AND class_ = '" + class_ + "' AND datafrom_ = '" + datafrom_ + "'";
                            sqlComm.ExecuteNonQuery();
                            sqlComm.Dispose();
                        }                   
                    }
                }
                //3. 使用 sqlBulkCopy寫入 SQL資料表
                using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                {
                    //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                    bcp.BatchSize = 100; //每次傳輸行數
                    bcp.NotifyAfter = 100; //進度提示的行數
                    bcp.DestinationTableName = DestinationTableName ; //目標table 
                    bcp.WriteToServer(dt); //轉寫入MSSQL
                }

                //關閉退出
                dt.Dispose();
                workbook.Close();
                excel.Quit();

                //釋放 COM Objects
                Marshal.ReleaseComObject(worksheet);
                Marshal.ReleaseComObject(workbook);
                Marshal.ReleaseComObject(excel);

                worksheet = null;
                workbook = null;
                excel = null;

                GC.Collect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Str_err + " " + ex.ToString());
            }
        }

        // BTSR712 國內股票績效表
        public void TransferDataXLS2SQL5(string excelFile)
        {
            String v_Str, pfno_, pfname_, pnotype_, cur_, type_, class_, datafrom_, DestinationTableName;
            DateTime date_;
            int rowIndex, colIndex;
            Double qty_, ungain_, gain_, cashdiv_;
            //            SourceTb = Path.GetFileNameWithoutExtension(excelFile);

            try
            {
                pfno_ = "";
                pfname_ = "";
                pnotype_ = "";

                DataSet ds = null;
                DataTable dt = null;

                //1. 讀取Excel文件流
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = null;
                Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
                Microsoft.Office.Interop.Excel.Sheets sheets = null;
                Microsoft.Office.Interop.Excel.Range range = null;

                object missing = System.Reflection.Missing.Value;

                workbook = excel.Workbooks.Open(excelFile, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing);

                // 取得所有 sheet 表
                sheets = workbook.Worksheets;

                ds = new DataSet();

                //建立主表
                dt = new DataTable();
                dt.TableName = "stk_balance";
                DestinationTableName = "stk_balance";

                //建立表格欄位
                dt.Columns.Add("date_", typeof(DateTime));
                dt.Columns.Add("pfno_", typeof(String));
                dt.Columns.Add("pfname_", typeof(String));
                dt.Columns.Add("pnotype_", typeof(String));
                dt.Columns.Add("secondtp_", typeof(String));
                dt.Columns.Add("stkno_", typeof(String));
                dt.Columns.Add("bloombergcode_", typeof(String));
                dt.Columns.Add("name_", typeof(String));
                dt.Columns.Add("cur_", typeof(String));
                dt.Columns.Add("qty_", typeof(Double));
                dt.Columns.Add("avg_", typeof(Double));
                dt.Columns.Add("amt_", typeof(Double));
                dt.Columns.Add("reset_avg_", typeof(Double));
                dt.Columns.Add("reset_amt_", typeof(Double));
                dt.Columns.Add("close_", typeof(Double));
                dt.Columns.Add("updown_", typeof(Double));
                dt.Columns.Add("mv_", typeof(Double));
                dt.Columns.Add("ungain_", typeof(Double));
                dt.Columns.Add("reset_ungain_", typeof(Double));
                dt.Columns.Add("gain_", typeof(Double));
                dt.Columns.Add("reset_gain_", typeof(Double));
                dt.Columns.Add("cashdiv_", typeof(Double));
                dt.Columns.Add("ttl_gain_", typeof(Double));
                dt.Columns.Add("reset_ttl_gain_", typeof(Double));
                dt.Columns.Add("ungain_px_", typeof(Double));
                dt.Columns.Add("ungain_fx_", typeof(Double));
                dt.Columns.Add("reset_ungain_px_", typeof(Double));
                dt.Columns.Add("reset_ungain_fx_", typeof(Double));
                dt.Columns.Add("gain_px_", typeof(Double));
                dt.Columns.Add("gain_fx_", typeof(Double));
                dt.Columns.Add("reset_gain_px_", typeof(Double));
                dt.Columns.Add("reset_gain_fx_", typeof(Double));
                dt.Columns.Add("logdate_", typeof(DateTime));
                dt.Columns.Add("loguser_", typeof(String));
                dt.Columns.Add("type_", typeof(String));
                dt.Columns.Add("class_", typeof(String));
                dt.Columns.Add("datafrom_", typeof(String));

                //設定String長度
                dt.Columns["pfno_"].MaxLength = 100;
                dt.Columns["pfname_"].MaxLength = 100;
                dt.Columns["pnotype_"].MaxLength = 100;
                dt.Columns["secondtp_"].MaxLength = 100;
                dt.Columns["bloombergcode_"].MaxLength = 10;
                dt.Columns["name_"].MaxLength = 100;
                dt.Columns["cur_"].MaxLength = 3;
                dt.Columns["loguser_"].MaxLength = 100;
                dt.Columns["type_"].MaxLength = 20;
                dt.Columns["class_"].MaxLength = 20;
                dt.Columns["datafrom_"].MaxLength = 20;

                //設定預設值
                dt.Columns["pfno_"].DefaultValue = "";
                dt.Columns["pfname_"].DefaultValue = "";
                dt.Columns["pnotype_"].DefaultValue = "";
                dt.Columns["pfname_"].DefaultValue = "";
                dt.Columns["secondtp_"].DefaultValue = "";
                dt.Columns["stkno_"].DefaultValue = "";
                dt.Columns["bloombergcode_"].DefaultValue = "";
                dt.Columns["cur_"].DefaultValue = "";
                dt.Columns["qty_"].DefaultValue = 0;
                dt.Columns["avg_"].DefaultValue = 0;
                dt.Columns["amt_"].DefaultValue = 0;
                dt.Columns["reset_avg_"].DefaultValue = 0;
                dt.Columns["reset_amt_"].DefaultValue = 0;
                dt.Columns["updown_"].DefaultValue = 0;
                dt.Columns["mv_"].DefaultValue = 0;
                dt.Columns["ungain_"].DefaultValue = 0;
                dt.Columns["reset_ungain_"].DefaultValue = 0;
                dt.Columns["gain_"].DefaultValue = 0;
                dt.Columns["reset_gain_"].DefaultValue = 0;
                dt.Columns["cashdiv_"].DefaultValue = 0;
                dt.Columns["ttl_gain_"].DefaultValue = 0;
                dt.Columns["reset_ttl_gain_"].DefaultValue = 0;
                dt.Columns["ungain_px_"].DefaultValue = 0;
                dt.Columns["ungain_fx_"].DefaultValue = 0;
                dt.Columns["reset_ungain_px_"].DefaultValue = 0;
                dt.Columns["reset_ungain_fx_"].DefaultValue = 0;
                dt.Columns["gain_px_"].DefaultValue = 0;
                dt.Columns["gain_fx_"].DefaultValue = 0;
                dt.Columns["reset_gain_px_"].DefaultValue = 0;
                dt.Columns["reset_gain_fx_"].DefaultValue = 0;

                // 擷取資料-sheet迴圈
                for (int i = 1; i <= sheets.Count; i++)
                {
                    //取得第一個表
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)sheets.get_Item(i);
                    v_Str = "";
                    //MessageBox.Show(worksheet.Name);
                    Application.DoEvents();
                    textBox3.AppendText(running_time + "-->" + i.ToString() + "/" + (sheets.Count).ToString() + "." + worksheet.Name + Environment.NewLine);
                    if (worksheet.Name != "XLR_NoRangeSheet")
                    {
                        int rowCount = worksheet.UsedRange.Rows.Count;
                        int colCount = worksheet.UsedRange.Columns.Count;

                        //判斷初始列數
                        if (worksheet.Cells[6, 3].Value == null)
                        { v_Str = ""; }
                        else
                        { v_Str = worksheet.Cells[6, 3].Value.ToString(); };

                        //MessageBox.Show(v_Str.IndexOf("原幣/記帳幣：").ToString());
                        if (v_Str.IndexOf("股票部位：") == -1) //投資單位別
                        {
                            rowIndex = 9; //起始行為 1
                            colIndex = 2;  //起始列為 2                           
                            //判斷是原幣或記帳幣  type_
                            //v_Str = worksheet.Cells[6, 3].Value.ToString();
                            type_ = "";
                            class_ = "投資單位";
                        }
                        else //部位別
                        {
                            rowIndex = 10; //起始行為 12
                            colIndex = 2;  //起始列為 2
                            //判斷是原幣或記帳幣  type_
                            //v_Str = worksheet.Cells[7, 3].Value.ToString();
                            type_ = "";
                            class_ = "部位";
                        }
                        datafrom_ = "BTSR712";
                        pfno_ = worksheet.Name.Substring(0, worksheet.Name.Length - 0);
                        cur_ = "TWD";

                        //取得庫存日期
                        v_Str = worksheet.Cells[2, 3].Value.ToString();
                        v_Str = v_Str.Replace("日期：", "");

                        IFormatProvider culture = new System.Globalization.CultureInfo("zh-TW", true);
                        date_ = DateTime.ParseExact(v_Str, "yyyy/MM/dd", culture);

                        //轉寫EXCEL    
                        //textBox1.AppendText(running_time + "-->" + vDt + "0/" + Environment.NewLine);
                        for (int k = rowIndex; k <= rowCount; k++)
                        {
                            if (worksheet.Cells[k, 3].Value == "總計")
                            {
                                break;
                            }
                            else if (worksheet.Cells[k, 2].Value == null && worksheet.Cells[k, 3].Value != null)
                            {
                                //
                            }
                            else if (worksheet.Cells[k, 2].Value != null)
                            {
                                // qty_
                                if (worksheet.Cells[k, 7].Value == null)
                                { qty_ = 0; }
                                else
                                { qty_ = worksheet.Cells[k, 7].Value; }

                                // ungain_
                                if (worksheet.Cells[k, 15].Value == null)
                                { ungain_ = 0; }
                                else
                                { ungain_ = worksheet.Cells[k, 15].Value; }

                                // cashdiv_
                                if (worksheet.Cells[k, 19].Value == null)
                                { cashdiv_ = 0; }
                                else
                                { cashdiv_ = worksheet.Cells[k, 19].Value; }

                                // gain_
                                if (worksheet.Cells[k, 20].Value == null)
                                { gain_ = 0; }
                                else
                                { gain_ = worksheet.Cells[k, 20].Value; }


                                //排除庫存為零且當年度無股利息+已實(含匯差)+未實(含匯差) 之資料
                                if ((Math.Abs(qty_) + Math.Abs(ungain_) + Math.Abs(gain_) + Math.Abs(cashdiv_)) != 0)
                                {
                                    DataRow dr = dt.NewRow();
                                    dr[0] = date_.ToString("yyyy/MM/dd"); // date_

                                    dr[1] = pfno_; //pfno_

                                    // pfname_ 
                                    if (worksheet.Cells[k, 2].Value == null)
                                    { dr[2] = ""; }
                                    else
                                    { dr[2] = worksheet.Cells[k, 2].Value.ToString(); }

                                    // pnotype_ 
                                    if (worksheet.Cells[k, 3].Value == null)
                                    { dr[3] = ""; }
                                    else
                                    { dr[3] = worksheet.Cells[k, 3].Value.ToString(); }

                                    // secondtp_ 
                                    if (worksheet.Cells[k, 4].Value == null)
                                    { dr[4] = ""; }
                                    else
                                    { dr[4] = worksheet.Cells[k, 4].Value.ToString(); }

                                    // stkno_ 
                                    if (worksheet.Cells[k, 5].Value == null)
                                    { dr[5] = ""; }
                                    else
                                    { dr[5] = worksheet.Cells[k, 5].Value.ToString(); }

                                    // bloombergcode_
                                    dr[6] = "";

                                    // name_
                                    if (worksheet.Cells[k, 6].Value == null)
                                    { dr[7] = ""; }
                                    else
                                    { dr[7] = worksheet.Cells[k, 6].Value.ToString(); }

                                    // cur_
                                    dr[8] = cur_ ;

                                    // qty_
                                    dr[9] = qty_;

                                    // avg_
                                    if (worksheet.Cells[k, 8].Value == null)
                                    { dr[10] = 0; }
                                    else
                                    { dr[10] = worksheet.Cells[k, 8].Value.ToString(); }

                                    // amt_
                                    if (worksheet.Cells[k, 9].Value == null)
                                    { dr[11] = 0; }
                                    else
                                    { dr[11] = worksheet.Cells[k, 9].Value.ToString(); }

                                    // reset_avg_
                                    if (worksheet.Cells[k, 10].Value == null)
                                    { dr[12] = 0; }
                                    else
                                    { dr[12] = worksheet.Cells[k, 10].Value.ToString(); }

                                    // reset_amt_
                                    if (worksheet.Cells[k, 11].Value == null)
                                    { dr[13] = 0; }
                                    else
                                    { dr[13] = worksheet.Cells[k, 11].Value.ToString(); }

                                    // close_
                                    if (worksheet.Cells[k, 12].Value == null)
                                    { dr[14] = 0; }
                                    else
                                    { dr[14] = worksheet.Cells[k, 12].Value.ToString(); }

                                    // updown_
                                    if (worksheet.Cells[k, 13].Value == null)
                                    { dr[15] = 0; }
                                    else
                                    { dr[15] = worksheet.Cells[k, 13].Value.ToString(); }

                                    // mv_
                                    if (worksheet.Cells[k, 14].Value == null)
                                    { dr[16] = 0; }
                                    else
                                    { dr[16] = worksheet.Cells[k, 14].Value.ToString(); }

                                    // ungain_
                                    dr[17] = ungain_;

                                    // reset_ungain_
                                    if (worksheet.Cells[k, 17].Value == null)
                                    { dr[18] = 0; }
                                    else
                                    { dr[18] = worksheet.Cells[k, 17].Value.ToString(); }

                                    // gain_
                                    dr[19] = gain_;

                                    // reset_gain_
                                    if (worksheet.Cells[k, 21].Value == null)
                                    { dr[20] = 0; }
                                    else
                                    { dr[20] = worksheet.Cells[k, 21].Value.ToString(); }

                                    // cashdiv_
                                    dr[21] = cashdiv_;

                                    // ttl_gain_
                                    if (worksheet.Cells[k, 22].Value == null)
                                    { dr[22] = 0; }
                                    else
                                    { dr[22] = worksheet.Cells[k, 22].Value.ToString(); }

                                    // reset_ttl_gain_
                                    if (worksheet.Cells[k, 23].Value == null)
                                    { dr[23] = 0; }
                                    else
                                    { dr[23] = worksheet.Cells[k, 23].Value.ToString(); }

                                    // 以下為擴增for記帳幣使用
                                    // ungain_px_
                                    dr[24] = ungain_;

                                    // ungain_fx_
                                    dr[25] = 0;

                                    // reset_ungain_px_
                                    if (worksheet.Cells[k, 17].Value == null)
                                    { dr[26] = 0; }
                                    else
                                    { dr[26] = worksheet.Cells[k, 17].Value.ToString(); }

                                    // reset_ungain_fx_
                                    dr[27] = 0;

                                    // gain_px_
                                    dr[28] = gain_;

                                    // gain_fx_
                                    dr[29] = 0;

                                    // reset_gain_px_
                                    if (worksheet.Cells[k, 21].Value == null)
                                    { dr[30] = 0; }
                                    else
                                    { dr[30] = worksheet.Cells[k, 21].Value.ToString(); }

                                    // reset_gain_fx_
                                    dr[31] = 0;

                                    dr[32] = DateTime.Now.ToString(); //logdate_
                                    dr[33] = loguser_; // loguser_
                                    dr[34] = type_; // type_
                                    dr[35] = class_; // class_
                                    dr[36] = datafrom_; // class_
                                    dt.Rows.Add(dr);
                                }
                            }
                        }
                        //MessageBox.Show(dt.Rows.Count.ToString());
                        //寫入 MSSQL
                        //2. 檢查是否有當日資料,若有刪之~
                        if (i == 1)
                        {
                            SqlCommand sqlComm = new SqlCommand();
                            sqlComm.Connection = cnn;
                            sqlComm.CommandText = "DELETE FROM " + DestinationTableName + " WHERE 1 = 1 AND date_ = '" + date_.ToString("yyyy/MM/dd") + "'  AND type_ = '" + type_ + "' AND class_ = '" + class_ + "' AND datafrom_ = '" + datafrom_ + "'";
                            sqlComm.ExecuteNonQuery();
                            sqlComm.Dispose();
                        }
                    }
                }
                //3. 使用 sqlBulkCopy寫入 SQL資料表
                using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                {
                    //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                    bcp.BatchSize = 100; //每次傳輸行數
                    bcp.NotifyAfter = 100; //進度提示的行數
                    bcp.DestinationTableName = DestinationTableName; //目標table 
                    bcp.WriteToServer(dt); //轉寫入MSSQL
                }

                //關閉退出
                dt.Dispose();
                workbook.Close();
                excel.Quit();

                //釋放 COM Objects
                Marshal.ReleaseComObject(worksheet);
                Marshal.ReleaseComObject(workbook);
                Marshal.ReleaseComObject(excel);

                worksheet = null;
                workbook = null;
                excel = null;

                GC.Collect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Str_err + " " + ex.ToString());
            }
        }

        // 利關人負面表列導入
        public void TransferDataXLS2SQL4(string excelFile)
        {
            String v_Str, pfno_, type_, class_, DestinationTableName;
            DateTime date_;
            int rowIndex, colIndex;
            //            SourceTb = Path.GetFileNameWithoutExtension(excelFile);

            try
            {
                DataSet ds = null;
                DataTable dt = null;

                //1. 讀取Excel文件流
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = null;
                Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
                Microsoft.Office.Interop.Excel.Sheets sheets = null;
                Microsoft.Office.Interop.Excel.Range range = null;

                object missing = System.Reflection.Missing.Value;

                workbook = excel.Workbooks.Open(excelFile, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing);

                // 取得所有 sheet 表
                sheets = workbook.Worksheets;

                ds = new DataSet();

                DestinationTableName = "sh_Stakeholder_fh";

                for (int i = 1; i <= sheets.Count ; i++)
                {
                    //取得第一個表
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)sheets.get_Item(i);
                    Application.DoEvents();
                    textBox2.AppendText(running_time + "-->" + i.ToString() + "/" + (sheets.Count).ToString() + "." + worksheet.Name + Environment.NewLine);
                    v_Str = "";
                    //MessageBox.Show(worksheet.Name);
                        int rowCount = worksheet.UsedRange.Rows.Count;
                        int colCount = worksheet.UsedRange.Columns.Count;

                        //判斷初始列數
                        rowIndex = 5; //起始行為 5
                        colIndex = 1;  //起始列為 1

                        //取得庫存日期
                        v_Str = worksheet.Cells[3, 1].Value.ToString();
                        v_Str = v_Str.Replace("資料日期：", "");

                        //IFormatProvider culture = new System.Globalization.CultureInfo("zh-TW", true);
                        //date_ = DateTime.ParseExact(v_Str, "yyyy/MM/dd", culture);

                        DataColumn dc;
                        dt = new DataTable();
                        dt.TableName = DestinationTableName;

                        //建立表格欄位
                        dt.Columns.Add("關係人/事業名稱", typeof(String));
                        dt.Columns.Add("關係人/事業ID", typeof(String));
                        dt.Columns.Add("類別", typeof(String));
                        dt.Columns.Add("股票代號", typeof(String));
                        dt.Columns.Add("公司簡稱", typeof(String));

                        //設定String長度
                        dt.Columns["關係人/事業名稱"].MaxLength = 100;
                        dt.Columns["關係人/事業ID"].MaxLength = 50;
                        dt.Columns["類別"].MaxLength = 50;
                        dt.Columns["股票代號"].MaxLength = 100;
                        dt.Columns["公司簡稱"].MaxLength = 200;

                        //設定預設值
                        dt.Columns["關係人/事業名稱"].DefaultValue = "";
                        dt.Columns["關係人/事業ID"].DefaultValue = "";
                        dt.Columns["類別"].DefaultValue = "";
                        dt.Columns["股票代號"].DefaultValue = "";
                        dt.Columns["公司簡稱"].DefaultValue = "";

                        //轉寫EXCEL    
                        //textBox1.AppendText(running_time + "-->" + vDt + "0/" + Environment.NewLine);
                        for (int k = rowIndex; k <= rowCount; k++)
                        {
                            if (worksheet.Cells[k, 1].Value == null)
                            {
                                break;
                            }
                            else if (worksheet.Cells[k, 1].Value != null)
                            {
                                DataRow dr = dt.NewRow();
                                if (worksheet.Cells[k, 1].Value == null)
                                { dr[0] = ""; }
                                else
                                { dr[0] = worksheet.Cells[k, 1].Value.ToString(); // 關係人/事業名稱
                                }
                                if (worksheet.Cells[k, 2].Value == null)
                                { dr[1] = ""; }
                                else
                                {
                                    dr[1] = worksheet.Cells[k, 2].Value.ToString(); // 關係人/事業ID
                                }
                                if (worksheet.Cells[k, 3].Value == null)
                                { dr[2] = ""; }
                                else
                                {
                                    dr[2] = worksheet.Cells[k, 3].Value.ToString(); // 類別
                                }
                                if (worksheet.Cells[k, 4].Value == null)
                                { dr[3] = ""; }
                                else
                                {
                                    dr[3] = worksheet.Cells[k, 4].Value.ToString(); // 股票代號
                                }
                                if (worksheet.Cells[k, 5].Value == null)
                                { dr[4] = ""; }
                                else
                                {
                                    dr[4] = worksheet.Cells[k, 5].Value.ToString(); // 公司簡稱
                                }
                                dt.Rows.Add(dr);
                                //MessageBox.Show(worksheet.Cells[k, colIndex + 2].Value.ToString());
                                //MessageBox.Show(worksheet.Cells[k, colIndex + 9].Value.ToString());
                                //MessageBox.Show(worksheet.Cells[k, colIndex + 12].Value.ToString());                                                               
                            }
                        }
                        //寫入 MSSQL
                        //2. 檢查是否有當日資料,若有刪之~
                        SqlCommand sqlComm = new SqlCommand();
                        sqlComm.Connection = cnn;
                        sqlComm.CommandText = "DELETE FROM " + DestinationTableName + " WHERE 1 = 1  ";
                        sqlComm.ExecuteNonQuery();

                        //3. 使用 sqlBulkCopy寫入 SQL資料表
                        using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                        {
                            //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                            bcp.BatchSize = 100; //每次傳輸行數
                            bcp.NotifyAfter = 100; //進度提示的行數
                            bcp.DestinationTableName = DestinationTableName; //目標table 
                            bcp.WriteToServer(dt); //轉寫入MSSQL
                        }
                        sqlComm.Dispose();
                }

                //關閉退出
                workbook.Close();

                excel.Quit();

                //釋放 COM Objects
                Marshal.ReleaseComObject(worksheet);
                Marshal.ReleaseComObject(workbook);
                Marshal.ReleaseComObject(excel);

                worksheet = null;
                workbook = null;
                excel = null;

                GC.Collect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Str_err + " " + ex.ToString());
            }
        }

        // F_BalTrans
        public F_BalTrans()
        {
            InitializeComponent();

            // Start timer
            timer1.Enabled = true;
            
            //設定sql 連結資訊
            setSQL_info();

            //清除text 資訊
            textBox1.Clear();
            textBox3.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox7.Clear();
            textBox6.Clear();

            //指定預設路徑
            String vPath = "" ;
            GetPrivateProfileString("PATH-DEFAULT", "TAB1", "", data, 255, dirstr);
            vPath = data.ToString();
            txt_foldername1.Text = vPath;

            GetPrivateProfileString("PATH-DEFAULT", "TAB2", "", data, 255, dirstr);
            vPath = data.ToString();
            txt_foldername2.Text = vPath;

            GetPrivateProfileString("PATH-DEFAULT", "TAB3", "", data, 255, dirstr);
            vPath = data.ToString();
            txt_foldername3.Text = vPath;

            GetPrivateProfileString("PATH-DEFAULT", "TAB4", "", data, 255, dirstr);
            vPath = data.ToString();
            txt_foldername4.Text = vPath;

            GetPrivateProfileString("PATH-DEFAULT", "TAB5", "", data, 255, dirstr);
            vPath = data.ToString();
            txt_foldername5.Text = vPath;
        }

        // 呼叫目錄對話及填入選定後路徑
        private void button4_Click(object sender, EventArgs e)
        {
            string Currentpath = "";
            
            if (tabControl1.SelectedTab.Name == "tabPage2") //累積分層表
            {
                 Currentpath = txt_foldername2.Text;
            }
            else if (tabControl1.SelectedTab.Name == "tabPage1") //海外績效表
            {
                Currentpath = txt_foldername1.Text;
            }
            else if (tabControl1.SelectedTab.Name == "tabPage3") //利關人比對表
            {
                Currentpath = txt_foldername3.Text;
            }
            else if (tabControl1.SelectedTab.Name == "tabPage4") //信用額度
            {
                Currentpath = txt_foldername4.Text;
            }
            else if (tabControl1.SelectedTab.Name == "tabPage5") //金控報表F18_F19
            {
                Currentpath = txt_foldername5.Text;
            }

            folderBrowserDialog1.SelectedPath = txt_foldername5.Text;

            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                Currentpath = folderBrowserDialog1.SelectedPath.ToString();

                // 預設打勾
                if (tabControl1.SelectedTab.Name == "tabPage2") //累積分層表
                {
                    txt_foldername2.Text = Currentpath;
                }
                else if (tabControl1.SelectedTab.Name == "tabPage1") //海外績效表
                {
                    txt_foldername1.Text = Currentpath;
                }
                else if (tabControl1.SelectedTab.Name == "tabPage3") //利關人比對表
                {
                    txt_foldername3.Text = Currentpath;
                }
                else if (tabControl1.SelectedTab.Name == "tabPage4") //信用額度
                {
                    txt_foldername4.Text = Currentpath;
                }
                else if (tabControl1.SelectedTab.Name == "tabPage5") //金控報表F18_F19
                {
                    txt_foldername5.Text = Currentpath;
                }
            }
            readfilename();
        }

        //分層累積授權表製作
        private void button2_Click_1(object sender, EventArgs e)
        {
            int i;


            string vGoing, excelFile, strxls, SourceTb, targetTb, vDt , vUrl;
            SourceTb = "";
            targetTb = "";

            vDt = maskedTextBox3.Text;
            textBox1.AppendText(running_time + "-->開始" + vDt + "分層累積授權表製作" + Environment.NewLine);
            try
            {

                //1 連結MSSQL
                Connect_MSSQL();

                vGoing = "N";
                for (i = 0; i <= checkedListBox3.Items.Count - 1; i++)
                {
                    if (checkedListBox3.GetItemChecked(i))
                    {
                        vGoing = "Y";
                        break;
                    }
                    else
                    { vGoing = "N"; }
                }

                //開始進行檔案判斷及轉檔
                if (vGoing == "Y")
                {
                    this.Cursor = Cursors.WaitCursor;
                    //1. 轉檔
                    for (i = 0; i <= checkedListBox3.Items.Count - 1; i++)
                    {
                        if (checkedListBox3.GetItemChecked(i))
                        {
                            excelFile = txt_foldername2.Text + '\\' + checkedListBox3.Items[i].ToString();
                            textBox1.AppendText(running_time + ">處理資料轉檔" + Environment.NewLine);
                            TransferDataXLS2SQL(excelFile);
                        }
                    }
                    //2. 執行查詢 SP 
                    Application.DoEvents();
                    textBox1.AppendText(running_time + ">執行分層累積授權表運算" + Environment.NewLine);
                    sql = "spINVESTAMT1";

                    cmd = new SqlCommand(sql, cnn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000;
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("dt", vDt));
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        ////3. 呼叫 EXCEL
                        //Application.DoEvents();
                        //textBox1.AppendText(running_time + ">啟動EXCEL" + Environment.NewLine);
                        ////應用程序
                        //Excel.Application Excel_AP = new Excel.Application();
                        //Excel_AP.DisplayAlerts = false;

                        ////開檔案
                        //Application.DoEvents();
                        //textBox1.AppendText(running_time + ">開啟EXCEL工作表" + Environment.NewLine);
                        //Excel.Workbook Excel_WB = Excel_AP.Workbooks.Open("\\\\filesvr2\\投資一處投資四部公用區\\INVESTAMT\\累計分層授權預警表.xlsm");
                        ////指定工作表
                        //Excel.Worksheet Excel_WS1 = new Excel.Worksheet();
                        //Excel_WS1 = Excel_WB.Worksheets["Main"];
                        //Excel_WS1.Activate();


                        ////寫入日期資訊
                        //Excel_AP.Cells[3, 3] = vvDt.Year.ToString("0000") + "/" + vvDt.Month.ToString("00") + "/" + vvDt.Day.ToString("00");

                        ////4. 將資料寫入對應 EXCEL 欄位
                        ////指定工作表
                        //Application.DoEvents();
                        //textBox1.AppendText(running_time + ">填寫EXCEL工作表" + Environment.NewLine);
                        //Excel.Worksheet Excel_WS2 = new Excel.Worksheet();
                        //Excel_WS2 = Excel_WB.Worksheets["累計分層授權預警表"];
                        //Excel_WS2.Activate();

                        //// Range 變數
                        //Excel.Range WS_RG = null;

                        //i = 14;
                        //while (reader.Read())
                        //{
                        //    //MessageBox.Show(reader[8].ToString() + " " + reader[3].ToString());
                        //    Excel_AP.Cells[i, 2] = reader[0].ToString(); //市場別
                        //    Excel_AP.Cells[i, 3] = reader[1].ToString(); //投資類別
                        //    Excel_AP.Cells[i, 4] = reader[2].ToString(); //投資代碼
                        //    Excel_AP.Cells[i, 5] = reader[3].ToString(); //商品名稱
                        //    Excel_AP.Cells[i, 6] = reader[4].ToString(); //累積金額
                        //    Excel_AP.Cells[i, 7] = reader[5].ToString(); //核決層級
                        //    Excel_AP.Cells[i, 8] = reader[6].ToString(); //備註

                        //    if (reader[8].ToString() != "增加")
                        //    {
                        //        WS_RG = Excel_WS2.get_Range("B" + i.ToString(), "H" + i.ToString());
                        //        WS_RG.Font.Color = 0xC0C0C0; // 變成淡淡灰
                        //    }
                        //    else
                        //    {
                        //        WS_RG = Excel_WS2.get_Range("B" + i.ToString(), "G" + i.ToString());
                        //        WS_RG.Font.Color = 0x000000; // 變成black
                        //        WS_RG = Excel_WS2.get_Range("H" + i.ToString(), "H" + i.ToString());
                        //        WS_RG.Font.Color = 0x0000FF; // 變成red
                        //    }

                        //    i++;
                        //}
                        //Excel_AP.Visible = true;

                        //// 釋放Excel資源
                        //WS_RG = null;
                        //Excel_WB.Save();
                        //Excel_WS1 = null;
                        //Excel_WS2 = null;
                        //Excel_WB = null;
                        //System.Runtime.InteropServices.Marshal.ReleaseComObject(Excel_AP);
                        //Excel_AP = null;

                        Application.DoEvents();
                        textBox1.AppendText(running_time + ">資料寫入完成,請開啟Smart eVision" + Environment.NewLine);
                        GetPrivateProfileString("SQ-link", "url", "", data, 255, dirstr);
                        vUrl = data.ToString();
                        System.Diagnostics.Process.Start(vUrl);
                    }
                    else
                    {
                        MessageBox.Show("預警表計算後,無回饋資料,請查明!");
                    }
                    reader.Close();
                    cmd.Dispose();
                    cnn.Close();
                    textBox1.AppendText(running_time + ">完成" + vDt + "分層累積授權表製作" + Environment.NewLine + Environment.NewLine);
                    this.Cursor = Cursors.Default;
                }
                else
                {
                    this.Cursor = Cursors.Default;
                    MessageBox.Show("請確認預備轉檔的檔案!!");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(ex.ToString());
            }
        }

        //Calll setSQL_info();
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            setSQL_info();
        }

        //股票基金庫存轉檔
        private void button3_Click(object sender, EventArgs e)
        {
            int i;

            string vGoing, excelFile, vDt;

            try
            {
                vGoing = "N";
                for (i = 0; i <= checkedListBox1.Items.Count - 1; i++)
                {
                    if (checkedListBox1.GetItemChecked(i))
                    {
                        vGoing = "Y";
                        break;
                    }
                    else
                    { vGoing = "N"; }
                }

                //開始進行檔案判斷及轉檔
                if (vGoing == "Y")
                {
                    this.Cursor = Cursors.WaitCursor;

                    vDt = maskedTextBox4.Text ;
                    textBox3.AppendText(running_time + "-->開始 " + vDt + " 股票基金庫存轉檔" + Environment.NewLine);

                    //1 連結MSSQL
                    textBox3.AppendText(running_time + ">資料庫存聯結..." + Environment.NewLine);
                    Connect_MSSQL();

                    //1. 轉檔
                    for (i = 0; i <= checkedListBox1.Items.Count - 1; i++)
                    {
                        if (checkedListBox1.GetItemChecked(i))
                        {
                            Application.DoEvents();
                            excelFile = txt_foldername1.Text + '\\' + checkedListBox1.Items[i].ToString();
                            textBox3.AppendText(running_time + ">處理資料" + checkedListBox1.Items[i].ToString() + Environment.NewLine);
                            if (excelFile.IndexOf("BTSR402") > -1)
                            {
                                TransferDataXLS2SQL2(excelFile);
                            }
                            else if (excelFile.IndexOf("BTSR719") > -1)
                            {
                                TransferDataXLS2SQL3(excelFile);
                            }
                            else if (excelFile.IndexOf("BTSR712") > -1)
                            {
                                TransferDataXLS2SQL5(excelFile);
                            }
                        }
                    }
                    Application.DoEvents();
                    textBox3.AppendText(running_time + ">處理資料轉檔完成" + Environment.NewLine);
                    this.Cursor = Cursors.Default;
                }
                else
                {
                    this.Cursor = Cursors.Default;
                    MessageBox.Show("請確認預備轉檔的檔案!!");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(ex.ToString());
            }
        }

        //績效表計算開始約1
        private void button5_Click(object sender, EventArgs e)
        {
            string vDt;

            try
            {
                vvDt = dateTimePicker2.Value;
                vDt = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
                textBox3.AppendText(running_time + " " + vDt + "-- >績效表計算開始約1~2分鐘!" + Environment.NewLine);

                Connect_MSSQL();
                int i = 1;
                if (cnn != null && cnn.State == ConnectionState.Open)
                {
                    // 執行轉檔
                    this.Cursor = Cursors.WaitCursor;
                    for (i = 1; i <= 4; i++)
                    {
                        textBox3.AppendText(running_time + " " + vDt + "-- >計算第" + i.ToString() + "/4 段資料" + Environment.NewLine);
                        switch (i)
                        {
                            case 1:
                                sql = "EXEC pr_man_performance_rpt0_I9 @dt ,'0' ";
                                break;
                            case 2:
                                sql = "EXEC pr_man_performance_rpt0_I9 @dt ,'1' ";
                                break;
                            case 3:
                                sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'1','0' ";
                                break;
                            case 4:
                                sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'0','0' ";
                                break;
                                //case 4:
                                //    sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'1','2' ";
                                //    break;
                                //case 5:
                                //    sql = "EXEC pr_man_performance_rpt3_I9 @dt ,'1','3' ";
                                //    break;
                                //case 6:
                                //    sql = "EXEC pr_man_performance_rpt4_I9 @dt ,'0' ";
                                //    break;
                        }
                        cmd = new SqlCommand(sql, cnn);
                        cmd.CommandTimeout = 10000;
                        cmd.Parameters.Add(new SqlParameter("dt", vDt));
                        cmd.ExecuteNonQuery();
                        Application.DoEvents();
                        cmd.Dispose();
                        //MessageBox.Show(sql);
                    }
                    cnn.Close();
                    this.Cursor = Cursors.Default;
                    textBox3.AppendText(running_time + " " + vDt + "-- >績效表計算完成!" + Environment.NewLine);
                }
                else
                {
                    MessageBox.Show("資料庫連結失敗,請查明原因!!");
                }
            }
            catch (Exception ex)
            {
                cnn.Close();
                this.Cursor = Cursors.Default;
                MessageBox.Show(ex.ToString());
            }
        }

        //績效表計算-連續執行三個任務
        private void button6_Click(object sender, EventArgs e)
        {
            //連續執行三個任務
            button3.PerformClick(); //1.轉檔
            button5.PerformClick(); //2.計算彙總
            button7.PerformClick(); //3.開啟 EXCEL 
        }

        // Timer1-Display Clock
        private void timer1_Tick(object sender, EventArgs e)
        {
            Application.DoEvents();
            running_time = DateTime.Now.ToString("HH:mm:ss") + "--";
        }

        //開檔案 EXCEL
        private void button7_Click(object sender, EventArgs e)
        {
            //開檔案
            Application.DoEvents();
            textBox3.AppendText(running_time + ">開啟EXCEL工作表" + Environment.NewLine);
            Process.Start("\\\\filesvr2\\invest\\GI_invest\\GA Fund\\GA基金下單相關檔案\\GA管理績效表\\日績效表\\基金股票ETF產製工具_IFRS9.xls");            
        }

        //利關人庫存轉檔
        private void button8_Click(object sender, EventArgs e)
        {
            int i;

            string vGoing, excelFile, vDt , vUrl;

            if (maskedTextBox1.Text != "")
            {
                vDt = maskedTextBox1.Text;
                textBox2.AppendText(running_time + "-->開始 年月:" + vDt + " 利關人庫存轉檔" + Environment.NewLine);
                try
                {
                    //1 連結MSSQL
                    textBox2.AppendText(running_time + ">資料庫存聯結..." + Environment.NewLine);
                    Connect_MSSQL();

                    vGoing = "N";
                    for (i = 0; i <= checkedListBox2.Items.Count - 1; i++)
                    {
                        if (checkedListBox2.GetItemChecked(i))
                        {
                            vGoing = "Y";
                            break;
                        }
                        else
                        { vGoing = "N"; }
                    }

                    //開始進行檔案判斷及轉檔
                    if (vGoing == "Y")
                    {
                        this.Cursor = Cursors.WaitCursor;
                        //1. 轉檔
                        for (i = 0; i <= checkedListBox2.Items.Count - 1; i++)
                        {
                            if (checkedListBox2.GetItemChecked(i))
                            {
                                Application.DoEvents();
                                excelFile = txt_foldername3.Text + '\\' + checkedListBox2.Items[i].ToString();
                                textBox3.AppendText(running_time + ">處理資料" + checkedListBox2.Items[i].ToString() + Environment.NewLine);
                                if (excelFile.IndexOf("負面") > -1)
                                {
                                    TransferDataXLS2SQL4(excelFile);
                                }
                                else //if (excelFile.IndexOf("BTSM002") > -1)
                                {
                                    TransferDataXLS(excelFile, vDt);
                                }

                            }
                        }

                        //2. exec SP
                        Application.DoEvents();
                        textBox2.AppendText(running_time + ">重組資料配對利關人資料" + Environment.NewLine);
                        sql = "EXEC sp_Stakeholder_check @yyyymm , @loguser";
                        cmd = new SqlCommand(sql, cnn);
                        cmd.CommandTimeout = 10000;
                        cmd.Parameters.Add(new SqlParameter("yyyymm", maskedTextBox1.Text));
                        cmd.Parameters.Add(new SqlParameter("loguser", loguser_));
                        cmd.ExecuteNonQuery();

                        //3.處理完成
                        Application.DoEvents();
                        textBox2.AppendText(running_time + ">處理資料轉檔完成" + Environment.NewLine);

                        Application.DoEvents();
                        textBox2.AppendText(running_time + ">資料寫入完成,請開啟Smart eVision" + Environment.NewLine);

                        GetPrivateProfileString("SQ-link", "url", "", data, 255, dirstr);
                        vUrl = data.ToString();
                        System.Diagnostics.Process.Start(vUrl);

                        this.Cursor = Cursors.Default;
                    }
                    else
                    {
                        this.Cursor = Cursors.Default;
                        MessageBox.Show("請確認預備轉檔的檔案!!");
                    }
                }
                catch (Exception ex)
                {
                    this.Cursor = Cursors.Default;
                    MessageBox.Show(ex.ToString());
                }
            }
            else
            {
                MessageBox.Show("請輸入查詢年月");
            }
        }

        //績效表計算-刪除舊資料
        private void button10_Click(object sender, EventArgs e)
        {
            string vDt;

            vvDt = dateTimePicker2.Value;
            vDt = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");

            try
            {
                DialogResult Result = MessageBox.Show("是否刪除["+ vDt + "]的"+ comboBox1 .Text + "轉檔資料", "刪除庫存", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (Result == DialogResult.Yes)
                {
                    textBox3.AppendText(running_time + " " + vDt + "-- >刪除["+ vDt + "]"+ comboBox1.Text + "庫存!" + Environment.NewLine);

                    Connect_MSSQL();
                    int i = 1;
                    if (cnn != null && cnn.State == ConnectionState.Open)
                    {
                        // 執行轉檔
                        this.Cursor = Cursors.WaitCursor;
                        if (comboBox1.SelectedIndex == 0)
                        {
                            sql = "DELETE FROM stk_balance WHERE DATE_ = @dt ";
                            cmd = new SqlCommand(sql, cnn);
                            cmd.CommandTimeout = 10000;
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(new SqlParameter("dt", vDt));
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                        }
                        else if (comboBox1.SelectedIndex == 1)
                        {
                            sql = "DELETE FROM mf_balance WHERE DATE_ = @dt ";
                            cmd = new SqlCommand(sql, cnn);
                            cmd.CommandTimeout = 10000;
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(new SqlParameter("dt", vDt));
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                        }
                        else if (comboBox1.SelectedIndex == 2)
                        {
                            cmd = new SqlCommand();
                            cmd.Connection = cnn;
                            cmd.CommandTimeout = 10000;
                            cmd.Parameters.Clear();
                            cmd.CommandText = "DELETE FROM stk_balance WHERE DATE_ = @dt ";
                            cmd.Parameters.Add(new SqlParameter("dt", vDt));
                            cmd.ExecuteNonQuery();

                            cmd.Parameters.Clear();
                            cmd.CommandText = "DELETE FROM mf_balance WHERE DATE_ = @dt ";
                            cmd.Parameters.Add(new SqlParameter("dt", vDt));
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                        }
                        cnn.Close();
                        this.Cursor = Cursors.Default;
                        textBox3.AppendText(running_time + " " + vDt + "-- >資料刪除完成!" + Environment.NewLine);

                    }
                    else
                    {
                        MessageBox.Show("資料庫連結失敗,請查明原因!!");
                    }
                }
            }
            catch (Exception ex)
            {
                cnn.Close();
                this.Cursor = Cursors.Default;
                MessageBox.Show(ex.ToString());
            }
        }

        // 讀取 BBG 資料
        public void run_get_bbg()
        {
            //string serverHost = "localhost";
            string serverHost = "10.174.190.75";
            int serverPort = 8194;

            SessionOptions sessionOptions = new SessionOptions();
            sessionOptions.ServerHost = serverHost;
            sessionOptions.ServerPort = serverPort;

            textBox4.AppendText("Connecting to " + serverHost + ":" + serverPort + System.Environment.NewLine);
            Session session = new Session(sessionOptions);
            bool sessionStarted = session.Start();
            if (!sessionStarted)
            {
                //System.Console.WriteLine("Failed to start session.");
                textBox4.AppendText("Failed to start session." + System.Environment.NewLine);
                return;
            }
            if (!session.OpenService("//blp/refdata"))
            {
                //System.Console.Error.WriteLine("Failed to open //blp/refdata");
                textBox4.AppendText("Failed to open //blp/refdata");
                return;
            }
            Service refDataService = session.GetService("//blp/refdata");

            Request request = refDataService.CreateRequest("ReferenceDataRequest");
            Element securities = request.GetElement("securities");

            // Bloomberg Ticker List 
            List<string> TickerLists = new List<string>();

            // Bloomberg Ticker List 
            List<string> FiledLists = new List<string>();

            TickerLists.Add("IBM US Equity");
            for (int i = 0; i <= TickerLists.Count - 1; i++)
            {
                securities.AppendValue(TickerLists[i]);
            }

            //securities.AppendValue("/cusip/912810RE0@BGN");
            // this CUSIP identifies US Treasury Bill 
            // 'T 3 5/8 02/15/44 Govt'

            Element fields = request.GetElement("fields");
            FiledLists.Add("PX_LAST");
            for (int j = 0; j <= FiledLists.Count - 1; j++)
            {
                fields.AppendValue(FiledLists[j]);
            }
            //fields.AppendValue("DS002");

            //System.Console.WriteLine("Sending Request: " + request);
            textBox4.AppendText("Sending Request: " + request + System.Environment.NewLine);
            session.SendRequest(request, null);

            //StreamWriter wr = new StreamWriter(@"d:\test.txt", false, System.Text.Encoding.UTF8);

            while (true)
            {
                Event eventObj = session.NextEvent();
                foreach (Message msg in eventObj)
                {
                    //System.Console.WriteLine(msg.AsElement);
                    //wr.Write(msg.AsElement);
                    textBox4.AppendText(msg.AsElement.ToString());
                }

                if (eventObj.Type == Event.EventType.RESPONSE)
                {
                    break;
                }
            }
            //wr.Dispose();
            //wr.Close();
        }

        // 讀取 BBG 資料-顯示處理
        private void button11_Click(object sender, EventArgs e)
        {
            //1. 清除訊息框
            textBox4.Clear();
            //2. 讀取Bloomberg 資料
            run_get_bbg();
            //3. 解析 bloomberg 返回文本資料
        }

        // 讀取 BBG 資料-分析文本
        private void button12_Click(object sender, EventArgs e)
        {
            string vflag ,vstr;

            vflag = "N";
            vstr = "";
            for (int k = 0; k <= textBox4.Lines.Length-1 ; k++ )
            {
                vstr = textBox4.Lines[k].Trim().Replace(@"""","");
                if (vstr.IndexOf("security =") != -1)
                {
                    //MessageBox.Show(vstr);
                    textBox5.AppendText(vstr + Environment.NewLine );
                }
                else if (vstr.IndexOf("fieldData =") != -1 && vflag == "N")
                {
                    vflag = "Y";
                }
                else if (vflag == "Y")
                {
                    if (vstr.IndexOf("}") != -1)
                    {
                        vflag = "N";
                    }
                    else //讀取資料內容
                    {
                        //MessageBox.Show(vstr );
                        textBox5.AppendText(vstr + Environment.NewLine);
                    }
                }
            }
        }

        //信用額度MAPPING轉檔
        private void button14_Click(object sender, EventArgs e)
        {
            int i;


            string vGoing, excelFile, vDt;
            

            if (maskedTextBox2.Text != "")
            {
                vDt = maskedTextBox2.Text;
                textBox7.AppendText(running_time + "-->開始 年月日:" + vDt + " 信用額度MAPPING轉檔" + Environment.NewLine);
                try
                {
                    //1 連結MSSQL
                    textBox7.AppendText(running_time + ">資料庫存聯結..." + Environment.NewLine);
                    Connect_MSSQL();

                    vGoing = "N";
                    for (i = 0; i <= checkedListBox4.Items.Count - 1; i++)
                    {
                        if (checkedListBox4.GetItemChecked(i))
                        {
                            vGoing = "Y";
                            break;
                        }
                        else
                        { vGoing = "N"; }
                    }

                    //開始進行檔案判斷及轉檔
                    if (vGoing == "Y")
                    {
                        this.Cursor = Cursors.WaitCursor;
                        //1. 轉檔
                        for (i = 0; i <= checkedListBox4.Items.Count - 1; i++)
                        {
                            if (checkedListBox4.GetItemChecked(i))
                            {
                                Application.DoEvents();
                                excelFile = txt_foldername4.Text + '\\' + checkedListBox4.Items[i].ToString();
                                textBox7.AppendText(running_time + ">處理檔案: " + checkedListBox4.Items[i].ToString() + Environment.NewLine);
                                TransferDataXLS(excelFile, vDt);
                            }
                        }
                        Application.DoEvents();
                        textBox7.AppendText(running_time + ">資料匯入..." + Environment.NewLine);
                        //2. exec SP
                        DataSet ds = new DataSet();
                        Application.DoEvents();
                        textBox7.AppendText(running_time + ">處理信用額度資料組合" + Environment.NewLine);
                        sql = "EXEC spCPCredit @dt ";
                        cmd = new SqlCommand(sql, cnn);
                        cmd.CommandTimeout = 10000;
                        cmd.Parameters.Add(new SqlParameter("dt", maskedTextBox2.Text));
                        //cmd.ExecuteReader();
                        SqlDataAdapter dt = new SqlDataAdapter();
                        dt.SelectCommand = cmd;
                        dt.Fill(ds);

                        //3. 顯示資料到Datagridview , 共 4 個 dataset
                        dataGridView1.DataSource = ds.Tables[0] ; // 1.國外集團-資料檢查
                        dataGridView2.DataSource = ds.Tables[1] ; // 2.國內集團-資料檢查                        
                        dataGridView3.DataSource = ds.Tables[2] ; // 3.地方政府-資料檢查
                        dataGridView4.DataSource = ds.Tables[3] ; // MAPPING資料

                        //4.處理完成
                        Application.DoEvents();
                        textBox7.AppendText(running_time + ">處理資料轉檔完成...OK!" + Environment.NewLine);
                        ds.Dispose();

                        this.Cursor = Cursors.Default;
                    }
                    else
                    {
                        this.Cursor = Cursors.Default;
                        MessageBox.Show("請確認預備轉檔的檔案!!");
                    }
                }
                catch (Exception ex)
                {
                    this.Cursor = Cursors.Default;
                    MessageBox.Show(ex.ToString());
                }
            }
            else
            {
                MessageBox.Show("請輸入查詢年月日");
            }
        }

        //信用額度MAPPING轉檔-產製csv檔案
        private void button15_Click(object sender, EventArgs e)
        {
            //產生 csv 檔案
            string csvfile = "";
            string csvstr = "";

            if (dataGridView4.RowCount != 0)
            {
                textBox7.AppendText(running_time + ">產製完成檔案,路徑:" + csvfile + Environment.NewLine);
                csvfile = txt_foldername4.Text + "\\BTSM013_" + maskedTextBox2.Text + ".csv";
                FileStream fs = new FileStream(csvfile, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);
                //開始寫入csv
                //sw.Write("交易商代碼,交易商名稱,生效日期,佔總資產百分比,佔可運用資金百分比,佔扣外幣準備金之資金百分比,佔自結可運用資金百分比,債券主順位佔可運用資金百分比,債券次順位佔可運用資金百分比" + Environment.NewLine);
                //sw.Write("TRAN_BRK,TRAN_NAME,VALID_DATE,TOT_ASSETS_PER,INV_AMT_PER,RESERVE_AMT_PER,INV_AMT_SELF_PER,CREDIT_LINE_MAIN_PER,CREDIT_LINE_SUB_PER" + Environment.NewLine);
                sw.Write("交易商代碼,交易商名稱,生效日期,佔可運用資金百分比,佔扣外幣準備金之資金百分比,佔自結可運用資金百分比,債券主順位佔可運用資金百分比,債券次順位佔可運用資金百分比" + Environment.NewLine);
                sw.Write("TRAN_BRK,TRAN_NAME,VALID_DATE,INV_AMT_PER,RESERVE_AMT_PER,INV_AMT_SELF_PER,CREDIT_LINE_MAIN_PER,CREDIT_LINE_SUB_PER" + Environment.NewLine);
                for (int i = 0; i <= dataGridView4.RowCount-1; i++)
                {
                    if (dataGridView4.Rows[i].Cells[0].Value != null)
                    {
                        for (int j = 0; j <= dataGridView4.ColumnCount-1; j++)
                        {
                            if (csvstr == "")
                            {
                                csvstr = dataGridView4.Rows[i].Cells[j].Value.ToString() + ",";
                            }
                            else
                            {
                                csvstr = csvstr + dataGridView4.Rows[i].Cells[j].Value.ToString() + ",";
                            }
                        }
                        sw.Write(csvstr.Substring(0,csvstr.Length - 1) + Environment.NewLine);
                        csvstr = "";
                    }
                }
                //清空緩衝區
                sw.Flush();
                //關閉資料流
                sw.Close();
                fs.Close();
                MessageBox.Show(">產製完成檔案,路徑:" + Environment.NewLine + csvfile);
            }
            else
            {
                MessageBox.Show("無資料產出!!");
            }
        }

        //指定各tabpage 預設檔案路徑
        private void button17_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                string Currentpath = folderBrowserDialog1.SelectedPath.ToString();
                if (tabControl1.SelectedTab.Text == "投一海外績效表")
                {
                    txt_foldername1.Text = Currentpath;
                }
                else if (tabControl1.SelectedTab.Text == "累計分層授權預警表")
                {
                    txt_foldername2.Text = Currentpath;
                }
                else if (tabControl1.SelectedTab.Text == "GA-利關人檢核")
                {
                    txt_foldername3.Text = Currentpath;
                }
                else if (tabControl1.SelectedTab.Text == "信用額度")
                {
                    txt_foldername4.Text = Currentpath;
                }
            }
            readfilename();
        }

        //讀取路徑下的檔案到 checkbox
        private void txt_foldername5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                readfilename();
            }
        }

        //checklistbox 是否全選or全不選
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            // 全選與全不選
            if (tabControl1.SelectedTab.Text == "投一海外績效表")
            {
                for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
                {
                    checkedListBox1.SetItemChecked(i, ((CheckBox)sender).Checked);
                }
            }
            else if (tabControl1.SelectedTab.Text == "累計分層授權預警表")
            {
                for (int i = 0; i <= checkedListBox3.Items.Count - 1; i++)
                {
                    checkedListBox3.SetItemChecked(i, ((CheckBox)sender).Checked);
                }
            }
            else if (tabControl1.SelectedTab.Text == "GA-利關人檢核")
            {
                for (int i = 0; i <= checkedListBox2.Items.Count - 1; i++)
                {
                    checkedListBox2.SetItemChecked(i, ((CheckBox)sender).Checked);
                }
            }
            else if (tabControl1.SelectedTab.Text == "信用額度")
            {
                for (int i = 0; i <= checkedListBox4.Items.Count - 1; i++)
                {
                    checkedListBox4.SetItemChecked(i, ((CheckBox)sender).Checked);
                }
            }
            else if (tabControl1.SelectedTab.Text == "金控報表F18_F19")
            {
                for (int i = 0; i <= checkedListBox5.Items.Count - 1; i++)
                {
                    checkedListBox5.SetItemChecked(i, ((CheckBox)sender).Checked);
                }
            }

        }

        //資料日期格式化及預設值
        private void dateTimePicker1_CloseUp(object sender, EventArgs e)
        {
            DateTime vvDt;            
            vvDt = ((DateTimePicker)sender).Value;

            if (tabControl1.SelectedTab.Text == "投一海外績效表")
            {
                maskedTextBox4.Text = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
            }
            else if (tabControl1.SelectedTab.Text == "累計分層授權預警表")
            {
                maskedTextBox3.Text = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
            }
            else if (tabControl1.SelectedTab.Text == "信用額度")
            {
                maskedTextBox2.Text = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
            }
            else if (tabControl1.SelectedTab.Text == "金控報表F18_F19")
            {
                maskedTextBox5.Text = vvDt.Year.ToString("0000") + vvDt.Month.ToString("00") + vvDt.Day.ToString("00");
            }

        }

        //F_BalTrans_Shown
        private void F_BalTrans_Shown(object sender, EventArgs e)
        {
            //設定初始值
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = dateTimePicker1.Value;
            dateTimePicker3.Value = dateTimePicker1.Value;
            dateTimePicker4.Value = dateTimePicker1.Value;

            maskedTextBox1.Text = DateTime.Now.Year.ToString("0000") + DateTime.Now.Month.ToString("00");

            maskedTextBox2.Text = DateTime.Now.Year.ToString("0000") + DateTime.Now.Month.ToString("00") + DateTime.Now.Day.ToString("00");
            maskedTextBox3.Text = maskedTextBox2.Text;
            maskedTextBox4.Text = maskedTextBox2.Text;
            maskedTextBox5.Text = maskedTextBox2.Text;

            comboBox1.SelectedIndex = 0;
        }

        //金控報表F18_F19轉檔
        private void button16_Click(object sender, EventArgs e)
        {
            int i;

            string vGoing, excelFile, vDt;

            if (maskedTextBox5.Text != "")
            {
                vDt = maskedTextBox5.Text;
                textBox6.AppendText(running_time + "-->開始 年月日:" + vDt + " 金控報表F18_F19轉檔" + Environment.NewLine);
                try
                {
                    //1 連結MSSQL
                    textBox6.AppendText(running_time + ">資料庫存聯結..." + Environment.NewLine);
                    Connect_MSSQL();

                    vGoing = "N";
                    for (i = 0; i <= checkedListBox5.Items.Count - 1; i++)
                    {
                        if (checkedListBox5.GetItemChecked(i))
                        {
                            vGoing = "Y";
                            break;
                        }
                        else
                        { vGoing = "N"; }
                    }

                    //開始進行檔案判斷及轉檔
                    if (vGoing == "Y")
                    {
                        this.Cursor = Cursors.WaitCursor;
                        //1. 轉檔
                        for (i = 0; i <= checkedListBox5.Items.Count - 1; i++)
                        {
                            if (checkedListBox5.GetItemChecked(i))
                            {
                                Application.DoEvents();
                                excelFile = txt_foldername5.Text + '\\' + checkedListBox5.Items[i].ToString();
                                textBox6.AppendText(running_time + ">處理檔案: " + checkedListBox5.Items[i].ToString() + Environment.NewLine);
                                TransferDataXLS(excelFile, vDt);
                            }
                        }
                        Application.DoEvents();
                        textBox6.AppendText(running_time + ">資料匯入..." + Environment.NewLine);

                        //4.處理完成
                        Application.DoEvents();
                        textBox6.AppendText(running_time + ">處理資料轉檔完成...OK!" + Environment.NewLine);
                        //ds.Dispose();

                        this.Cursor = Cursors.Default;
                    }
                    else
                    {
                        this.Cursor = Cursors.Default;
                        MessageBox.Show("請確認預備轉檔的檔案!!");
                    }
                }
                catch (Exception ex)
                {
                    this.Cursor = Cursors.Default;
                    MessageBox.Show(ex.ToString());                    
                }
            }
            else
            {
                MessageBox.Show("請輸入查詢年月日");
            }
        }

        //排序選擇改變時,重讀檔案至checklistbox
        private void radioButton1_Click(object sender, EventArgs e)
        {
            readfilename() ;
        }

        //Read csv file to datatable, 
        public static DataTable OpenCSV(string filePath, bool b_IsFirst , int DataRows)
        {
            //Encoding encoding = Common.GetType(filePath); //Encoding.ASCII;//
            int CRows ;

            DataTable dt = new DataTable();
            using (FileStream fs = new FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read))
            {
                using (StreamReader sr = new StreamReader(fs, Encoding.Default))
                {
                    //StreamReader sr = new StreamReader(fs, encoding);
                    //string fileContent = sr.ReadToEnd();
                    //encoding = sr.CurrentEncoding;
                    //記錄每次讀取的一行記錄
                    string strLine = "";
                    //記錄每行記錄中的各字段內容
                    string[] aryLine = null;
                    string[] tableHead = null;

                    //標示列數
                    int columnCount = 0;

                    //標示是否是讀取的第一行
                    bool IsFirst = b_IsFirst;

                    //逐行讀取CSV中的數據
                    CRows = 0 ;
                    while ((strLine = sr.ReadLine()) != null)
                    {
                        CRows = CRows + 1;
                        //strLine = Common.ConvertStringUTF8(strLine, encoding);
                        //strLine = Common.ConvertStringUTF8(strLine);

                        if (IsFirst == true)
                        {
                            tableHead = strLine.Split(',');
                            IsFirst = false;
                            columnCount = tableHead.Length;
                            //創建列
                            for (int i = 0; i < columnCount; i++)
                            {
                                DataColumn dc = new DataColumn(tableHead[i]);
                                dt.Columns.Add(dc);
                            }
                        }
                        else
                        {
                            // 讀取行大於等於設定資料起始行讀取資料
                            if (CRows >= DataRows)
                            {
                                aryLine = strLine.Split(',');
                                DataRow dr = dt.NewRow();
                                for (int j = 0; j < columnCount; j++)
                                {
                                    dr[j] = aryLine[j];
                                }
                                dt.Rows.Add(dr);
                            }
                        }
                    }
                    if (aryLine != null && aryLine.Length > 0)
                    {
                        dt.DefaultView.Sort = tableHead[0] + " " + "asc";
                    }

                    sr.Close();
                    fs.Close();
                }
            }
            return dt;
        }

        //  由CSV寫入MSSQL - 只能有一行表頭
        public void TransferData_CSV_To_SQL(string PathFile)
        {
            string SourceTb, targetTb, vField_Mapping, vFieldstr, vDelstr , Val, val2 ;

            DataTable s_Datatb = new DataTable();

            //取得檔名
            SourceTb = Path.GetFileNameWithoutExtension(PathFile) ;

            Val = "";

            // 取得對應目檔資料表名
            GetPrivateProfileString(tabControl1.SelectedTab.Text, SourceTb, "", data, 255, dirstr);
            targetTb = data.ToString();

            if (targetTb != "")
            {
                // 讀取資料後寫入Datatable
                GetPrivateProfileString(SourceTb, "IsFirst", "", data, 255, dirstr);
                Val = data.ToString();

                GetPrivateProfileString(SourceTb, "DataRows", "", data, 255, dirstr);
                val2 = data.ToString();

                s_Datatb = OpenCSV(PathFile,Convert.ToBoolean(Val) , Convert.ToInt32(val2) );

                //2. 清除目標資料表資料~
                GetPrivateProfileString(targetTb + "-MAP", "FILTER_FIELD", "", data, 255, dirstr);
                vFieldstr = data.ToString();

                //讀取來源資料過濾欄位值
                if (vFieldstr != "")
                {
                    Val = s_Datatb.Rows[0][vFieldstr].ToString();
                }

                SqlCommand sqlComm = new SqlCommand();
                sqlComm.Connection = cnn;
                sqlComm.CommandText = "DELETE FROM " + targetTb + " WHERE 1=1 ";

                if (vFieldstr != "")
                {
                    sqlComm.CommandText = sqlComm.CommandText
                                         + " AND " + vFieldstr + " = '" + Val + "'";
                }
                sqlComm.ExecuteNonQuery();

                //3. 使用 sqlBulkCopy寫入 SQL資料表
                using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.KeepIdentity))
                {
                    //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                    bcp.BatchSize = 500; //每次傳輸行數
                    bcp.NotifyAfter = 500; //進度提示的行數

                    // Add column mappings here                               
                    for (int j = 0; j <= s_Datatb.Columns.Count - 1; j++)
                    {
                        if (s_Datatb.Columns[j].ColumnName != "")
                        {
                            if (GetPrivateProfileString(targetTb + "-MAP", "FIELDS", "", data, 255, dirstr) != 0)
                            {   //取得mapping 資訊
                                GetPrivateProfileString(targetTb + "-MAP", s_Datatb.Columns[j].ColumnName, "", data, 255, dirstr);
                                vField_Mapping = data.ToString();

                                bcp.ColumnMappings.Add(s_Datatb.Columns[j].ColumnName, vField_Mapping);
                            }
                            else //無取得mapping 資訊,表示來源欄位=目的欄位
                            {
                                bcp.ColumnMappings.Add(s_Datatb.Columns[j].ColumnName, s_Datatb.Columns[j].ColumnName);
                            }
                        }
                    }
                    // finally write to server
                    bcp.DestinationTableName = targetTb; //目標table 
                                                         //MessageBox.Show(ds.Tables[ds.Tables.Count - 1].Columns.Count.ToString());
                    bcp.WriteToServer(s_Datatb); //轉寫入MSSQL 轉入來源與目的欄位數必須相同
                    bcp.Close();
                }

                // 刪除指定欄位為null的資料
                GetPrivateProfileString(targetTb + "-MAP", "CHK_FIELD", "", data, 255, dirstr);
                vField_Mapping = data.ToString();
                if (vField_Mapping != "")
                {
                    vDelstr = "AND " + vField_Mapping + " IS NULL";
                    sqlComm.CommandText = "DELETE FROM " + targetTb + " WHERE 1=1 " + vDelstr;
                    sqlComm.ExecuteNonQuery();
                }

                sqlComm.Dispose();
            }
        }

        //讀取 CSV
        private void button18_Click(object sender, EventArgs e)
        {
            Connect_MSSQL();
            TransferData_CSV_To_SQL(textBox8.Text);
            cnn.Close();
        }
    }
}

//login information
//
//[PositionDB]
//server_=P-2523-600G1\SQLEXPRESS
//database_=PositionDB
//user_=ppview
//password_=Ir2Os7aFV7ABdLNs1i9Pww==
//[InvestDB]
//server_=P-2523-600G1\SQLEXPRESS
//database_=InvestDB
//user_=invuser
//password_=VoY7um5JnYqH7GoSCZZAAA==
//[OR_CTLGA]
//database_=CTLGA
//user_=niiuser
//password_=zbmTkmT8GbXLj822qTkimA==
//[OR_METUAT]
//database_=METUAT
//user_=sw
//password_=il/vWRUBS0s=
//[OR_CTLUAT]
//database_=CTLUAT
//user_=sw
//password_=il/vWRUBS0s=
