﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;

namespace IvLogBook
{
    public partial class WF_Logbook : Form
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        //string dirstr = System.IO.Directory.GetCurrentDirectory();
        string dirstr = Application.StartupPath;

        //Connect Access DB 2007 Encrypt password
        string connectionString = null;
        string sql = null;
        OleDbDataAdapter datadapter;
        DataTable myDataTable;
        DataView myDataView;
        String DataStatus ; //A:add ; E:edit ; D:Del
        DataRowView drv;

        public WF_Logbook()
        {
            InitializeComponent();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release to Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void MainForm1_Load(object sender, EventArgs e)
        {
            
            comboBox1.SelectedIndex = 0;
            //timer1.Enabled = true;

            dateTimePicker2.Value = System.DateTime.Now.AddDays(60); //計算45天後
            dateTimePicker1.Value = System.DateTime.Now.AddDays(-90); //計算90天前
            stlUSER.Text = "登錄人員: "+ Environment.UserName ;
            txt_query.Text = Environment.UserName ;

            cb_type.Items.Clear();
            cb_type.Items.Add("研討會");
            cb_type.Items.Add("教育訓練");
            cb_type.Items.Add("會議");
            cb_type.Items.Add("其他");

            cb_typeQry.Items.Clear();
            cb_typeQry.Items.Add("");
            cb_typeQry.Items.Add("研討會");
            cb_typeQry.Items.Add("教育訓練");
            cb_typeQry.Items.Add("會議");
            cb_typeQry.Items.Add("其他");

            // 資料庫連結,建立DataTable
            DataLoad();
            
            // GridView 抬頭說明及控制
            dataGridView1.ReadOnly = true;
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[0].HeaderText = "序號";
            dataGridView1.Columns[1].HeaderText = "登記姓名";
            dataGridView1.Columns[2].HeaderText = "預計外出日期";
            dataGridView1.Columns[3].HeaderText = "預計外出時間";
            dataGridView1.Columns[4].HeaderText = "預計返回時間";

            dataGridView1.Columns[5].HeaderText = "不返回公司";
            dataGridView1.Columns[6].HeaderText = "外出類型";
            dataGridView1.Columns[7].HeaderText = "外出說明";
            dataGridView1.Columns[8].HeaderText = "同行人數(含本人)";

            //dataGridView1.Columns[10].HeaderText = "建立人員";
            //dataGridView1.Columns[11].HeaderText = "建立時間";
            dataGridView1.Columns[9].HeaderText = "更新人員";
            dataGridView1.Columns[10].HeaderText = "更新時間";
            //dataGridView1.Columns[14].HeaderText = "FLAG";

            dataGridView1.Columns[9].Visible = false;
            dataGridView1.Columns[10].Visible = false;
            dataGridView1.AutoGenerateColumns = false;

            //資料繫結
            DataBind();

            //調整控制元件 Enable
            Edit_Status(true);
        }

        //讀取資料庫資料--查詢
        private void DataLoad()
        {
            connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + dirstr + "\\Logbookdb.accdb;Persist Security Info=True;Jet OLEDB:Database Password=logbook";
            sql = "select keyno_ as 序號,登記人,外出日期,外出時間,返回時間,不返回公司,外出類型,外出說明,隨行人數,loguser_ as 更新人員,logdate_ as 更新時間 from logItem  ";
            sql = sql + "WHERE flag_ <> 'D' ";
            sql = sql + "order by  [登記人] ,[外出日期] DESC , [外出時間] DESC ";

            //資料庫連結,建立DataTable
            using (OleDbConnection cnn = new OleDbConnection(connectionString))
            {
                cnn.Open();
                using (OleDbCommand cmd = new OleDbCommand(sql, cnn))
                {
                    using ( OleDbDataReader DataReader = cmd.ExecuteReader())
                    {
                        using (DataTable dt = new DataTable())
                        {
                            dt.Load(DataReader);
                            dt.DefaultView.RowFilter = " ( [外出日期] >= '" + dateTimePicker1.Text + "' AND [外出日期] <= '" + dateTimePicker2.Text + "') ";
                            if (txt_query.Text.Trim() != "")
                            {
                                dt.DefaultView.RowFilter = dt.DefaultView.RowFilter
                                                         + "and [" + comboBox1.Text.Trim() + "] LIKE '%" + txt_query.Text.Trim() + "%'";
                            }
                            if (cb_typeQry.Text.Trim() != "")
                            {
                                dt.DefaultView.RowFilter = dt.DefaultView.RowFilter
                                                         + "and [外出類型] = '" + cb_typeQry.Text.Trim() + "'";
                            }
                            myDataTable = dt;
                        }
                    }
                }
            }
            myDataView = new DataView(myDataTable);
            myDataView.AllowEdit = true;
            myDataView.AllowNew = true;
            myDataView.AllowDelete = true;

            bindingSource1.DataSource = myDataTable;

            bindingNavigator1.BindingSource = bindingSource1;

            dataGridView1.DataSource = bindingSource1;
        }

        //編輯元件資料繫結
        private void DataBind()
        {
            txt_keyno_.DataBindings.Clear();
            txt_USERID.DataBindings.Clear();
            txt_bookdate.DataBindings.Clear();
            txt_booktimeg.DataBindings.Clear();
            txt_booktimeb.DataBindings.Clear();
            ck_booktimeb.DataBindings.Clear();
            cb_type.DataBindings.Clear();
            txt_num.DataBindings.Clear();
            txt_Desc.DataBindings.Clear();

            txt_keyno_.DataBindings.Add("Text", bindingSource1, "序號");
            txt_USERID.DataBindings.Add("Text", bindingSource1, "登記人");
            txt_bookdate.DataBindings.Add("Text", bindingSource1, "外出日期");
            txt_booktimeg.DataBindings.Add("Text", bindingSource1, "外出時間");
            txt_booktimeb.DataBindings.Add("Text", bindingSource1, "返回時間");

            ck_booktimeb.DataBindings.Add("Checked", bindingSource1, "不返回公司");
            cb_type.DataBindings.Add("Text", bindingSource1, "外出類型");

            txt_num.DataBindings.Add("Text", bindingSource1, "隨行人數");
            txt_Desc.DataBindings.Add("Text", bindingSource1, "外出說明");

        }

        //按鈕控制
        private void Edit_Status(Boolean vBool)
        {            
            bindingNavigatorMovePreviousItem.Enabled = vBool;
            bindingNavigatorMoveNextItem.Enabled = vBool;
            bindingNavigatorMoveFirstItem.Enabled = vBool;
            bindingNavigatorMoveLastItem.Enabled = vBool;
            toolStripButton1.Enabled = vBool;
            toolStripButton2.Enabled = vBool;
            toolStripButton5.Enabled = vBool;

            toolStripButton3.Enabled = !vBool;
            toolStripButton4.Enabled = !vBool;
            btn_Query.Enabled = vBool;

            //編輯區控制
            txt_USERID.ReadOnly = vBool;
            txt_bookdate.ReadOnly = vBool;
            txt_booktimeg.ReadOnly = vBool;
            txt_booktimeb.ReadOnly = vBool;
            ck_booktimeb.Enabled = !vBool;
            txt_num.ReadOnly = vBool;
            txt_Desc.ReadOnly = vBool;
            cb_type.Enabled = !vBool;

        }

        //資料異動控制,新增刪除修改後,資料重讀及定位
        private void DataUpdate(String vRecordStatus)
        {
            String vKeyno = "" ;
            String vUser = "";
            String vDate = "";
            String vTime = "";
            String vTimeback = "";

            if (txt_keyno_.Text == "" )
            { vKeyno = txt_USERID.Text + ">" + txt_bookdate.Text + "-" + txt_booktimeg.Text ; }
            else
            { vKeyno = txt_keyno_.Text ; }

            vUser = txt_USERID.Text;
            vDate = txt_bookdate.Text;
            vTime = txt_booktimeb.Text;

            OleDbConnection cnn = new OleDbConnection(connectionString);
            cnn.Open();            
            OleDbDataAdapter dtapter = new OleDbDataAdapter(sql, cnn);

            if (vRecordStatus == "A" || vRecordStatus == "E")
            {
                // 判斷是否有重覆資料 登記人+日期+時間
                sql = " select  * from logItem"
                     + " WHERE keyno_ = '" + vKeyno + "' ";

                dtapter.SelectCommand = cnn.CreateCommand() ;
                dtapter.SelectCommand.CommandText = sql;
                DataSet ds = new DataSet();
                dtapter.Fill(ds, "logItem");
                

                if (ds.Tables[0].Rows.Count == 0)
                {
                    sql = "INSERT INTO logItem(keyno_,登記人,外出日期,外出時間,返回時間,不返回公司,外出類型,外出說明,隨行人數,loguser_,logdate_,建立人員,建立時間,flag_) "
                         + "VALUES(@keyno_,@登記人,@外出日期,@外出時間,@返回時間,@不返回公司,@外出類型,@外出說明,@隨行人數,@loguser_,@logdate_,@建立人員,@建立時間,@flag_)";
                    dtapter.InsertCommand = cnn.CreateCommand();
                    dtapter.InsertCommand.CommandText = sql;
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("keyno_", vKeyno ));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("登記人", txt_USERID.Text));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("外出日期", txt_bookdate.Text));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("外出時間", txt_booktimeg.Text));
                    if (txt_booktimeb.Text.Trim() == ":")
                    { vTimeback = ""; }
                    else
                    {
                        if (ck_booktimeb.Checked)
                        { vTimeback = "" ; }
                        else
                        { vTimeback = txt_booktimeb.Text; }
                    }
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("返回時間", vTimeback));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("不返回公司", ck_booktimeb.Checked) );
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("外出類型", cb_type.Text));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("外出說明", txt_Desc.Text.Trim()));
                    if (txt_num.Text.Trim() != "")
                    {
                        dtapter.InsertCommand.Parameters.Add(new OleDbParameter("隨行人數", Convert.ToInt32(txt_num.Text.Trim()).ToString()));
                    }
                    else
                    {
                        dtapter.InsertCommand.Parameters.Add(new OleDbParameter("隨行人數", "1"));
                    }
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("loguser_", Environment.UserName));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("logdate_", System.DateTime.Now.ToString()));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("建立人員", Environment.UserName));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("建立時間", System.DateTime.Now.ToString()));
                    dtapter.InsertCommand.Parameters.Add(new OleDbParameter("flag_", "A"));
                    dtapter.InsertCommand.ExecuteNonQuery();
                }
                else 
                {

                    sql = "UPDATE logItem SET flag_ = @flag_ , 隨行人數 = @隨行人數 ,loguser_ = @loguser_  ,logdate_ = @logdate_ ,外出說明 = @外出說明,返回時間 = @返回時間,不返回公司 = @不返回公司,外出類型 = @外出類型 "
                        + " WHERE keyno_ = @keyno_ " ;  
                    dtapter.UpdateCommand = cnn.CreateCommand();
                    dtapter.UpdateCommand.CommandText = sql;
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("flag_", "M"));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("隨行人數", Convert.ToInt32(txt_num.Text.Trim()).ToString()));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("loguser_", Environment.UserName));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("logdate_", System.DateTime.Now.ToString()));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("外出說明", txt_Desc.Text.Trim()));
                    if (txt_booktimeb.Text.Trim() == ":")
                    { vTimeback = ""; }
                    else
                    {
                        if (ck_booktimeb.Checked)
                        { vTimeback = ""; }
                        else
                        { vTimeback = txt_booktimeb.Text; }
                    }
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("返回時間", vTimeback));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("不返回公司", ck_booktimeb.Checked));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("外出類型", cb_type.Text));
                    dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("keyno_", vKeyno));
                    if (vRecordStatus == "A")
                    {
                        DialogResult result = MessageBox.Show("此筆資料已存在，是否異動資料??", "新增提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (result == DialogResult.Yes)
                        { 
                            dtapter.UpdateCommand.ExecuteNonQuery();  
                        }                        
                    }
                    else
                    {
                        dtapter.UpdateCommand.ExecuteNonQuery();
                    }
                    
                }
            }
            else if (vRecordStatus == "D")
            {
                sql = "UPDATE logItem SET flag_ = @flag_ ,loguser_ = @loguser_  ,logdate_ = @logdate_ "
                     + " WHERE keyno_ = @keyno_ ";
                dtapter.UpdateCommand = cnn.CreateCommand();
                dtapter.UpdateCommand.CommandText = sql;
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("flag_", "D"));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("loguser_", Environment.UserName));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("logdate_", System.DateTime.Now.ToString()));
                dtapter.UpdateCommand.Parameters.Add(new OleDbParameter("keyno_", vKeyno ));
                dtapter.UpdateCommand.ExecuteNonQuery();
            }
            System.Threading.Thread.Sleep(600); //延遲處理時,等待完成異動!
            dtapter.Dispose();
            //按鈕控制

            Edit_Status(true);
            DataLoad();

            // 定位回編輯資料
            int row = this.dataGridView1.Rows.Count;

            for (int i = 0; i < row; i++)
            {
                if (  vUser  == dataGridView1[2, i].Value.ToString()
                   && vDate == dataGridView1[3, i].Value.ToString() 
                   && vTime == dataGridView1[4, i].Value.ToString() )
                {
                    this.dataGridView1.CurrentCell = this.dataGridView1[2, i];//定位到相同的儲存格
                    break;
                }
            }
            tabControl1.SelectedIndex = 0;
        }
     

        private void timer1_Tick(object sender, EventArgs e)
        {
            stlbl_date.Text = System.DateTime.Now.ToLongDateString() ;
            stlbl_time.Text = System.DateTime.Now.ToLongTimeString()
                             + " "
                             + System.DateTime.Now.DayOfWeek.ToString();
        }

        private void dp_bookdate_ValueChanged(object sender, EventArgs e)
        {
            if (DataStatus == "A" || DataStatus == "E")
            {  txt_bookdate.Text = dp_bookdate.Text; }            
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                DialogResult result = MessageBox.Show("是否繼續刪除此筆資料??", "刪除提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                   DataStatus = "D";
                   DataUpdate("D");
                }
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            DataStatus = "A";
            tabControl1.SelectedIndex = 1 ;
            tabPage1.Text = "資料明細-新增";
            txt_USERID.Focus();
            Edit_Status(false);
            ////建立DataView
            myDataView = new DataView(myDataTable);
            DataRowView drv = myDataView.AddNew();
            txt_USERID.Text = Environment.UserName;
            dp_bookdate.Value = System.DateTime.Now;
            txt_bookdate.Text = dp_bookdate.Value.ToString("yyyyMMdd");
            txt_booktimeg.Text = System.DateTime.Now.ToString("HH:mm");
            txt_booktimeb.Text = "" ;
            ck_booktimeb.Checked = false;
            txt_num.Text = "1";
            cb_type.SelectedIndex = -1 ;
            txt_Desc.Text = "";

            drv["登記人"] = txt_USERID.Text;
            drv["外出日期"] = txt_bookdate.Text;
            drv["外出時間"] = txt_booktimeg.Text;
            drv["隨行人數"] = txt_num.Text;
            drv["外出說明"] = txt_Desc.Text.Trim();
            //drv.EndEdit();
        }

        private void btn_Query_Click(object sender, EventArgs e)
        {
            DataLoad();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (txt_USERID.Text.Trim() == "")
            {
                MessageBox.Show("請輸入登記姓名!");
                txt_USERID.Focus();
                return;
            }

            if (txt_bookdate.Text.Trim() == "")
            {
                MessageBox.Show("請輸入外出日期!");
                txt_bookdate.Focus();
                return;
            }

            if (txt_booktimeg.Text.Trim() == ":")
            {
                MessageBox.Show("請輸入外出時間!");
                txt_booktimeg.Focus();
                return;
            }
            
            if (txt_booktimeb.Text.Trim() == ":")
            {
                if ( !ck_booktimeb.Checked )
                {
                    MessageBox.Show("請輸入返回時間!");
                    txt_booktimeb.Focus();
                    return;
                }
            }

            if (cb_type.Text == "")
            {
                MessageBox.Show("請選取外出類型!");
                cb_type.Focus();
                return;
            }

            if (cb_type.Text == "其他")
            {
                if (txt_Desc.Text.Trim() == "")
                {
                    MessageBox.Show("請輸入外出說明!");
                    txt_Desc.Focus();
                    return;
                } 
            }
            //資料庫異動
            DataUpdate(DataStatus);
            DataStatus = "";
            tabPage1.Text = "資料明細";
            //System.Threading.Thread.Sleep(500); //延遲處理時,等待完成異動!
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            //重讀資料
            DataLoad();
            //控制按鈕狀態
            Edit_Status(true);
            DataStatus = "";
            tabPage1.Text = "資料明細";
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                DataStatus = "E";
                tabControl1.SelectedIndex = 1;
                tabPage1.Text = "資料明細-修改";
                Edit_Status(false); 
            }
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (DataStatus == "A" || DataStatus =="E") 
            {
                tabControl1.SelectTab(1);
            }

        }

        private void 顯示其他欄位ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Columns[10].Visible)
            {
                FieldDs_MenuItem.Text = "顯示其他資訊";
            }
            else
            {
                FieldDs_MenuItem.Text = "隱藏其他資訊";
            }
            
            //dataGridView1.Columns[10].Visible = !dataGridView1.Columns[10].Visible ;
            //dataGridView1.Columns[11].Visible = !dataGridView1.Columns[11].Visible;
            dataGridView1.Columns[9].Visible = !dataGridView1.Columns[9].Visible;
            dataGridView1.Columns[10].Visible = !dataGridView1.Columns[10].Visible;
            //dataGridView1.Columns[14].Visible = !dataGridView1.Columns[14].Visible;

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            tabControl1.SelectTab(1);
        }

        private void 轉出ExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //匯出至excel 
            if ((dataGridView1.RowCount) != 0)
            {
                //宣告 EXCEL 變數
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                // Open xls file   
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                int i, j ;
                for (j = 0; j <= dataGridView1.Columns.Count - 1; j++)
                {
                    if (dataGridView1.Columns[j].HeaderText.ToString() == "FLAG"
                        || dataGridView1.Columns[j].HeaderText.ToString() == "識別碼"
                        || dataGridView1.Columns[j].HeaderText.ToString() == "序號"
                        || dataGridView1.Columns[j].HeaderText.ToString() == "建立人員"
                        || dataGridView1.Columns[j].HeaderText.ToString() == "建立時間")
                    { continue; }
                    else
                    { xlWorkSheet.Cells[1, j + 1] = dataGridView1.Columns[j].HeaderText.ToString();  }                    
                }

                for (i = 0; i <= dataGridView1.RowCount - 1; i++)
                {
                    for (j = 0; j <= dataGridView1.Columns.Count - 1; j++)
                    {
                        if (dataGridView1.Columns[j].HeaderText.ToString() == "FLAG"
                            || dataGridView1.Columns[j].HeaderText.ToString() == "識別碼"
                            || dataGridView1.Columns[j].HeaderText.ToString() == "序號"
                            || dataGridView1.Columns[j].HeaderText.ToString() == "建立人員"
                            || dataGridView1.Columns[j].HeaderText.ToString() == "建立時間")
                        { continue;  }
                        else
                        {
                            if (dataGridView1.Columns[j].HeaderText.ToString() == "不返回公司")
                            {                                
                                if (dataGridView1[j, i].Value.ToString().ToLower() == "true")
                                { xlWorkSheet.Cells[i + 2, j + 1] =  "V" ; }
                                else
                                { xlWorkSheet.Cells[i + 2, j + 1] =  "" ; }
                            }
                            else
                            { xlWorkSheet.Cells[i + 2, j + 1] = dataGridView1[j, i].Value.ToString();  }
                            
                        }

                    }
                }
                // show xls file

                // close xls file
                SaveFileDialog SaveFileDialog1 = new SaveFileDialog() ;
                SaveFileDialog1.RestoreDirectory = true;
                SaveFileDialog1.Filter = "Microsoft Office Excel 活頁簿 (*.xls)|*.xls";
                SaveFileDialog1.Title = "儲存檔案" ;
                SaveFileDialog1.FileName = "外出登記簿" ;
                SaveFileDialog1.ShowDialog();

                xlWorkBook.SaveAs(SaveFileDialog1.FileName, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlApp.Visible = true;
                //xlWorkBook.Close(true, misValue, misValue);
                //xlApp.Quit();

                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook);
            }

        }

        private void 轉出Excel2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            
        }
    }
}
