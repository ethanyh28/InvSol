﻿namespace InvestPG
{
    partial class FMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stlUSER = new System.Windows.Forms.ToolStripStatusLabel();
            this.stlbl_date = new System.Windows.Forms.ToolStripStatusLabel();
            this.stlbl_time = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.WorkItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mumEncrypt = new System.Windows.Forms.ToolStripMenuItem();
            this.mumDataTrans = new System.Windows.Forms.ToolStripMenuItem();
            this.munLogBook = new System.Windows.Forms.ToolStripMenuItem();
            this.mumBondBaseTrans = new System.Windows.Forms.ToolStripMenuItem();
            this.mumSameTrader = new System.Windows.Forms.ToolStripMenuItem();
            this.mumDlpLog = new System.Windows.Forms.ToolStripMenuItem();
            this.mumCmoneyTrans = new System.Windows.Forms.ToolStripMenuItem();
            this.mumBalTrans = new System.Windows.Forms.ToolStripMenuItem();
            this.mumWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.munCascade = new System.Windows.Forms.ToolStripMenuItem();
            this.munHorizontal = new System.Windows.Forms.ToolStripMenuItem();
            this.munVertical = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.基本資料ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mumClose = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.mumNewTrans = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stlUSER,
            this.stlbl_date,
            this.stlbl_time});
            this.statusStrip1.Location = new System.Drawing.Point(0, 656);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(958, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // stlUSER
            // 
            this.stlUSER.Font = new System.Drawing.Font("Microsoft JhengHei", 9F, System.Drawing.FontStyle.Bold);
            this.stlUSER.ForeColor = System.Drawing.Color.DarkBlue;
            this.stlUSER.Name = "stlUSER";
            this.stlUSER.Size = new System.Drawing.Size(53, 20);
            this.stlUSER.Text = "stlUSER";
            // 
            // stlbl_date
            // 
            this.stlbl_date.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stlbl_date.Name = "stlbl_date";
            this.stlbl_date.Size = new System.Drawing.Size(66, 20);
            this.stlbl_date.Text = "stlbl_date";
            // 
            // stlbl_time
            // 
            this.stlbl_time.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stlbl_time.Name = "stlbl_time";
            this.stlbl_time.Size = new System.Drawing.Size(65, 20);
            this.stlbl_time.Text = "stlbl_time";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.WorkItemToolStripMenuItem,
            this.mumWindow,
            this.基本資料ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(958, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // WorkItemToolStripMenuItem
            // 
            this.WorkItemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mumEncrypt,
            this.mumDataTrans,
            this.munLogBook,
            this.mumBondBaseTrans,
            this.mumSameTrader,
            this.mumDlpLog,
            this.mumCmoneyTrans,
            this.mumBalTrans,
            this.mumNewTrans});
            this.WorkItemToolStripMenuItem.Name = "WorkItemToolStripMenuItem";
            this.WorkItemToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.WorkItemToolStripMenuItem.Text = "作業項目";
            // 
            // mumEncrypt
            // 
            this.mumEncrypt.Name = "mumEncrypt";
            this.mumEncrypt.Size = new System.Drawing.Size(215, 22);
            this.mumEncrypt.Text = "字串加解密試算";
            this.mumEncrypt.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // mumDataTrans
            // 
            this.mumDataTrans.Name = "mumDataTrans";
            this.mumDataTrans.Size = new System.Drawing.Size(215, 22);
            this.mumDataTrans.Text = "轉檔作業-績效表";
            this.mumDataTrans.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // munLogBook
            // 
            this.munLogBook.Name = "munLogBook";
            this.munLogBook.Size = new System.Drawing.Size(215, 22);
            this.munLogBook.Text = "外出登記簿";
            this.munLogBook.Visible = false;
            this.munLogBook.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // mumBondBaseTrans
            // 
            this.mumBondBaseTrans.Name = "mumBondBaseTrans";
            this.mumBondBaseTrans.Size = new System.Drawing.Size(215, 22);
            this.mumBondBaseTrans.Text = "債券基本資料轉換";
            this.mumBondBaseTrans.Visible = false;
            this.mumBondBaseTrans.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // mumSameTrader
            // 
            this.mumSameTrader.Name = "mumSameTrader";
            this.mumSameTrader.Size = new System.Drawing.Size(215, 22);
            this.mumSameTrader.Text = "同一人交易上傳(Monthly)";
            this.mumSameTrader.Visible = false;
            this.mumSameTrader.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // mumDlpLog
            // 
            this.mumDlpLog.Name = "mumDlpLog";
            this.mumDlpLog.Size = new System.Drawing.Size(215, 22);
            this.mumDlpLog.Text = "刪除DLP LOG";
            this.mumDlpLog.Visible = false;
            this.mumDlpLog.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // mumCmoneyTrans
            // 
            this.mumCmoneyTrans.Name = "mumCmoneyTrans";
            this.mumCmoneyTrans.Size = new System.Drawing.Size(215, 22);
            this.mumCmoneyTrans.Text = "讀取CMONEY資訊";
            this.mumCmoneyTrans.Visible = false;
            this.mumCmoneyTrans.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // mumBalTrans
            // 
            this.mumBalTrans.Name = "mumBalTrans";
            this.mumBalTrans.Size = new System.Drawing.Size(215, 22);
            this.mumBalTrans.Text = "綜合轉檔";
            this.mumBalTrans.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // mumWindow
            // 
            this.mumWindow.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.munCascade,
            this.munHorizontal,
            this.munVertical,
            this.toolStripMenuItem1});
            this.mumWindow.Name = "mumWindow";
            this.mumWindow.Size = new System.Drawing.Size(68, 20);
            this.mumWindow.Text = "視窗排列";
            // 
            // munCascade
            // 
            this.munCascade.Name = "munCascade";
            this.munCascade.Size = new System.Drawing.Size(135, 22);
            this.munCascade.Text = "&Cascade";
            this.munCascade.Click += new System.EventHandler(this.cascadeToolStripMenuItem_Click);
            // 
            // munHorizontal
            // 
            this.munHorizontal.Name = "munHorizontal";
            this.munHorizontal.Size = new System.Drawing.Size(135, 22);
            this.munHorizontal.Text = "&Horizontal";
            this.munHorizontal.Click += new System.EventHandler(this.horizontalToolStripMenuItem_Click);
            // 
            // munVertical
            // 
            this.munVertical.Name = "munVertical";
            this.munVertical.Size = new System.Drawing.Size(135, 22);
            this.munVertical.Text = "&Vertical";
            this.munVertical.Click += new System.EventHandler(this.verticalToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(132, 6);
            // 
            // 基本資料ToolStripMenuItem
            // 
            this.基本資料ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mumClose});
            this.基本資料ToolStripMenuItem.Name = "基本資料ToolStripMenuItem";
            this.基本資料ToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.基本資料ToolStripMenuItem.Text = "系統";
            // 
            // mumClose
            // 
            this.mumClose.Name = "mumClose";
            this.mumClose.Size = new System.Drawing.Size(124, 22);
            this.mumClose.Text = "結束平台";
            this.mumClose.Click += new System.EventHandler(this.munLogBook_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mumNewTrans
            // 
            this.mumNewTrans.Name = "mumNewTrans";
            this.mumNewTrans.Size = new System.Drawing.Size(215, 22);
            this.mumNewTrans.Text = "新綜合轉檔";
            // 
            // FMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(958, 681);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "投資管理作業小平台";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FMain_FormClosing);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel stlUSER;
        private System.Windows.Forms.ToolStripStatusLabel stlbl_date;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 基本資料ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mumClose;
        private System.Windows.Forms.ToolStripMenuItem mumWindow;
        private System.Windows.Forms.ToolStripMenuItem munCascade;
        private System.Windows.Forms.ToolStripMenuItem munHorizontal;
        private System.Windows.Forms.ToolStripMenuItem munVertical;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem WorkItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem munLogBook;
        private System.Windows.Forms.ToolStripStatusLabel stlbl_time;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem mumSameTrader;
        private System.Windows.Forms.ToolStripMenuItem mumBondBaseTrans;
        private System.Windows.Forms.ToolStripMenuItem mumEncrypt;
        private System.Windows.Forms.ToolStripMenuItem mumDlpLog;
        private System.Windows.Forms.ToolStripMenuItem mumDataTrans;
        private System.Windows.Forms.ToolStripMenuItem mumCmoneyTrans;
        private System.Windows.Forms.ToolStripMenuItem mumBalTrans;
        private System.Windows.Forms.ToolStripMenuItem mumNewTrans;
    }
}

